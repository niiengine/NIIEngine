/*
-----------------------------------------------------------------------------
���Ͷ�ý����

ʱ��: 2014-5-8

�ı�����: utf-8

������˾: �������ǿƼ����޹�˾

�������: ����������

��̷��: ͳ��ʽ

����ģʽ: �ֲ�ʽ

�ڲ��ɷ�: UI���� ������� ��Ƶ���� �������� �¼���������(��ɢ�����)

��Ҫ�ɷ�: c++(80%) c(20%)

��;: ����ϵͳ����(��Χ����ϵͳ�ں�api)
      ��άӦ������
        ��������������������(CAD)
        ������Ϣϵͳ����(GIS)
        ��Ӱ���������ع�����
        ������Ϸ����

ƫ����;: ������Ϸ����

��ҳ: www.niiengine.com ��������: niiengine@gmail.com OR niiengine@163.com

��Ȩ��ʽ:��ҵ��Ȩ(www.niiengine.com/license)(3��)
------------------------------------------------------------------------------
*/

#define RING_BUFFER_OK 0;
#define RING_BUFFER_EMPTY 1;
#define RING_BUFFER_FULL 2;
#define RING_BUFFER_NOTAVAILABLE 3;

//#define RING_BUFFER_DEBUG

#include "utils/log.h"  //CLog
#include <string.h>     //memset, memcpy

/**
 * This buffer can be used by one read and one write thread at any one time
 * without the risk of data corruption.
 * If you intend to call the Reset() method, please use Locks.
 * All other operations are thread-safe.
 */
class CoreAudioRingBuffer
{
public:
    CoreAudioRingBuffer() :
        m_iReadPos(0),
        m_iWritePos(0),
        m_iRead(0),
        m_iWritten(0),
        m_iSize(0),
        m_Buffer(NULL)
    {
    }

    CoreAudioRingBuffer(NCount size) :
        m_iReadPos(0),
        m_iWritePos(0),
        m_iRead(0),
        m_iWritten(0),
        m_iSize(0),
        m_Buffer(NULL)
    {
        Create(size);
    }

    ~CoreAudioRingBuffer()
    {
#ifdef RING_BUFFER_DEBUG
        CLog::Log(LOGDEBUG, "CoreAudioRingBuffer::~CoereAudioRingBuffer: Deleting buffer.");
#endif
        _aligned_free(m_Buffer);
    }

    /**
    * Allocates space for buffer, and sets it's contents to 0.
    *
    * @return true on success, false otherwise
    */
    bool Create(int size)
    {
        m_Buffer =  (Nui8 *)_aligned_malloc(size,16);
        if (m_Buffer)
        {
            m_iSize = size;
            memset(m_Buffer, 0, m_iSize);
            return true;
        }
        return false;
    }

    /**
    * Fills the buffer with zeros and resets the pointers.
    * This method is not thread-safe, so before using this method
    * please acquire a Lock()
    */
    void Reset()
    {
#ifdef RING_BUFFER_DEBUG
        CLog::Log(LOGDEBUG, "CoereAudioRingBuffer::Reset: Buffer reset.");
#endif
        m_iWritten = 0;
        m_iRead = 0;
        m_iReadPos = 0;
        m_iWritePos = 0;
    }

    /**
    * Writes data to buffer.
    * Attempt to write more bytes than available results in RING_BUFFER_FULL.
    *
    * @return RING_BUFFER_OK on success, otherwise an error code
    */
    int Write(Nui8 * src, NCount size)
    {
        NCount space = GetWriteSize();

        //do we have enough space for all the data?
        if (size > space)
        {
#ifdef RING_BUFFER_DEBUG
            CLog::Log(LOGDEBUG, "CoereAudioRingBuffer: Not enough space, ignoring data. Requested: %u Available: %u",size, space);
#endif
            return RING_BUFFER_FULL;
        }

        //no wrapping?
        if (m_iSize > size + m_iWritePos)
        {
#ifdef RING_BUFFER_DEBUG
            CLog::Log(LOGDEBUG, "CoereAudioRingBuffer: Written to: %u size: %u space before: %u\n", m_iWritePos, size, space);
#endif
            memcpy(&(m_Buffer[m_iWritePos]), src, size);
            m_iWritePos+=size;
        }
        //need to wrap
        else
        {
            NCount first = m_iSize - m_iWritePos;
            NCount second = size - first;
#ifdef RING_BUFFER_DEBUG
            CLog::Log(LOGDEBUG, "CoereAudioRingBuffer: Written to (split) first: %u second: %u size: %u space before: %u\n", first, second, size, space);
#endif
            memcpy(&(m_Buffer[m_iWritePos]), src, first);
            memcpy(&(m_Buffer[0]), &src[first], second);
            m_iWritePos = second;
        }

        //we can increase the write count now
        m_iWritten+=size;
        return RING_BUFFER_OK;
    }

    /**
    * Reads data from buffer.
    * Attempt to read more bytes than available results in RING_BUFFER_NOTAVAILABLE.
    * Reading from empty buffer returns RING_BUFFER_EMPTY
    *
    * @return RING_BUFFER_OK on success, otherwise an error code
    */
    int Read(Nui8 * dest, NCount size)
    {
        NCount space = GetReadSize();

        //want to read more than we have written?
        if(space <= 0)
        {
#ifdef RING_BUFFER_DEBUG
            CLog::Log(LOGDEBUG, "CoereAudioRingBuffer: Can't read from empty buffer.");
#endif
            return RING_BUFFER_EMPTY;
        }

        //want to read more than we have available
        if(size > space)
        {
#ifdef RING_BUFFER_DEBUG
            CLog::Log(LOGDEBUG, "CoereAudioRingBuffer: Can't read %u bytes when we only have %u.", size, space);
#endif
            return RING_BUFFER_NOTAVAILABLE;
        }

        //no wrapping?
        if (size + m_iReadPos < m_iSize)
        {
#ifdef RING_BUFFER_DEBUG
            CLog::Log(LOGDEBUG, "CoereAudioRingBuffer: Reading from: %u size: %u space before: %u\n", m_iWritePos, size, space);
#endif
            memcpy(dest, &(m_Buffer[m_iReadPos]), size);
            m_iReadPos += size;
        }
        //need to wrap
        else
        {
            NCount first = m_iSize - m_iReadPos;
            NCount second = size - first;
#ifdef RING_BUFFER_DEBUG
            CLog::Log(LOGDEBUG, "CoereAudioRingBuffer: Reading from (split) first: %u second: %u size: %u space before: %u\n", first, second, size, space);
#endif
            memcpy(dest, &(m_Buffer[m_iReadPos]), first);
            memcpy(&dest[first], &(m_Buffer[0]), second);
            m_iReadPos = second;
        }
        //we can increase the read count now
        m_iRead += size;

        return RING_BUFFER_OK;
    }

    /**
    * Dumps the buffer.
    */
    void Dump()
    {
        Nui8 * bufferContents =  (Nui8 *)_aligned_malloc(m_iSize + 1,16);
        for (NCount i = 0; i<m_iSize; i++)
        {
            if (i >= m_iReadPos && i<m_iWritePos)
                bufferContents[i] = m_Buffer[i];
            else
                bufferContents[i] = '_';
        }
        bufferContents[m_iSize] = '\0';
        CLog::Log(LOGDEBUG, "CoereAudioRingBuffer::Dump()\n%s",bufferContents);
        _aligned_free(bufferContents);
    }

    /**
    * Returns available space for writing to buffer.
    * Attempt to write more bytes than available results in RING_BUFFER_FULL.
    */
    NCount GetWriteSize()
    {
        return m_iSize - (m_iWritten - m_iRead);
    }

    /**
    * Returns available space for reading from buffer.
    * Attempt to read more bytes than available results in RING_BUFFER_EMPTY.
    */
    NCount GetReadSize()
    {
        return m_iWritten > m_iRead ? m_iWritten - m_iRead : 0;
    }

    /**
    * Returns the buffer size.
    */
    NCount GetMaxSize()
    {
        return m_iSize;
    }

private:
    NCount m_iReadPos;
    NCount m_iWritePos;
    NCount m_iRead;
    NCount m_iWritten;
    NCount m_iSize;
    Nui8 * m_Buffer;
};
