/*
-----------------------------------------------------------------------------
���Ͷ�ý����

ʱ��: 2014-5-7

�ı�����: utf-8

������˾: �������ǿƼ����޹�˾

�������: ����������

��̷��: ͳ��ʽ

����ģʽ: �ֲ�ʽ

�ڲ��ɷ�: UI���� ������� ��Ƶ���� �������� �¼���������(��ɢ�����)

��Ҫ�ɷ�: c++(80%) c(20%)

��;: ����ϵͳ����(��Χ����ϵͳ�ں�api)
      ��άӦ������
        ������Ϣϵͳ����(GIS)
        ��Ӱ���������ع�����
        ������Ϸ����

ƫ����;: ������Ϸ����

��ҳ: www.niiengine.com ��������: niiengine@gmail.com OR niiengine@163.com

��Ȩ��ʽ:��ҵ��Ȩ(www.niiengine.com/license)(3��)
------------------------------------------------------------------------------
*/

#include "NiiPreProcess.h"
#include "NiiDefaultSoundStream.h"
#include "NiiDefaultSoundSystem.h"

#include "threads/SingleLock.h"
#include "utils/log.h"
#include "utils/MathUtils.h"

#include "AEFactory.h"
#include "Utils/AEUtil.h"

/* typecast AE to DefaultSoundSystem */
#define AE (*((DefaultSoundSystem*)CAEFactory::GetEngine()))

using namespace std;

namespace NII
{
namespace NII_MEDIA
{
    //------------------------------------------------------------------------
    DefaultSoundStream::DefaultSoundStream(enum SampleFormat dataFormat,
        NCount sampleRate, NCount encodedSampleRate, AudioChannel channelLayout,
            NCount options) :
                m_resampleRatio(1.0),
                m_internalRatio(1.0),
                m_convertBuffer(NULL),
                m_valid(false),
                m_delete(false),
                m_volume(1.0f),
                m_rgain(1.0f),
                m_refillBuffer(0),
                m_convertFn(NULL),
                m_ssrc(NULL),
                m_framesBuffered(0),
                m_newPacket(NULL),
                m_packet(NULL),
                m_vizPacketPos(NULL),
                m_draining(false),
                m_vizBufferSamples(0),
                m_audioCallback(NULL),
                m_fadeRunning(false),
                m_slave(NULL)
    {
        m_ssrcData.data_out = NULL;

        m_initDataFormat = dataFormat;
        m_initSampleRate = sampleRate;
        m_initEncodedSampleRate = encodedSampleRate;
        m_initChannelLayout = channelLayout;
        m_chLayoutCount = channelLayout.Count();
        m_forceResample = (options & AESTREAM_FORCE_RESAMPLE) != 0;
        m_paused = (options & AESTREAM_PAUSED) != 0;
        m_autoStart = (options & AESTREAM_AUTOSTART) != 0;

        if (m_autoStart)
            m_paused = true;

        ASSERT(m_initChannelLayout.Count());
    }
    //------------------------------------------------------------------------
    void DefaultSoundStream::InitializeRemap()
    {
        CExclusiveLock lock(m_lock);
        if (!AE_IS_RAW(m_initDataFormat))
        {
            /* re-init the remappers */
            m_remap.Initialize(m_initChannelLayout, AE.GetChannelLayout(), false, false, AE.GetStdChLayout());
            m_vizRemap.Initialize(m_initChannelLayout, AudioChannel(ALT_2_0), false, true);

            /*
            if the layout has changed we need to drop data that was already remapped
            */
            if (AE.GetChannelLayout() != m_aeChannelLayout)
            {
                InternalFlush();
                m_aeChannelLayout = AE.GetChannelLayout();
                m_samplesPerFrame = AE.GetChannelLayout().Count();
                m_aeBytesPerFrame = AE_IS_RAW(m_initDataFormat) ? m_bytesPerFrame : (m_samplesPerFrame * sizeof(NIIf));
            }
        }
    }
    //------------------------------------------------------------------------
    void DefaultSoundStream::Initialize()
    {
        CExclusiveLock lock(m_lock);
        if (m_valid)
        {
            InternalFlush();
            delete m_newPacket;

            if (m_convert)
                _aligned_free(m_convertBuffer);

            if (m_resample)
            {
                _aligned_free(m_ssrcData.data_out);
                m_ssrcData.data_out = NULL;
            }
        }

        enum SampleFormat useDataFormat = m_initDataFormat;
        if (AE_IS_RAW(m_initDataFormat))
        {
            /* we are raw, which means we need to work in the output format */
            useDataFormat = AE.GetSinkDataFormat();
            m_initChannelLayout = AE.GetSinkChLayout  ();
            m_samplesPerFrame = m_initChannelLayout.Count();
        }
        else
        {
            if (!m_initChannelLayout.Count())
            {
                m_valid = false;
                return;
            }
            m_samplesPerFrame = AE.GetChannelLayout().Count();
        }

        m_bytesPerSample = (CAEUtil::DataFormatToBits(useDataFormat) >> 3);
        m_bytesPerFrame = m_bytesPerSample * m_initChannelLayout.Count();

        m_aeChannelLayout = AE.GetChannelLayout();
        m_aeBytesPerFrame = AE_IS_RAW(m_initDataFormat) ? m_bytesPerFrame : (m_samplesPerFrame * sizeof(NIIf));
        // set the waterlevel to 75 percent of the number of frames per second.
        // this lets us drain the main buffer down futher before flagging an underrun.
        m_waterLevel = AE.GetSampleRate() - (AE.GetSampleRate() / 4);
        m_refillBuffer = m_waterLevel;

        m_format.m_dataFormat = useDataFormat;
        m_format.m_sampleRate = m_initSampleRate;
        m_format.m_encodedRate = m_initEncodedSampleRate;
        m_format.m_channelLayout = m_initChannelLayout;
        m_format.m_frames = m_initSampleRate / 8;
        m_format.m_frameSamples = m_format.m_frames * m_initChannelLayout.Count();
        m_format.m_frameSize = m_bytesPerFrame;

        m_newPacket = new PPacket();
        if (AE_IS_RAW(m_initDataFormat))
            m_newPacket->data.Alloc(m_format.m_frames * m_format.m_frameSize);
        else
        {
            if (!m_remap.Initialize(m_initChannelLayout, m_aeChannelLayout, false, false,
                AE.GetStdChLayout()) || !m_vizRemap.Initialize(m_initChannelLayout,
                    AudioChannel(ALT_2_0), false, true))
            {
                m_valid = false;
                return;
            }

            m_newPacket->data.Alloc(m_format.m_frameSamples * sizeof(NIIf));
        }

        m_packet = NULL;

        m_inputBuffer.Alloc(m_format.m_frames * m_format.m_frameSize);

        m_resample = (m_forceResample || m_initSampleRate != AE.GetSampleRate()) && !AE_IS_RAW(m_initDataFormat);
        m_convert = m_initDataFormat != SF_F && !AE_IS_RAW(m_initDataFormat);

        /* if we need to convert, set it up */
        if (m_convert)
        {
            /* get the conversion function and allocate a buffer for the data */
            CLog::Log(LOGDEBUG, "DefaultSoundStream::DefaultSoundStream - Converting from %s to SF_F", CAEUtil::DataFormatToStr(m_initDataFormat));
            m_convertFn = CAEConvert::ToFloat(m_initDataFormat);
            if (m_convertFn)
                m_convertBuffer = (NIIf *)_aligned_malloc(m_format.m_frameSamples * sizeof(NIIf), 16);
            else
                m_valid = false;
        }
        else
            m_convertBuffer = (NIIf *)m_inputBuffer.Raw(m_format.m_frames * m_format.m_frameSize);

        /* if we need to resample, set it up */
        if (m_resample)
        {
            int err;
            m_ssrc = src_new(SRC_SINC_MEDIUM_QUALITY, m_initChannelLayout.Count(), &err);
            m_ssrcData.data_in = m_convertBuffer;
            m_internalRatio = (NIId)AE.GetSampleRate() / (NIId)m_initSampleRate;
            m_ssrcData.src_ratio = m_internalRatio;
            m_ssrcData.data_out = (NIIf *)_aligned_malloc(m_format.m_frameSamples * (int)std::ceil(m_ssrcData.src_ratio) * sizeof(NIIf), 16);
            m_ssrcData.output_frames = m_format.m_frames * (long)std::ceil(m_ssrcData.src_ratio);
            m_ssrcData.end_of_input = 0;
            // we must buffer the same amount as before but taking the source sample rate into account
            // there is no reason to decrease the buffer for upsampling
            if (m_internalRatio < 1)
            {
                m_waterLevel *= (1.0 / m_internalRatio);
                m_refillBuffer = m_waterLevel;
            }
        }

        m_limiter.SetSamplerate(AE.GetSampleRate());

        m_chLayoutCount = m_format.m_channelLayout.Count();
        m_valid = true;
    }
    //------------------------------------------------------------------------
    void DefaultSoundStream::Destroy()
    {
        CExclusiveLock lock(m_lock);
        m_valid = false;
        m_delete = true;
    }
    //------------------------------------------------------------------------
    DefaultSoundStream::~DefaultSoundStream()
    {
        CExclusiveLock lock(m_lock);

        InternalFlush();
        if (m_convert)
            _aligned_free(m_convertBuffer);

        if (m_resample)
        {
            _aligned_free(m_ssrcData.data_out);
            src_delete(m_ssrc);
            m_ssrc = NULL;
        }

        delete m_newPacket;
        delete m_packet;

        CLog::Log(LOGDEBUG, "DefaultSoundStream::~DefaultSoundStream - Destructed");
    }
    //------------------------------------------------------------------------
    NCount DefaultSoundStream::getValidSize()
    {
        if (!m_valid || m_draining)
            return 0;

        if (m_framesBuffered >= m_waterLevel)
            return 0;

        return m_inputBuffer.Free() + (std::max(0U, (m_waterLevel - m_framesBuffered)) * m_format.m_frameSize);
    }
    //------------------------------------------------------------------------
    NCount DefaultSoundStream::add(void * data, NCount size)
    {
        CExclusiveLock lock(m_lock);
        if (!m_valid || size == 0 || data == NULL)
            return 0;

        /* if the stream is draining */
        if (m_draining)
        {
            /* if the stream has finished draining, cork it */
            if (m_packet && !m_packet->data.Used() && m_outBuffer.empty())
                m_draining = false;
            else
                return 0;
        }

        /* dont ever take more then getValidSize advertises */
        size = std::min(size, getValidSize());
        if (size == 0)
            return 0;

        NCount taken = 0;
        while(size)
        {
            NCount copy = std::min((NCount)m_inputBuffer.Free(), size);
            if (copy > 0)
            {
                m_inputBuffer.Push(data, copy);
                size -= copy;
                taken += copy;
                data = (uint8_t*)data + copy;
            }

            if (m_inputBuffer.Free() == 0)
            {
                NCount consumed = ProcessFrameBuffer();
                m_inputBuffer.Shift(NULL, consumed);
            }
        }

        lock.Leave();

        /* if the stream is flagged to autoStart when the buffer is full, then do it */
        if (m_autoStart && m_framesBuffered >= m_waterLevel)
            resume();

        return taken;
    }
    //------------------------------------------------------------------------
    NCount DefaultSoundStream::ProcessFrameBuffer()
    {
        uint8_t * data;
        NCount frames, consumed, sampleSize;

        /* convert the data if we need to */
        NCount samples;
        if (m_convert)
        {
            data = (uint8_t*)m_convertBuffer;
            samples = m_convertFn((uint8_t*)m_inputBuffer.Raw(m_inputBuffer.Used()),
                m_inputBuffer.Used() / m_bytesPerSample, m_convertBuffer);
            sampleSize = sizeof(NIIf);
        }
        else
        {
            data = (uint8_t*)m_inputBuffer.Raw(m_inputBuffer.Used());
            samples = m_inputBuffer.Used() / m_bytesPerSample;
            sampleSize = m_bytesPerSample;
        }

        if (samples == 0)
            return 0;

        /* resample it if we need to */
        if (m_resample)
        {
            m_ssrcData.input_frames = samples / m_chLayoutCount;
            if (src_process(m_ssrc, &m_ssrcData) != 0)
                return 0;
            data = (uint8_t*)m_ssrcData.data_out;
            frames = m_ssrcData.output_frames_gen;
            consumed = m_ssrcData.input_frames_used * m_bytesPerFrame;
            if (!frames)
                return consumed;

            samples = frames * m_chLayoutCount;
        }
        else
        {
            data = (uint8_t *)m_convertBuffer;
            frames = samples / m_chLayoutCount;
            consumed = frames * m_bytesPerFrame;
        }

        if (m_refillBuffer)
        {
            if (frames > m_refillBuffer)
                m_refillBuffer = 0;
            else
                m_refillBuffer -= frames;
        }

        /* buffer the data */
        m_framesBuffered += frames;
        const NCount inputBlockSize = m_format.m_frames * m_format.m_channelLayout.Count() * sampleSize;

        size_t remaining = samples * sampleSize;
        while (remaining)
        {
            size_t copy = std::min(m_newPacket->data.Free(), remaining);
            m_newPacket->data.Push(data, copy);
            data += copy;
            remaining -= copy;

            /* wait till we have a full packet, or no more data before processing the packet */
            if ((!m_draining || remaining) && m_newPacket->data.Free() > 0)
                continue;

            /* if we have a full block of data */
            if (AE_IS_RAW(m_initDataFormat))
            {
                m_outBuffer.push_back(m_newPacket);
                m_newPacket = new PPacket();
                m_newPacket->data.Alloc(inputBlockSize);
                continue;
            }

            /* make a new packet for downmix/remap */
            PPacket *pkt = new PPacket();

            /* downmix/remap the data */
            size_t frames = m_newPacket->data.Used() / m_format.m_channelLayout.Count() / sizeof(NIIf);
            size_t used   = frames * m_aeChannelLayout.Count() * sizeof(NIIf);
            pkt->data.Alloc(used);
            m_remap.Remap((NIIf*)m_newPacket->data.Raw (m_newPacket->data.Used()),
                (NIIf*)pkt->data.Take(used), frames);

            /* downmix for the viz if we have one */
            if (m_audioCallback)
            {
                size_t vizUsed = frames * 2 * sizeof(NIIf);
                pkt->vizData.Alloc(vizUsed);
                m_vizRemap.Remap((NIIf*)m_newPacket->data.Raw (m_newPacket->data.Used()),
                    (NIIf*)pkt->vizData.Take(vizUsed), frames);
            }

            /* add the packet to the output */
            m_outBuffer.push_back(pkt);
            m_newPacket->data.Empty();
        }
        return consumed;
    }
    //------------------------------------------------------------------------
    uint8_t * DefaultSoundStream::GetFrame()
    {
        CExclusiveLock lock(m_lock);

        /* if we are fading, this runs even if we have underrun as it is time based */
        if (m_fadeRunning)
        {
            m_volume += m_fadeStep;
            m_volume = std::min(1.0f, std::max(0.0f, m_volume));
            if (m_fadeDirUp)
            {
                if (m_volume >= m_fadeTarget)
                    m_fadeRunning = false;
            }
            else
            {
                if (m_volume <= m_fadeTarget)
                    m_fadeRunning = false;
            }
        }

        /* if we have been deleted or are refilling but not draining */
        if (!m_valid || m_delete || (m_refillBuffer && !m_draining))
            return NULL;

        /* if the packet is empty, advance to the next one */
        if (!m_packet || m_packet->data.CursorEnd())
        {
            delete m_packet;
            m_packet = NULL;

            /* no more packets, return null */
            if (m_outBuffer.empty())
            {
                if (m_draining)
                    return NULL;
                else
                {
                    /* underrun, we need to refill our buffers */
                    CLog::Log(LOGDEBUG, "DefaultSoundStream::GetFrame - Underrun");
                    ASSERT(m_waterLevel > m_framesBuffered);
                    m_refillBuffer = m_waterLevel - m_framesBuffered;
                    return NULL;
                }
            }

            /* get the next packet */
            m_packet = m_outBuffer.front();
            m_outBuffer.pop_front();
        }

        /* fetch one frame of data */
        uint8_t *ret = (uint8_t*)m_packet->data.CursorRead(m_aeBytesPerFrame);

        /* we have a frame, if we have a viz we need to hand the data to it */
        if (m_audioCallback && !m_packet->vizData.CursorEnd())
        {
            NIIf *vizData = (NIIf*)m_packet->vizData.CursorRead(2 * sizeof(NIIf));
            memcpy(m_vizBuffer + m_vizBufferSamples, vizData, 2 * sizeof(NIIf));
            m_vizBufferSamples += 2;
            if (m_vizBufferSamples == 512)
            {
                m_audioCallback->OnAudioData(m_vizBuffer, 512);
                m_vizBufferSamples = 0;
            }
        }

        --m_framesBuffered;
        return ret;
    }
    //------------------------------------------------------------------------
    NIId DefaultSoundStream::getDataWait()
    {
        if (m_delete)
            return 0.0;

        NIId delay = AE.GetDelay();
        delay += (NIId)(m_inputBuffer.Used() / m_format.m_frameSize) / (NIId)m_format.m_sampleRate;
        delay += (NIId)m_framesBuffered / (NIId)AE.GetSampleRate();
        return delay;
    }
    //------------------------------------------------------------------------
    NIId DefaultSoundStream::getRemainTime()
    {
        if (m_delete)
            return 0.0;

        NIId time = AE.GetCacheTime();
        time += (NIId)(m_inputBuffer.Used() / m_format.m_frameSize) / (NIId)m_format.m_sampleRate;
        time += (NIId)m_framesBuffered / (NIId)AE.GetSampleRate();
        return time;
    }
    //------------------------------------------------------------------------
    NIId DefaultSoundStream::getCapacityTime()
    {
        if (m_delete)
            return 0.0;

        NIId total = AE.GetCacheTotal();
        total += (NIId)(m_inputBuffer.Size() / m_format.m_frameSize) / (NIId)m_format.m_sampleRate;
        total += (NIId)m_waterLevel / (NIId)AE.GetSampleRate();
        return total;
    }
    //------------------------------------------------------------------------
    void DefaultSoundStream::pause()
    {
        if (m_paused)
            return;
        m_paused = true;
        AE.pause(this);
    }
    //------------------------------------------------------------------------
    void DefaultSoundStream::resume()
    {
        if (!m_paused)
            return;
        m_paused    = false;
        m_autoStart = false;
        AE.resume(this);
    }
    //------------------------------------------------------------------------
    void DefaultSoundStream::stop()
    {
        CSharedLock lock(m_lock);
        m_draining = true;
    }
    //------------------------------------------------------------------------
    bool DefaultSoundStream::isStop()
    {
        CSharedLock lock(m_lock);
        return (m_draining && !m_packet && m_outBuffer.empty());
    }
    //------------------------------------------------------------------------
    void DefaultSoundStream::clear()
    {
        CLog::Log(LOGDEBUG, "DefaultSoundStream::clear");
        CExclusiveLock lock(m_lock);
        InternalFlush();

        /* internal flush does not do this as these samples are still valid if we are re-initializing */
        m_inputBuffer.Empty();
    }
    //------------------------------------------------------------------------
    void DefaultSoundStream::InternalFlush()
    {
        /* reset the resampler */
        if (m_resample)
        {
            m_ssrcData.end_of_input = 0;
            src_reset(m_ssrc);
        }

        /* invalidate any incoming samples */
        m_newPacket->data.Empty();

        /*
        clear the current buffered packet, we cant delete the data as it may be
        in use by the AE thread, so we just seek to the end of the buffer
        */
        if (m_packet)
            m_packet->data.CursorSeek(m_packet->data.Size());

        /* clear any other buffered packets */
        while (!m_outBuffer.empty())
        {
            PPacket * p = m_outBuffer.front();
            m_outBuffer.pop_front();
            delete p;
        }

        /* reset our counts */
        m_framesBuffered = 0;
        m_refillBuffer = m_waterLevel;
        m_draining = false;
    }
    //------------------------------------------------------------------------
    NIId DefaultSoundStream::getResampleFactor()
    {
        if (!m_resample)
            return 1.0f;

        CSharedLock lock(m_lock);
        return m_ssrcData.src_ratio;
    }
    //------------------------------------------------------------------------
    bool DefaultSoundStream::setResampleFactor(NIId ratio)
    {
        if (!m_resample)
            return false;

        CSharedLock lock(m_lock);

        int oldRatioInt = (int)std::ceil(m_ssrcData.src_ratio);

        m_resampleRatio = ratio;

        src_set_ratio(m_ssrc, m_resampleRatio * m_internalRatio);
        m_ssrcData.src_ratio = m_resampleRatio * m_internalRatio;

        //Check the resample buffer size and resize if necessary.
        if (oldRatioInt < std::ceil(m_ssrcData.src_ratio))
        {
            _aligned_free(m_ssrcData.data_out);
            m_ssrcData.data_out = (NIIf*)_aligned_malloc(m_format.m_frameSamples * (int)std::ceil(m_ssrcData.src_ratio) * sizeof(NIIf), 16);
            m_ssrcData.output_frames = m_format.m_frames * (long)std::ceil(m_ssrcData.src_ratio);
        }
        return true;
    }
    //------------------------------------------------------------------------
    void DefaultSoundStream::add(IAudioCallback * lis)
    {
        CExclusiveLock lock(m_lock);
        m_vizBufferSamples = 0;
        m_audioCallback = lis;
        if (m_audioCallback)
            m_audioCallback->OnInitialize(2, m_initSampleRate, 32);
    }
    //------------------------------------------------------------------------
    void DefaultSoundStream::remove(IAudioCallback * lis)
    {
        CExclusiveLock lock(m_lock);
        m_audioCallback = NULL;
        m_vizBufferSamples = 0;
    }
    //------------------------------------------------------------------------
    void DefaultSoundStream::rollOff(NIIf from, NIIf target, NCount time)
    {
        /* can't fade a RAW stream */
        if (AE_IS_RAW(m_initDataFormat))
            return;

        CExclusiveLock lock(m_lock);
        NIIf delta = target - from;
        m_fadeDirUp = target > from;
        m_fadeTarget = target;
        m_fadeStep = delta / (((NIIf)AE.GetSampleRate() / 1000.0f) * (NIIf)time);
        m_fadeRunning = true;
    }
    //------------------------------------------------------------------------
    bool DefaultSoundStream::isRollOff()
    {
        CSharedLock lock(m_lock);
        return m_fadeRunning;
    }
    //------------------------------------------------------------------------
    void DefaultSoundStream::setNext(SoundStream * slave)
    {
        CSharedLock lock(m_lock);
        m_slave = (DefaultSoundStream *)slave;
    }
    //------------------------------------------------------------------------
}
}