/*
-----------------------------------------------------------------------------
���Ͷ�ý����

ʱ��: 2014-5-8

�ı�����: utf-8

������˾: �������ǿƼ����޹�˾

�������: ����������

��̷��: ͳ��ʽ

����ģʽ: �ֲ�ʽ

�ڲ��ɷ�: UI���� ������� ��Ƶ���� �������� �¼���������(��ɢ�����)

��Ҫ�ɷ�: c++(80%) c(20%)

��;: ����ϵͳ����(��Χ����ϵͳ�ں�api)
      ��άӦ������
        ��������������������(CAD)
        ������Ϣϵͳ����(GIS)
        ��Ӱ���������ع�����
        ������Ϸ����

ƫ����;: ������Ϸ����

��ҳ: www.niiengine.com ��������: niiengine@gmail.com OR niiengine@163.com

��Ȩ��ʽ:��ҵ��Ȩ(www.niiengine.com/license)(3��)
------------------------------------------------------------------------------
*/

#ifndef _NII_PULSE_SOUND_STREAM_H_
#define _NII_PULSE_SOUND_STREAM_H_

#include "NiiPreInclude.h"
#include "NiiSoundStream.h"
#include "threads/Thread.h"
#include <pulse/pulseaudio.h>

namespace NII
{
    class PulseSoundStream : public SoundStream
    {
    public:
        /* this should NEVER be called directly, use AE.GetStream */
        PulseSoundStream(pa_context *context, pa_threaded_mainloop *mainLoop,
            SampleFormat format, NCount sampleRate, AudioChannel channelLayout,
                NCount options);

        ~PulseSoundStream();

        /// @copydetails SoundStream::play
        void play();

        /// @copydetails SoundStream::pause
        void pause();

        /// @copydetails SoundStream::resume
        void resume();

        /// @copydetails SoundStream::stop
        void stop();

        /// @copydetails SoundStream::add
        NCount add(void * data, NCount size);

        /// @copydetails SoundStream::add
        NCount add(const SoundStream * data);

        /// @copydetails SoundStream::add
        NCount add(const Sound * data);

        /// @copydetails SoundStream::clear
        void clear();

        /// @copydetails SoundStream::add
        void add(IAudioCallback * lis);

        /// @copydetails SoundStream::remove
        void remove(IAudioCallback * lis);

        /// @copydetails SoundStream::setVol
        void setVol(NIIf volume);

        /// @copydetails SoundStream::getVol
        NIIf getVol();

        /// @copydetails SoundStream::setPos
        void setPos(const Vector3f & pos);

        /// @copydetails SoundStream::getPos
        void getPos(Vector3f & pos);

        /// @copydetails SoundStream::setVel
        void setVel(const Vector3f & vel);

        /// @copydetails SoundStream::getVel
        void getVel(Vector3f & vel);

        /// @copydetails SoundStream::setDir
        void setDir(const Vector3f & dir);

        /// @copydetails SoundStream::getDir
        void getDir(Vector3f & dir);

        /// @copydetails SoundStream::isStop
        bool isStop();

        /// @copydetails SoundStream::isDataIn
        bool isDataIn(){ return false; }

        /// @copydetails SoundStream::isDataOut
        bool isDataOut();

        /// @copydetails SoundStream::IsDestroyed
        bool IsDestroyed();

        /// @copydetails SoundStream::isRollOff
        bool isRollOff();

        /// @copydetails SoundStream::rollOff
        void rollOff(NIIf from, NIIf target, NCount time);

        /// @copydetails SoundStream::getValidSize
        NCount getValidSize();

        /// @copydetails SoundStream::getRemainTime
        NIId getRemainTime();

        /// @copydetails SoundStream::getCapacityTime
        NIId getCapacityTime();

        /// @copydetails SoundStream::getDataWait
        NIId getDataWait();

        /// @copydetails SoundStream::IsDraining
        bool IsDraining();

        /// @copydetails SoundStream::GetReplayGain
        NIIf GetReplayGain();

        /// @copydetails SoundStream::SetReplayGain
        void SetReplayGain(NIIf factor);

        /// @copydetails SoundStream::GetAmplification
        NIIf GetAmplification() { return 1.0f; }

        /// @copydetails SoundStream::SetAmplification
        void SetAmplification(NIIf amplify){}

        /// @copydetails SoundStream::getFrameSize
        NCount getFrameSize() const;

        /// @copydetails SoundStream::getChannelCount
        NCount getChannelCount() const;

        /// @copydetails SoundStream::getSampleRate
        NCount getSampleRate() const;

        /// @copydetails SoundStream::getEncodeSampleRate
        NCount getEncodeSampleRate() const { return getSampleRate(); }

        /// @copydetails SoundStream::getSampleFormat
        SampleFormat getSampleFormat() const;

        /// @copydetails SoundStream::getResampleFactor
        NIId getResampleFactor();

        /// @copydetails SoundStream::setResampleFactor
        bool setResampleFactor(NIId ratio);

        /// @copydetails SoundStream::setNext
        void setNext(SoundStream * stream);

        /* trigger the stream to update its volume relative to AE */
        void UpdateVolume(NIIf max);

        /* used to prepare a stream for resume */
        void SetDrained() { mResumeCB = true; };

        /* Process the resume of streams */
        void ProcessCallbacks();

        void setMute(bool muted);

        bool IsPaused();

        void Destroy();
    private:
        ///
        static void StreamRequestCallback(pa_stream * s, NCount length, void * data);

        ///
        static void StreamLatencyUpdateCallback(pa_stream * s, void * data);

        ///
        static void StreamStateCallback(pa_stream * s, void * data);

        ///
        static void StreamUnderflowCallback(pa_stream * s, void * data);

        ///
        static void StreamDrainComplete(pa_stream * s, int success, void * data);

        ///
        static inline bool WaitForOperation(pa_operation * op, pa_threaded_mainloop * mainloop, const char *LogEntry);
        bool Cork(bool cork);
    private:
        bool mDestroy;
        bool mInit;
        bool mPause;
        bool mResumeCB;

        pa_stream * mStream;
        pa_sample_spec mSampleFormat;

        NIIf mMaxVol;
        NIIf mVol;
        pa_cvolume mChVol;

        pa_context * mContext;
        pa_threaded_mainloop *m_MainLoop;

        IAudioCallback * mAudioCB;

        SampleFormat mFormat;
        NCount mSampleRate;
        AudioChannel mChLayout;
        NCount mOptions;
        NCount mFrameSize;
        NCount mCacheSize;

        pa_operation * mStopOP;
        SoundStream * mNext;

        class CLinearFader : public CThread
        {
        public:
            CLinearFader(SoundStream * stream);
            void SetupFader(NIIf from, NIIf target, NCount time);
            bool IsRunning();
        protected:
            virtual void Process();
        private:
            SoundStream * mStream;
            NIIf mSrc;
            NIIf mDest;
            NCount mTime;
            volatile bool mRun;
        } mFader;
    };
}
#endif
