/*
-----------------------------------------------------------------------------
���Ͷ�ý����

ʱ��: 2014-5-7

�ı�����: utf-8

������˾: �������ǿƼ����޹�˾

�������: ����������

��̷��: ͳ��ʽ

����ģʽ: �ֲ�ʽ

�ڲ��ɷ�: UI���� ������� ��Ƶ���� �������� �¼���������(��ɢ�����)

��Ҫ�ɷ�: c++(80%) c(20%)

��;: ����ϵͳ����(��Χ����ϵͳ�ں�api)
      ��άӦ������
        ������Ϣϵͳ����(GIS)
        ��Ӱ���������ع�����
        ������Ϸ����

ƫ����;: ������Ϸ����

��ҳ: www.niiengine.com ��������: niiengine@gmail.com OR niiengine@163.com

��Ȩ��ʽ:��ҵ��Ȩ(www.niiengine.com/license)(3��)
------------------------------------------------------------------------------
*/

#include "NiiPreProcess.h"
#include "NiiPulseSound.h"
#include "AEFactory.h"
#include "utils/log.h"
#include "MathUtils.h"
#include "StringUtils.h"

    //------------------------------------------------------------------------
    PulseSound::PulseSound(const String & file, pa_context *context,
        pa_threaded_mainloop * mainLoop) :
            Sound(file),
            mFile(file),
            mSend(0),
            mContext(context),
            mMain(mainLoop),
            mStream(NULL),
            mOP(NULL),
            mMaxVol(0.0f),
            mVol(0.0f),
            mPulse(StringUtils::CreateUUID())
    {
        mWavLoader.Load(file);
    }
    //------------------------------------------------------------------------
    PulseSound::~PulseSound()
    {
        DeInitialize();
    }
    //------------------------------------------------------------------------
    bool PulseSound::Initialize()
    {
        /* we dont re-init the wav loader in PA as PA handles the samplerate */
        if (!mWavLoader.IsValid())
            return false;

        mSampleFormat.format = PA_SAMPLE_FLOAT32NE;
        mSampleFormat.rate = mWavLoader.GetSampleRate();
        mSampleFormat.channels = mWavLoader.GetChannelLayout().Count();

        if (!pa_sample_spec_valid(&mSampleFormat))
        {
            CLog::Log(LOGERROR, "PulseSound::Initialize - Invalid sample spec");
            return false;
        }

        struct pa_channel_map map;
        map.channels = mSampleFormat.channels;
        switch (map.channels)
        {
        case 1:
            map.map[0] = PA_CHANNEL_POSITION_MONO;
            break;
        case 2:
            map.map[0] = PA_CHANNEL_POSITION_FRONT_LEFT;
            map.map[1] = PA_CHANNEL_POSITION_FRONT_RIGHT;
            break;
        default:
            CLog::Log(LOGERROR, "PulseSound::Initialize - We do not yet support multichannel sounds");
            return false;
        }

        mMaxVol = CAEFactory::GetEngine()->getVol();
        mVol = 1.0f;
        pa_volume_t paVolume = pa_sw_volume_from_linear((double)(mVol * mMaxVol));
        pa_cvolume_set(&mChVol, mSampleFormat.channels, paVolume);

        pa_threaded_mainloop_lock(mMain);
        if ((mStream = pa_stream_new(mContext, mPulse.c_str(), &mSampleFormat, &map)) == NULL)
        {
            CLog::Log(LOGERROR, "PulseSound::Initialize - Could not create a stream");
            pa_threaded_mainloop_unlock(mMain);
            return false;
        }

        pa_stream_set_state_callback(mStream, PulseSound::StreamStateCallback, this);
        pa_stream_set_write_callback(mStream, PulseSound::StreamWriteCallback, this);

        if (pa_stream_connect_upload(mStream, mWavLoader.GetFrameCount() * pa_frame_size(&mSampleFormat)) != 0)
        {
            CLog::Log(LOGERROR, "PulseSound::Initialize - Could not initialize the stream");
            pa_stream_disconnect(mStream);
            mStream = NULL;
            pa_threaded_mainloop_unlock(mMain);
            return false;
        }

        /* check if the stream failed */
        if (pa_stream_get_state(mStream) == PA_STREAM_FAILED)
        {
            CLog::Log(LOGERROR, "PulseSound::Initialize - Waited for the stream but it failed");
            pa_stream_disconnect(mStream);
            mStream = NULL;
            pa_threaded_mainloop_unlock(mMain);
            return false;
        }

        pa_threaded_mainloop_unlock(mMain);
        return true;
    }
    //------------------------------------------------------------------------
    void PulseSound::DeInitialize()
    {
        pa_threaded_mainloop_lock(mMain);
        pa_operation * op = pa_context_remove_sample(mContext, mPulse.c_str(), NULL, NULL);
        if (op)
            pa_operation_unref(op);
        pa_threaded_mainloop_unlock(mMain);

        mWavLoader.DeInitialize();
    }
    //------------------------------------------------------------------------
    void PulseSound::play()
    {
        pa_threaded_mainloop_lock(mMain);
        /* we only keep the most recent operation as it is the only one needed for isPlay to function */
        if (mOP)
            pa_operation_unref(mOP);
        mOP = pa_context_play_sample(mContext, mPulse.c_str(), NULL, PA_VOLUME_INVALID, NULL, NULL);
        pa_threaded_mainloop_unlock(mMain);
    }
    //------------------------------------------------------------------------
    void PulseSound::stop()
    {
        if (mOP)
        {
            pa_operation_cancel(mOP);
            pa_operation_unref(mOP);
            mOP = NULL;
        }
    }
    //------------------------------------------------------------------------
    bool PulseSound::isPlay()
    {
        if (mOP)
        {
            if (pa_operation_get_state(mOP) == PA_OPERATION_RUNNING)
            return true;

            pa_operation_unref(mOP);
            mOP = NULL;
        }

        return false;
    }
    //------------------------------------------------------------------------
    void PulseSound::setVol(NIIf volume)
    {
    }
    //------------------------------------------------------------------------
    NIIf PulseSound::getVol()
    {
        return 1.0f;
    }
    //------------------------------------------------------------------------
    void PulseSound::setLoop(NCount c)
    {
    }
    //------------------------------------------------------------------------
    NCount PulseSound::getLoop() const
    {
    }
    //------------------------------------------------------------------------
    void PulseSound::setPos(const Vector3f & pos)
    {
    }
    //------------------------------------------------------------------------
    void PulseSound::getPos(Vector3f & pos) const
    {
    }
    //------------------------------------------------------------------------
    void PulseSound::setVel(const Vector3f & vel)
    {
    }
    //------------------------------------------------------------------------
    void PulseSound::getVel(Vector3f & vel) const
    {
    
    }
    //------------------------------------------------------------------------
    void PulseSound::setDir(const Vector3f & dir)
    {
    
    }
    //------------------------------------------------------------------------
    void PulseSound::getDir(Vector3f & dir) const
    {
    }
    //------------------------------------------------------------------------
    void PulseSound::StreamStateCallback(pa_stream * s, void * data)
    {
        PulseSound * sound = (PulseSound *)data;
        pa_stream_state_t state = pa_stream_get_state(s);

        switch (state)
        {
        case PA_STREAM_FAILED:
            CLog::Log(LOGERROR, "PulseSound::StreamStateCallback - %s",
                pa_strerror(pa_context_errno(sound->mContext)));

        case PA_STREAM_UNCONNECTED:
        case PA_STREAM_CREATING:
        case PA_STREAM_READY:
        case PA_STREAM_TERMINATED:
            pa_threaded_mainloop_signal(sound->mMain, 0);
            break;
        }
    }
    //------------------------------------------------------------------------
    void PulseSound::StreamWriteCallback(pa_stream * s, NCount length, void * data)
    {
        PulseSound * sound = (PulseSound *)data;
        sound->Upload(length);
    }
    //------------------------------------------------------------------------
    void PulseSound::Upload(NCount length)
    {
        NIIf * samples = mWavLoader.GetSamples();
        NCount left = (mWavLoader.GetSampleCount() * sizeof(NIIf)) - mSend;
        NCount send = std::min(length, left);

        if (pa_stream_write(mStream, samples + mSend, send, 0, 0, PA_SEEK_RELATIVE) == 0)
            mSend += send;

        /* if we have no more data disable the callback */
        if (left == send)
        {
            pa_stream_set_write_callback(mStream, NULL, NULL);
            if (pa_stream_finish_upload(mStream) != 0)
            {
                CLog::Log(LOGERROR, "PulseSound::Upload - Error occured");
                /* FIXME: Better error handling */
            }

            /* disconnect the stream as we dont need it anymore */
            pa_stream_disconnect(mStream);
            mStream = NULL;
        }
    }
    //------------------------------------------------------------------------