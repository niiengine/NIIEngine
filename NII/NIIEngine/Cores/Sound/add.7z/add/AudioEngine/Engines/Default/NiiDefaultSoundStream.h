/*
-----------------------------------------------------------------------------
���Ͷ�ý����

ʱ��: 2014-5-8

�ı�����: utf-8

������˾: �������ǿƼ����޹�˾

�������: ����������

��̷��: ͳ��ʽ

����ģʽ: �ֲ�ʽ

�ڲ��ɷ�: UI���� ������� ��Ƶ���� �������� �¼���������(��ɢ�����)

��Ҫ�ɷ�: c++(80%) c(20%)

��;: ����ϵͳ����(��Χ����ϵͳ�ں�api)
      ��άӦ������
        ��������������������(CAD)
        ������Ϣϵͳ����(GIS)
        ��Ӱ���������ع�����
        ������Ϸ����

ƫ����;: ������Ϸ����

��ҳ: www.niiengine.com ��������: niiengine@gmail.com OR niiengine@163.com

��Ȩ��ʽ:��ҵ��Ȩ(www.niiengine.com/license)(3��)
------------------------------------------------------------------------------
*/

#ifndef _NII_DEFAULT_SOUNDSTREAM_H_
#define _NII_DEFAULT_SOUNDSTREAM_H_

#include <samplerate.h>
#include <list>

#include "threads/SharedSection.h"

#include "NiiAudioFormat.h"
#include "NiiSoundStream.h"
#include "Utils/AEConvert.h"
#include "Utils/AERemap.h"
#include "Utils/AEBuffer.h"
#include "Utils/AELimiter.h"

namespace NII
{
namespace NII_MEDIA
{
    class IAEPostProc;
    class DefaultSoundStream : public SoundStream
    {
        friend class DefaultSoundSystem;
    public:
        /// @copydetails SoundStream::play
        void play();

        /// @copydetails SoundStream::pause
        void pause();

        /// @copydetails SoundStream::resume
        void resume();

        /// @copydetails SoundStream::stop
        void stop();

        /// @copydetails SoundStream::add
        NCount add(void * data, NCount size);

        /// @copydetails SoundStream::add
        NCount add(const SoundStream * data);

        /// @copydetails SoundStream::add
        NCount add(const Sound * data);

        /// @copydetails SoundStream::clear
        void clear();

        /// @copydetails SoundStream::add
        void add(IAudioCallback * lis);

        /// @copydetails SoundStream::remove
        void remove(IAudioCallback * lis);

        /// @copydetails SoundStream::getVol
        NIIf getVol() { return m_volume; }

        /// @copydetails SoundStream::setVol
        void setVol(NIIf volume) { m_volume = std::max( 0.0f, std::min(1.0f, volume)); }

        /// @copydetails SoundStream::setPos
        void setPos(const Vector3f & pos);

        /// @copydetails SoundStream::getPos
        void getPos(Vector3f & pos) const;

        /// @copydetails SoundStream::setVel
        void setVel(const Vector3f & vel);

        /// @copydetails SoundStream::getVel
        void getVel(Vector3f & vel) const;

        /// @copydetails SoundStream::setDir
        void setDir(const Vector3f & dir);

        /// @copydetails SoundStream::getDir
        void getDir(Vector3f & dir) const;

        /// @copydetails SoundStream::isStop
        bool isStop();

        /// @copydetails SoundStream::isDataIn
        bool isDataIn() { return m_refillBuffer > 0; }

        /// @copydetails SoundStream::isDataOut
        bool isDataOut();

        /// @copydetails SoundStream::isRollOff
        bool isRollOff();

        /// @copydetails SoundStream::rollOff
        void rollOff(NIIf from, NIIf to, NCount time);

        /// @copydetails SoundStream::getValidSize
        NCount getValidSize();

        /// @copydetails SoundStream::getRemainTime
        NIId getRemainTime();

        /// @copydetails SoundStream::getCapacityTime
        NIId getCapacityTime();

        /// @copydetails SoundStream::getDataWait
        NIId getDataWait();

        /// @copydetails SoundStream::IsDraining
        bool IsDraining() { return m_draining; }

        /// @copydetails SoundStream::GetReplayGain
        NIIf GetReplayGain() { return m_rgain ; }

        /// @copydetails SoundStream::SetReplayGain
        void SetReplayGain(NIIf factor) { m_rgain  = std::max( 0.0f, factor); }

        /// @copydetails SoundStream::GetAmplification
        NIIf GetAmplification() { return m_limiter.GetAmplification(); }

        /// @copydetails SoundStream::SetAmplification
        void SetAmplification(NIIf amplify){ m_limiter.SetAmplification(amplify); }

        /// @copydetails SoundStream::getFrameSize
        NCount getFrameSize() const  { return m_format.m_frameSize; }

        /// @copydetails SoundStream::getChannelCount
        NCount getChannelCount() const  { return m_initChannelLayout.Count(); }

        /// @copydetails SoundStream::getSampleRate
        NCount getSampleRate() const  { return m_initSampleRate; }

        /// @copydetails SoundStream::getEncodeSampleRate
        NCount getEncodeSampleRate() const  { return m_initEncodedSampleRate; }

        /// @copydetails SoundStream::getSampleFormat
        SampleFormat getSampleFormat() const  { return m_initDataFormat; }

        /// @copydetails SoundStream::getResampleFactor
        NIId getResampleFactor();

        /// @copydetails SoundStream::setResampleFactor
        bool setResampleFactor(NIId ratio);

        /// @copydetails SoundStream::setNext
        void setNext(SoundStream * stream);

        NIIf RunLimiter(NIIf * frame, int channels) { return m_limiter.Run(frame, channels); }
    protected:
        DefaultSoundStream(enum SampleFormat format, NCount sampleRate,
            NCount encodedSamplerate, AudioChannel channelLayout,
                NCount options);
        virtual ~DefaultSoundStream();

        void Initialize();

        void InitializeRemap();

        void Destroy();

        uint8_t * GetFrame();

        bool IsPaused() { return m_paused; }
        bool IsDestroyed() { return m_delete; }
        bool IsValid() { return m_valid; }
        const bool IsRaw() const { return AE_IS_RAW(m_initDataFormat); }
    private:
        void InternalFlush();
        void CheckResampleBuffers();

        CSharedSection m_lock;
        enum SampleFormat m_initDataFormat;
        NCount m_initSampleRate;
        NCount m_initEncodedSampleRate;
        AudioChannel m_initChannelLayout;
        NCount m_chLayoutCount;

        typedef struct
        {
            CAEBuffer data;
            CAEBuffer vizData;
        } PPacket;

        VoiceFormat m_format;

        bool m_forceResample; /* true if we are to force resample even when the rates match */
        bool m_resample;      /* true if the audio needs to be resampled  */
        NIId m_resampleRatio; /* user specified resample ratio */
        NIId m_internalRatio; /* internal resample ratio */
        bool m_convert;       /* true if the bitspersample needs converting */
        NIIf * m_convertBuffer; /* buffer for converted data */
        bool m_valid;         /* true if the stream is valid */
        bool m_delete;        /* true if DefaultSoundSystem is to free this object */
        AudioChConvert m_remap;         /* the remapper */
        NIIf m_volume;        /* the volume level */
        NIIf m_rgain;         /* replay gain level */
        NCount m_waterLevel;    /* the fill level to fall below before calling the data callback */
        NCount m_refillBuffer;  /* how many frames that need to be buffered before we return any frames */

        CAEConvert::AEConvertToFn m_convertFn;

        CAEBuffer m_inputBuffer;
        NCount m_bytesPerSample;
        NCount m_bytesPerFrame;
        NCount m_samplesPerFrame;
        AudioChannel m_aeChannelLayout;
        NCount m_aeBytesPerFrame;
        SRC_STATE * m_ssrc;
        SRC_DATA m_ssrcData;
        NCount m_framesBuffered;
        std::list<PPacket *> m_outBuffer;
        NCount ProcessFrameBuffer();
        PPacket * m_newPacket;
        PPacket * m_packet;
        uint8_t * m_packetPos;
        NIIf * m_vizPacketPos;
        bool m_paused;
        bool m_autoStart;
        bool m_draining;
        CAELimiter m_limiter;

        /* vizualization internals */
        AudioChConvert m_vizRemap;
        NIIf m_vizBuffer[512];
        NCount m_vizBufferSamples;
        IAudioCallback * m_audioCallback;

        /* fade values */
        bool m_fadeRunning;
        bool m_fadeDirUp;
        NIIf m_fadeStep;
        NIIf m_fadeTarget;
        NCount m_fadeTime;

        /* slave stream */
        DefaultSoundStream * m_slave;
    };
}
}
#endif