/*
-----------------------------------------------------------------------------
���Ͷ�ý����

ʱ��: 2014-5-8

�ı�����: utf-8

������˾: �������ǿƼ����޹�˾

�������: ����������

��̷��: ͳ��ʽ

����ģʽ: �ֲ�ʽ

�ڲ��ɷ�: UI���� ������� ��Ƶ���� �������� �¼���������(��ɢ�����)

��Ҫ�ɷ�: c++(80%) c(20%)

��;: ����ϵͳ����(��Χ����ϵͳ�ں�api)
      ��άӦ������
        ��������������������(CAD)
        ������Ϣϵͳ����(GIS)
        ��Ӱ���������ع�����
        ������Ϸ����

ƫ����;: ������Ϸ����

��ҳ: www.niiengine.com ��������: niiengine@gmail.com OR niiengine@163.com

��Ȩ��ʽ:��ҵ��Ȩ(www.niiengine.com/license)(3��)
------------------------------------------------------------------------------
*/

#include "NiiPreInclude.h"

#include "threads/Thread.h"
#include "threads/CriticalSection.h"
#include "threads/SharedSection.h"

#include "Interfaces/ThreadedAE.h"
#include "Utils/AEBuffer.h"
#include "NiiAudioFormat.h"
#include "AESinkFactory.h"

#include "NiiDefaultSoundStream.h"
#include "NiiDefaultSound.h"

#include "cores/IAudioCallback.h"

namespace NII
{
namespace NII_MEDIA
{
    class IAESink;
    class IAEEncoder;

    class DefaultSoundSystem : public IThreadedAE
    {
        friend class CAEFactory;
    public:
        /// @copydetails IThreadedAE::Run
        virtual void Run();

        /// @copydetails IThreadedAE::Stop
        virtual void Stop();

        /// ֹͣ����
        void play(Sound * sound);

        /// ��������
        void stop(Sound * sound);

        ///
        void pause(DefaultSoundStream * stream);

        ///
        void resume(DefaultSoundStream * stream);

        /* these are for the streams so they can provide compatible data */
        NCount GetSampleRate();

        NCount GetChannelCount();

        AudioChannel & GetChannelLayout();

        AudioLayoutType GetStdChLayout();

        NCount GetFrames();

        NCount GetFrameSize();

        /* these are for streams that are in RAW mode */
        const VoiceFormat * GetSinkAudioFormat();

        SampleFormat GetSinkDataFormat();

        AudioChannel & GetSinkChLayout();

        NCount GetSinkFrameSize();

        /// @copydetails SoundSystem::getDataWait
        NIId getDataWait();

        /// @copydetails SoundSystem::getRemainTime
        NIId getRemainTime();

        /// @copydetails SoundSystem::getCapacityTime
        NIId getCapacityTime();
    public:
        /// @copydetails SoundSystem::pause
        bool pause();

        /// @copydetails SoundSystem::resume
        bool resume();

        /// @copydetails SoundSystem::update
        void update();

        /// @copydetails SoundSystem::setMute
        void setMute(const bool set) { m_muted = set; }

        /// @copydetails SoundSystem::setMode
        void setMode(const int mode);

        /// @copydetails SoundSystem::getVol
        NIIf getVol();

        /// @copydetails SoundSystem::setVol
        void setVol(const NIIf volume);

        /// @copydetails SoundSystem::isMute
        bool isMute() { return m_muted; }

        /// @copydetails SoundSystem::isPause
        bool isPause();

        /// @copydetails SoundSystem::create
        Sound * create(const String & file);

        /// @copydetails SoundSystem::destroy
        void destroy(Sound * sound);

        /// @copydetails SoundSystem::createStream
        SoundStream * createStream(SampleFormat sf,NCount sr,
            NCount encodedSampleRate, AudioChannel channelLayout, NCount options = 0);

        /// @copydetails SoundSystem::destroy
        SoundStream * destroy(SoundStream * stream);

        /// @copydetails SoundSystem::enumDev
        void enumDev(AEDeviceList & devices, bool passthrough);

        /// @copydetails SoundSystem::getDefaultDev
        String getDefaultDev(bool passthrough);

        /// @copydetails SoundSystem::SupportsRaw
        bool SupportsRaw();
    public:
        /// @copydetails SoundSystem::OnSettingsChange
        void OnSettingsChange(const String & setting);
    protected:
        DefaultSoundSystem();
        ~DefaultSoundSystem();
    private:
        typedef vector<DefaultSoundStream *>::type Streams;
        typedef list<DefaultSound *>::type Sounds;
    private:
        DefaultSoundStream * GetMasterStream();

        void LoadSettings();
        void VerifySoundDevice(String & device, bool passthrough);
        void OpenSink();

        void InternalOpenSink();
        void InternalCloseSink();
        void ResetEncoder();
        bool SetupEncoder(VoiceFormat & format);

        inline void ProcessSuspend(); /* enter suspend state if nothing to play and sink allows */

        inline void GetDeviceFriendlyName(String & device);

        IAESink * GetSink(VoiceFormat & desiredFormat, bool passthrough, String & device);
        void StopAllSounds();

        void AllocateConvIfNeeded(size_t convertedSize, bool prezero = false);

        /* thread run stages */

        /*! \brief Mix UI sounds into the current stream.
        \param buffer the buffer to mix into.
        \param samples the number of samples in the buffer.
        \return the number of sounds mixed into the buffer.
        */
        NCount softMixer(NIIf * buffer, NCount samples);

        /*! \brief Finalize samples ready for sending to the output device.
        Mixes in any UI sounds, applies volume adjustment, and clamps to [-1,1].
        \param buffer the audio data.
        \param samples the number of samples in the buffer.
        \param hasAudio whether we have audio from a stream (true) or silence (false)
        \return true if we have audio to output, false if we have only silence.
        */
        bool output(NIIf * buffer, NCount samples, bool hasAudio);

        /*! \brief Run the output stage on the audio.
        Prepares streamed data, mixes in any UI sounds, converts to a format suitable
        for the sink, then outputs to the sink.
        \param hasAudio whether or not we have audio (true) or silence (false).
        \return the number of samples sent to the sink.
        */
        int (DefaultSoundSystem::*m_outputStageFn)(bool);
        int RunOutputStage(bool hasAudio);
        int RunRawOutputStage(bool hasAudio);
        int RunTranscodeStage(bool hasAudio);

        NCount (DefaultSoundSystem::*m_streamStageFn)(NCount channelCount,
            void * out, bool & restart);
        NCount RunRawStreamStage(NCount channelCount, void * out, bool & restart);
        NCount RunStreamStage(NCount channelCount, void * out, bool & restart);

        void ResumeSlaveStreams(const Streams & streams);
        void RunNormalizeStage(NCount channelCount, void * out, NCount mixed);

        void RemoveStream(Streams & streams, DefaultSoundStream * stream);
        void PrintSinks();
    private:
        CThread * m_thread;

        enum AudioLayoutType m_stdChLayout;
        String m_device;
        String m_passthroughDevice;
        String m_deviceFriendlyName;
        bool m_audiophile;
        bool m_stereoUpmix;

        /* internal vars */
        bool m_running, m_reOpen;
        bool m_sinkIsSuspended; /* The sink is in unusable state, e.g. SoftSuspended */
        bool m_isSuspended;      /* engine suspended by external function to release audio context */
        bool m_softSuspend;      /* latches after last stream or sound played for timer below for idle */
        NCount m_softSuspendTimer; /* time in milliseconds to hold sink open before soft suspend for idle */
        CEvent m_reOpenEvent;
        CEvent m_wake;
        CEvent m_saveSuspend;

        CCriticalSection m_runningLock;     /* released when the thread exits */
        CCriticalSection m_streamLock;      /* m_streams lock */
        CCriticalSection m_soundLock;       /* m_sounds lock */
        CCriticalSection m_soundSampleLock; /* m_playing_sounds lock */
        CSharedSection   m_sinkLock;        /* lock for m_sink on re-open */
        CCriticalSection m_threadLock;      /* locked while starting/stopping the thread */

        /* the current configuration */
        NIIf m_volume;
        bool m_muted;
        AudioChannel m_chLayout;
        NCount m_frameSize;

        /* the sink, its format information, and conversion function */
        AESinkInfoList m_sinkInfoList;
        IAESink * m_sink;
        VoiceFormat m_sinkFormat;
        NIId m_sinkFormatSampleRateMul;
        NIId m_sinkFormatFrameSizeMul;
        NCount m_sinkBlockSize;
        bool m_sinkHandlesVolume;
        VoiceFormat m_encoderFormat;
        NIId m_encoderFrameSizeMul;
        NIId m_encoderInitSampleRateMul;
        NIId m_encoderInitFrameSizeMul;
        NCount m_bytesPerSample;
        CAEConvert::AEConvertFrFn m_convertFn;

        /* currently playing sounds */
        typedef struct
        {
            DefaultSound * owner;
            NIIf * samples;
            unsigned in sampleCount;
        } SoundState;

        typedef std::list<SoundState> SoundStates;

        /* the streams, sounds, output buffer and output buffer fill size */
        bool m_transcode;
        bool m_rawPassthrough;
        Streams m_newStreams;
        Streams m_streams;
        Streams m_playingStreams;
        Sounds m_sounds;
        SoundStates m_playing_sounds;
        int m_soundMode;
        bool m_streamsPlaying;

        /* this will contain either NIIf, or uint8_t depending on if we are in raw mode or not */
        CAEBuffer m_buffer;

        /* the encoder */
        IAEEncoder * m_encoder;
        CAEBuffer m_encodedBuffer;

        /* the output conversion buffer  */
        uint8_t * m_converted;
        size_t m_convertedSize;

        DefaultSoundStream * m_masterStream;
    };
}
}
