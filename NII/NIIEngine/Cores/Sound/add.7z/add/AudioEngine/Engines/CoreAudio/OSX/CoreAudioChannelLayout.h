/*
-----------------------------------------------------------------------------
大型多媒体框架

时间: 2014-5-8

文本编码: utf-8

所属公司: 深圳闽登科技有限公司

命名风格: 概论命名法

编程风格: 统筹式

管理模式: 分布式

内部成分: UI对象 网络对象 音频对象 物理对象 事件驱动对象(扩散性设计)

主要成分: c++(80%) c(20%)

用途: 操作系统桌面(包围操作系统内核api)
      三维应用软件
        计算机辅助立体设计软件(CAD)
        地理信息系统软件(GIS)
        电影背景立体重构软件
        立体游戏软件

偏向用途: 立体游戏软件

主页: www.niiengine.com 电子邮箱: niiengine@gmail.com OR niiengine@163.com

授权方式:商业授权(www.niiengine.com/license)(3种)
------------------------------------------------------------------------------
*/

#include "system.h"

#if defined(TARGET_DARWIN_OSX)
#include <list>
#include <vector>
#include <string>

#include <CoreAudio/CoreAudio.h>

namespace NII
{
namespace NII_MEDIA
{
    typedef std::vector<SInt32> CoreAudioChannelList;
    typedef std::list<AudioChannelLayoutTag> AudioChannelLayoutList;

    const AudioChannelLayoutTag g_LayoutMap[] =
    {
        kAudioChannelLayoutTag_Stereo,            // PCM_LAYOUT_2_0 = 0,
        kAudioChannelLayoutTag_Stereo,            // PCM_LAYOUT_2_0 = 0,
        kAudioChannelLayoutTag_DVD_4,             // PCM_LAYOUT_2_1,
        kAudioChannelLayoutTag_MPEG_3_0_A,        // PCM_LAYOUT_3_0,
        kAudioChannelLayoutTag_DVD_10,            // PCM_LAYOUT_3_1,
        kAudioChannelLayoutTag_DVD_3,             // PCM_LAYOUT_4_0,
        kAudioChannelLayoutTag_DVD_6,             // PCM_LAYOUT_4_1,
        kAudioChannelLayoutTag_MPEG_5_0_A,        // PCM_LAYOUT_5_0,
        kAudioChannelLayoutTag_MPEG_5_1_A,        // PCM_LAYOUT_5_1,
        kAudioChannelLayoutTag_AudioUnit_7_0,     // PCM_LAYOUT_7_0, ** This layout may be incorrect...no content to testß˚ **
        kAudioChannelLayoutTag_MPEG_7_1_A,        // PCM_LAYOUT_7_1
    };

    const AudioChannelLabel g_LabelMap[] =
    {
        kAudioChannelLabel_Unused,                // PCM_FRONT_LEFT,
        kAudioChannelLabel_Left,                  // PCM_FRONT_LEFT,
        kAudioChannelLabel_Right,                 // PCM_FRONT_RIGHT,
        kAudioChannelLabel_Center,                // PCM_FRONT_CENTER,
        kAudioChannelLabel_LFEScreen,             // PCM_LOW_FREQUENCY,
        kAudioChannelLabel_LeftSurroundDirect,    // PCM_BACK_LEFT, *** This is incorrect, but has been changed to match dvdplayer
        kAudioChannelLabel_RightSurroundDirect,   // PCM_BACK_RIGHT, *** This is incorrect, but has been changed to match dvdplayer
        kAudioChannelLabel_LeftCenter,            // PCM_FRONT_LEFT_OF_CENTER,
        kAudioChannelLabel_RightCenter,           // PCM_FRONT_RIGHT_OF_CENTER,
        kAudioChannelLabel_CenterSurround,        // PCM_BACK_CENTER,
        kAudioChannelLabel_LeftSurround,          // PCM_SIDE_LEFT, *** This is incorrect, but has been changed to match dvdplayer
        kAudioChannelLabel_RightSurround,         // PCM_SIDE_RIGHT, *** This is incorrect, but has been changed to match dvdplayer
        kAudioChannelLabel_VerticalHeightLeft,    // PCM_TOP_FRONT_LEFT,
        kAudioChannelLabel_VerticalHeightRight,   // PCM_TOP_FRONT_RIGHT,
        kAudioChannelLabel_VerticalHeightCenter,  // PCM_TOP_FRONT_CENTER,
        kAudioChannelLabel_TopCenterSurround,     // PCM_TOP_CENTER,
        kAudioChannelLabel_TopBackLeft,           // PCM_TOP_BACK_LEFT,
        kAudioChannelLabel_TopBackRight,          // PCM_TOP_BACK_RIGHT,
        kAudioChannelLabel_TopBackCenter          // PCM_TOP_BACK_CENTER
    };

    class CCoreAudioChannelLayout
    {
    public:
        CCoreAudioChannelLayout();
        CCoreAudioChannelLayout(AudioLayoutType &layout);
        virtual ~CCoreAudioChannelLayout();

        operator AudioLayoutType*() {return m_pLayout;}

        bool CopyLayout(AudioLayoutType &layout);
        static UInt32 GetChannelCountForLayout(AudioLayoutType & layout);
        static const char * ChannelLabelToString(UInt32 label);
        static const char * ChannelLayoutToString(AudioLayoutType & layout, String & str);
        bool AllChannelUnknown();
    protected:
        AudioLayoutType * m_pLayout;
    };
}
}
#endif