/*
-----------------------------------------------------------------------------
���Ͷ�ý����

ʱ��: 2015-5-7

�ı�����: utf-8

������˾: �������ǿƼ����޹�˾

�������: ����������

��̷��: ͳ��ʽ

����ģʽ: �ֲ�ʽ

�ڲ��ɷ�: UI���� ������� ��Ƶ���� �������� �¼���������(��ɢ�����)

��Ҫ�ɷ�: c++(80%) c(20%)

��;: ����ϵͳ����(��Χ����ϵͳ�ں�api)
      ��άӦ������
        ������Ϣϵͳ����(GIS)
        ��Ӱ���������ع�����
        ������Ϸ����

ƫ����;: ������Ϸ����

��ҳ: www.niiengine.com ��������: niiengine@gmail.com OR niiengine@163.com

��Ȩ��ʽ:��ҵ��Ȩ(www.niiengine.com/license)(3��)
------------------------------------------------------------------------------
*/

#include "NiiPreProcess.h"
#include "NiiPulseSoundSystem.h"
#include "NiiPulseSoundStream.h"
#include "NiiPulseSound.h"

#include <pulse/pulseaudio.h>
#include <pulse/simple.h>

#include "threads/SingleLock.h"
#include "utils/log.h"
#include "settings/Settings.h"

#include "guilib/LocalizeStrings.h"

namespace NII
{
namespace NII_MEDIA
{
    //------------------------------------------------------------------------
    static const char * ContextStateToString(pa_context_state s)
    {
        switch (s)
        {
        case PA_CONTEXT_UNCONNECTED:
            return "unconnected";
        case PA_CONTEXT_CONNECTING:
            return "connecting";
        case PA_CONTEXT_AUTHORIZING:
            return "authorizing";
        case PA_CONTEXT_SETTING_NAME:
            return "setting name";
        case PA_CONTEXT_READY:
            return "ready";
        case PA_CONTEXT_FAILED:
            return "failed";
        case PA_CONTEXT_TERMINATED:
            return "terminated";
        default:
            return "none";
        }
    }
    //------------------------------------------------------------------------
    PulseSoundSystem::PulseSoundSystem()
    {
        mContext = NULL;
        mMain = NULL;
        mMute = false;
        mVol = 0.0f;
    }
    //------------------------------------------------------------------------
    PulseSoundSystem::~PulseSoundSystem()
    {
        if (mContext)
        {
            pa_context_disconnect(mContext);
            pa_context_unref(mContext);
            mContext = NULL;
        }

        if (mMain)
        {
            pa_threaded_mainloop_stop(mMain);
            pa_threaded_mainloop_free(mMain);
        }
    }
    //------------------------------------------------------------------------
    bool PulseSoundSystem::startup(VoiceFormat & vf, String & device)
    {
        pa_simple * dummy;
        pa_sample_spec dummyss;

        dummyss.format = PA_SAMPLE_S16NE;
        dummyss.channels = 2;
        dummyss.rate = 48000;

        //create a pulse client, if this returns NULL, pulseaudio isn't running
        dummy = pa_simple_new(NULL, "XBMC-test", PA_STREAM_PLAYBACK, NULL,"test", &dummyss,
            NULL, NULL, NULL);

        if (dummy)
        {
            pa_simple_free(dummy);
            return true;
        }
        else
        {
            return false;
        }

        mVol = g_settings.m_fVolumeLevel;

        if ((mMain = pa_threaded_mainloop_new()) == NULL)
        {
            CLog::Log(LOGERROR, "PulseAudio: Failed to allocate main loop");
            return false;
        }

        if ((mContext = pa_context_new(pa_threaded_mainloop_get_api(mMain), "XBMC")) == NULL)
        {
            CLog::Log(LOGERROR, "PulseAudio: Failed to allocate context");
            return false;
        }

        pa_context_set_state_callback(mContext, ContextStateCallback, mMain);

        if (pa_context_connect(mContext, NULL, (pa_context_flags_t)0, NULL) < 0)
        {
            CLog::Log(LOGERROR, "PulseAudio: Failed to connect context");
            return false;
        }

        pa_threaded_mainloop_lock(mMain);
        if (pa_threaded_mainloop_start(mMain) < 0)
        {
            CLog::Log(LOGERROR, "PulseAudio: Failed to start MainLoop");
            pa_threaded_mainloop_unlock(mMain);
            return false;
        }

        /* Wait until the context is ready */
        do
        {
            pa_threaded_mainloop_wait(mMain);
            CLog::Log(LOGDEBUG, "PulseAudio: Context %s", ContextStateToString(pa_context_get_state(mContext)));
        }
        while (pa_context_get_state(mContext) != PA_CONTEXT_READY && pa_context_get_state(mContext) != PA_CONTEXT_FAILED);

        if (pa_context_get_state(mContext) == PA_CONTEXT_FAILED)
        {
            CLog::Log(LOGERROR, "PulseAudio: Waited for the Context but it failed");
            pa_threaded_mainloop_unlock(mMain);
            return false;
        }

        pa_threaded_mainloop_unlock(mMain);
        return true;
    }
    //------------------------------------------------------------------------
    void PulseSoundSystem::shutdown()
    {
    }
    //------------------------------------------------------------------------
    bool PulseSoundSystem::pause()
    {
        /* TODO: add implementation here. See SoftAE for example. Code should */
        /* release exclusive or hog mode and sleep each time packets would    */
        /* normally be written to sink if m_isSuspended = true. False return  */
        /* here will simply generate a debug log entry in externalplayer.cpp  */

        return false;
    }
    //------------------------------------------------------------------------
    bool PulseSoundSystem::isPause()
    {
        return false;
    }
    //------------------------------------------------------------------------
    bool PulseSoundSystem::resume()
    {
        /* TODO: see comments in pause() above */

        return false;
    }
    //------------------------------------------------------------------------
    void PulseSoundSystem::OnSettingsChange(const String & setting)
    {
    }
    //------------------------------------------------------------------------
    float PulseSoundSystem::getVol()
    {
        return mVol;
    }
    //------------------------------------------------------------------------
    void PulseSoundSystem::setVol(float volume)
    {
        CSingleLock lock(mLock);
        mVol = volume;
        Streams::iterator i, iend = mStreams.end();
        for (i = mStreams.begin(); i != iend; ++i)
            (*i)->UpdateVolume(volume);
    }
    //------------------------------------------------------------------------
    bool PulseSoundSystem::isMute()
    {
        return mMute;
    }
    //------------------------------------------------------------------------
    SoundStream * PulseSoundSystem::createStream(SampleFormat sf, NCount sr,
        NCount encodedSampleRate, AudioChannel channelLayout, NCount options)
    {
        CSingleLock lock(mLock);

        PulseSoundStream * st = N_new PulseSoundStream(mContext, mMain,
            sf, sr, channelLayout, options);

        mStreams.push_back(st);
        return st;
    }
    //------------------------------------------------------------------------
    void PulseSoundSystem::RemoveStream(SoundStream * stream)
    {
        CSingleLock lock(mLock);

        Streams::iterator i, iend = mStreams.end();
        for (i = mStreams.begin(); i != iend; ++i)
        {
            if (*i == stream)
            {
                mStreams.erase(i);
                return;
            }
        }
    }
    //------------------------------------------------------------------------
    SoundStream * PulseSoundSystem::destroy(SoundStream * stream)
    {
        RemoveStream(stream);

        N_delete stream;

        return NULL;
    }
    //------------------------------------------------------------------------
    Sound * PulseSoundSystem::create(const String & file)
    {
        CSingleLock lock(mLock);

        PulseSound * sound = new PulseSound(file, mContext, mMain);
        if (!sound->Initialize())
        {
            delete sound;
            return NULL;
        }

        mSounds.push_back(sound);
        return sound;
    }
    //------------------------------------------------------------------------
    void PulseSoundSystem::destroy(Sound * sound)
    {
        if(!sound)
            return;

        sound->stop();
        CSingleLock lock(mLock);
        Sounds::iterator i, iend = mSounds.end();
        for(i = mSounds.begin(); i != iend; ++i)
        {
            if(*i == sound)
            {
                mSounds.erase(i);
                break;
            }
        }
        delete (PulseSound *)sound;
    }
    //------------------------------------------------------------------------
    void PulseSoundSystem::update()
    {
        CSingleLock lock(mLock);
        SoundStreams::iterator i, iend = mStreams.end();
        for(i = mStreams.begin(); i != iend;)
        {
            if((*i)->IsDestroyed())
            {
                delete (*i);
                i = mStreams.erase(i);
                continue;
            }
            ++i;
        }
    }
    //------------------------------------------------------------------------
    struct SinkInfoStruct
    {
        bool passthrough;
        AEDeviceList * list;
        pa_threaded_mainloop *mainloop;
    };
    //------------------------------------------------------------------------
    static bool WaitForOperation(pa_operation * op, pa_threaded_mainloop * mainloop,
        const char * LogEntry = "")
    {
        if (op == NULL)
            return false;

        bool sucess = true;

        while (pa_operation_get_state(op) == PA_OPERATION_RUNNING)
            pa_threaded_mainloop_wait(mainloop);

        if (pa_operation_get_state(op) != PA_OPERATION_DONE)
        {
            CLog::Log(LOGERROR, "PulseAudio: %s Operation failed", LogEntry);
            sucess = false;
        }

        pa_operation_unref(op);
        return sucess;
    }
    //------------------------------------------------------------------------
    static void SinkInfo(pa_context * c, const pa_sink_info * i, int eol, void * src)
    {
        SinkInfoStruct * sinkStruct = (SinkInfoStruct *)src;

        if (i && i->name)
        {
            bool add = false;
            if(sinkStruct->passthrough)
            {
#if PA_CHECK_VERSION(1,0,0)
                for(int idx = 0; idx < i->n_formats; ++idx)
                {
                    if(!pa_format_info_is_pcm(i->formats[idx]))
                    {
                        add = true;
                        break;
                    }
                }
#endif
            }
            else
                add = true;

            if (add)
            {
                CStdString desc, sink;
                desc.Format("%s (PulseAudio)", i->description);
                sink.Format("pulse:%s@default", i->name);
                sinkStruct->list->push_back(AEDevice(desc, sink));
                CLog::Log(LOGDEBUG, "PulseAudio: Found %s with devicestring %s", desc.c_str(), sink.c_str());
            }
        }

        pa_threaded_mainloop_signal(sinkStruct->mainloop, 0);
    }
    //------------------------------------------------------------------------
    void PulseSoundSystem::enumDev(AEDeviceList & devices, bool passthrough)
    {
        if (!mMain || ! mContext)
            return;

        pa_threaded_mainloop_lock(mMain);

        SinkInfoStruct sinkStruct;
        sinkStruct.passthrough = passthrough;
        sinkStruct.mainloop = mMain;
        sinkStruct.list = &devices;
        CStdString def;
        def.Format("%s (PulseAudio)",g_localizeStrings.Get(409).c_str());
        devices.push_back(AEDevice(def, "pulse:default@default"));
        WaitForOperation(pa_context_get_sink_info_list(mContext,
            SinkInfo, &sinkStruct), mMain, "enumDev");

        pa_threaded_mainloop_unlock(mMain);
    }
    //------------------------------------------------------------------------
    bool PulseSoundSystem::SupportsRaw()
    {
#if PA_CHECK_VERSION(1,0,0)
        return true;
#endif
        return false;
    }
    //------------------------------------------------------------------------
    void PulseSoundSystem::ContextStateCallback(pa_context * c, void * src)
    {
        pa_threaded_mainloop * m = (pa_threaded_mainloop *)src;
        switch (pa_context_get_state(c))
        {
        case PA_CONTEXT_READY:
        case PA_CONTEXT_TERMINATED:
        case PA_CONTEXT_UNCONNECTED:
        case PA_CONTEXT_CONNECTING:
        case PA_CONTEXT_AUTHORIZING:
        case PA_CONTEXT_SETTING_NAME:
        case PA_CONTEXT_FAILED:
            pa_threaded_mainloop_signal(m, 0);
            break;
        }
    }
    //------------------------------------------------------------------------
    void PulseSoundSystem::setMute(bool set)
    {
        CSingleLock lock(mLock);

        Streams::iterator i, iend = mStreams.end();
        for (i = mStreams.begin(); i != iend; ++i)
            (*i)->setMute(set);

        mMute = set;
    }
    //------------------------------------------------------------------------
    void PulseSoundSystem::setMode(const int mode)
    {

    }
    //------------------------------------------------------------------------
#endif
}
}