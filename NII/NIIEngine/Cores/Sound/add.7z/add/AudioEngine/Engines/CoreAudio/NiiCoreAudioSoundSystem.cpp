/*
-----------------------------------------------------------------------------
���Ͷ�ý����

ʱ��: 2014-5-7

�ı�����: utf-8

������˾: �������ǿƼ����޹�˾

�������: ����������

��̷��: ͳ��ʽ

����ģʽ: �ֲ�ʽ

�ڲ��ɷ�: UI���� ������� ��Ƶ���� �������� �¼���������(��ɢ�����)

��Ҫ�ɷ�: c++(80%) c(20%)

��;: ����ϵͳ����(��Χ����ϵͳ�ں�api)
      ��άӦ������
        ������Ϣϵͳ����(GIS)
        ��Ӱ���������ع�����
        ������Ϸ����

ƫ����;: ������Ϸ����

��ҳ: www.niiengine.com ��������: niiengine@gmail.com OR niiengine@163.com

��Ȩ��ʽ:��ҵ��Ȩ(www.niiengine.com/license)(3��)
------------------------------------------------------------------------------
*/

#include "system.h"

#include "NiiCoreAudioSoundSystem.h"

#include "NiiCoreAudioSoundStream.h"
#include "NiiCoreAudioSound.h"
#include "cores/AudioEngine/Utils/AEUtil.h"
#include "settings/GUISettings.h"
#include "settings/Settings.h"
#include "settings/AdvancedSettings.h"
#include "threads/SingleLock.h"
#include "utils/EndianSwap.h"
#include "utils/log.h"
#include "utils/TimeUtils.h"
#include "utils/MathUtils.h"
#include "threads/SystemClock.h"

#define DELAY_FRAME_TIME  20
#define BUFFERSIZE 16416

// on darwin when the devicelist changes
// reinit by calling opencoreaudio with the last engine parameters
// (this will fallback to default
// device when our current output device vanishes
// and on the other hand will go back to that device
// if it re-appears).
#if defined(TARGET_DARWIN_OSX)
    //------------------------------------------------------------------------
    OSStatus deviceChangedCB(AudioObjectID inObjectID, UInt32 inNumberAddresses,
        const AudioObjectPropertyAddress inAddresses[], void * data)
    {
        CoreAudioSoundSystem * system = (CoreAudioSoundSystem *)data;
        if (system->GetHAL())
        {
            system->AudioDevicesChanged();
            CLog::Log(LOGDEBUG, "CoreAudioSoundSystem - audiodevicelist changed!");
        }
        return noErr;
    }
    //------------------------------------------------------------------------
    void RegisterDeviceChangedCB(bool add, void * ref)
    {
        OSStatus ret = noErr;
        const AudioObjectPropertyAddress inAdr =
        {
            kAudioHardwarePropertyDevices,
            kAudioObjectPropertyScopeGlobal,
            kAudioObjectPropertyElementMaster
        };

        if (add)
            ret = AudioObjectAddPropertyListener(kAudioObjectSystemObject, &inAdr, deviceChangedCB, ref);
        else
            ret = AudioObjectRemovePropertyListener(kAudioObjectSystemObject, &inAdr, deviceChangedCB, ref);

        if (ret != noErr)
            CLog::Log(LOGERROR, "CoreAudioSoundSystem::Deinitialize - error %s a listener callback for device changes!", bRegister?"attaching":"removing");
    }
    //------------------------------------------------------------------------
#else //ios
    void RegisterDeviceChangedCB(bool add, void * ref)
    {

    }
#endif
    //------------------------------------------------------------------------
    CoreAudioSoundSystem::CoreAudioSoundSystem() :
        m_Initialized(false),
        m_callbackRunning(false),
        m_lastStreamFormat(SF_Unknow),
        m_lastChLayoutCount(0),
        m_lastSampleRate(0),
        m_chLayoutCount(0),
        m_rawPassthrough(false),
        m_volume(1.0f),
        m_volumeBeforeMute(1.0f),
        m_muted(false),
        m_soundMode(AE_SOUND_OFF),
        m_streamsPlaying(false),
        m_isSuspended(false),
        m_softSuspend(false),
        m_softSuspendTimer(0)
    {
        HAL = new CCoreAudioAEHAL;

        RegisterDeviceChangedCB(true, this);
    }
    //------------------------------------------------------------------------
    CoreAudioSoundSystem::~CoreAudioSoundSystem()
    {
        shutdown();
        RegisterDeviceChangedCB(false, this);
    }
    //------------------------------------------------------------------------
    void CoreAudioSoundSystem::shutdown()
    {
        CSingleLock engineLock(m_engineLock);

        Stop();

        Deinitialize();

        /* free the streams */
        CSingleLock streamLock(m_streamLock);
        while (!m_streams.empty())
        {
            CoreAudioSoundStream * s = m_streams.front();
            m_sounds.pop_front();
            delete s;
        }

        /* free the sounds */
        CSingleLock soundLock(m_soundLock);
        while (!m_sounds.empty())
        {
            CoreAudioSound * s = m_sounds.front();
            m_sounds.pop_front();
            delete s;
        }

        delete HAL;
        HAL = NULL;
    }
    //------------------------------------------------------------------------
    void CoreAudioSoundSystem::AudioDevicesChanged()
    {
        if (!m_Initialized)
            return;

        // give CA a bit time to realise that maybe the
        // default device might have changed now - else
        // OpenCoreAudio might open the old default device
        // again (yeah that really is the case - duh)
        Sleep(500);
        CSingleLock engineLock(m_engineLock);
        OpenCoreAudio(m_lastSampleRate, COREAUDIO_IS_RAW(m_lastStreamFormat),
            m_lastStreamFormat);
    }
    //------------------------------------------------------------------------
    bool CoreAudioSoundSystem::startup(VoiceFormat & vf, String & device)
    {
        CSingleLock engineLock(m_engineLock);

        Stop();

        Deinitialize();

        bool ret = OpenCoreAudio(44100, false, SF_F);
        m_lastSampleRate = 44100;
        m_lastStreamFormat = SF_F;

        Start();

        return ret;
    }
    //------------------------------------------------------------------------
    bool CoreAudioSoundSystem::OpenCoreAudio(NCount sampleRate, bool forceRaw,
        SampleFormat rawDataFormat)
    {
        // remove any deleted streams
        CSingleLock streamLock(m_streamLock);
        StreamList::iterator i, iend = m_streams.end();
        for (i = m_streams.begin(); i != iend;)
        {
            CoreAudioSoundStream * stream = *i;
            if (stream->IsDestroyed())
            {
                i = m_streams.erase(i);
                delete stream;
                continue;
            }
            else
            {
                // close all converter
                stream->CloseConverter();
            }
            ++i;
        }

        /* override the sample rate based on the oldest stream if there is one */
        if (!m_streams.empty())
            sampleRate = m_streams.front()->getSampleRate();

        if (forceRaw)
            m_rawPassthrough = true;
        else
            m_rawPassthrough = !m_streams.empty() && m_streams.front()->IsRaw();
        streamLock.Leave();

        if (m_rawPassthrough)
            CLog::Log(LOGINFO, "CoreAudioSoundSystem::OpenCoreAudio - RAW passthrough enabled");

        std::string m_outputDevice =  g_guiSettings.GetString("audiooutput.audiodevice");

        // on iOS devices we set fixed to two channels.
        m_stdChLayout = ALT_2_0;
#if defined(TARGET_DARWIN_OSX)
        switch (g_guiSettings.GetInt("audiooutput.channels"))
        {
        default:
        case  0:
            m_stdChLayout = ALT_2_0;
            break; /* do not allow 1_0 output */
        case  1:
            m_stdChLayout = ALT_2_0;
            break;
        case  2:
            m_stdChLayout = ALT_2_1;
            break;
        case  3:
            m_stdChLayout = ALT_3_0;
            break;
        case  4:
            m_stdChLayout = ALT_3_1;
            break;
        case  5:
            m_stdChLayout = ALT_4_0;
            break;
        case  6:
            m_stdChLayout = ALT_4_1;
            break;
        case  7:
            m_stdChLayout = ALT_5_0;
            break;
        case  8:
            m_stdChLayout = ALT_5_1;
            break;
        case  9:
            m_stdChLayout = ALT_7_0;
            break;
        case 10:
            m_stdChLayout = ALT_7_1;
            break;
        }
#endif
        // force optical/coax to 2.0 output channels
        if (!m_rawPassthrough && g_guiSettings.GetInt("audiooutput.mode") == AUDIO_IEC958)
            m_stdChLayout = ALT_2_0;

        // setup the desired format
        m_format.m_channelLayout = AudioChannel(m_stdChLayout);

        // if there is an audio resample rate set, use it.
        if (g_advancedSettings.m_audioResample && !m_rawPassthrough)
        {
            sampleRate = g_advancedSettings.m_audioResample;
            CLog::Log(LOGINFO, "CoreAudioSoundSystem::passthrough - Forcing samplerate to %d", sampleRate);
        }

        if (m_rawPassthrough)
        {
            switch (rawDataFormat)
            {
            case SFE_AC3:
            case SFE_DTS:
                m_format.m_channelLayout = AudioChannel(ALT_2_0);
                m_format.m_sampleRate = 48000;
                m_format.m_dataFormat = SF_S16;
                break;
            case SFE_EAC3:
                m_format.m_channelLayout = AudioChannel(ALT_2_0);
                m_format.m_sampleRate = 192000;
                m_format.m_dataFormat = SF_S16;
                break;
            case SFE_DTSHD:
            case SFE_TRUEHD:
                m_format.m_channelLayout = AudioChannel(ALT_7_1);
                m_format.m_sampleRate = 192000;
                m_format.m_dataFormat = SF_S16;
                break;
            case SFE_LPCM:
                m_format.m_channelLayout = AudioChannel(ALT_7_1);
                m_format.m_sampleRate = sampleRate;
                m_format.m_dataFormat = SF_F;
                break;
            default:
                break;
            }
        }
        else
        {
            m_format.m_sampleRate = sampleRate;
            m_format.m_channelLayout = AudioChannel(m_stdChLayout);
            m_format.m_dataFormat = SF_F;
        }

        m_format.m_encodedRate = 0;

        if (m_outputDevice.empty())
            m_outputDevice = "default";

        VoiceFormat initformat = m_format;

        // initialize audio hardware
        m_Initialized = HAL->Initialize(this, m_rawPassthrough, initformat, rawDataFormat, m_outputDevice, m_volume);

        NCount bps = CAEUtil::DataFormatToBits(m_format.m_dataFormat);
        m_chLayoutCount = m_format.m_channelLayout.Count();
        m_format.m_frameSize = (bps >> 3) * m_chLayoutCount; //initformat.m_frameSize;
        //m_format.m_frames        = (NCount)(((NIIf)m_format.m_sampleRate / 1000.0f) * (NIIf)DELAY_FRAME_TIME);
        //m_format.m_frameSamples  = m_format.m_frames * m_format.m_channelLayout.Count();

        if ((initformat.m_channelLayout.Count() != m_chLayoutCount) && !m_rawPassthrough)
        {
            /* readjust parameters. hardware didn't accept channel count*/
            CLog::Log(LOGINFO, "CoreAudioSoundSystem::Initialize: Setup channels (%d) greater than possible hardware channels (%d).",
                m_chLayoutCount, initformat.m_channelLayout.Count());

            m_format.m_channelLayout = AudioChannel(initformat.m_channelLayout);
            m_chLayoutCount = m_format.m_channelLayout.Count();
            m_format.m_frameSize = (bps >> 3) * m_chLayoutCount; //initformat.m_frameSize;
            //m_format.m_frameSamples  = m_format.m_frames * m_format.m_channelLayout.Count();
        }

        CLog::Log(LOGINFO, "CoreAudioSoundSystem::Initialize:");
        CLog::Log(LOGINFO, "  Output Device : %s", m_outputDevice.c_str());
        CLog::Log(LOGINFO, "  Sample Rate   : %d", m_format.m_sampleRate);
        CLog::Log(LOGINFO, "  Sample Format : %s", CAEUtil::DataFormatToStr(m_format.m_dataFormat));
        CLog::Log(LOGINFO, "  Channel Count : %d", m_chLayoutCount);
        CLog::Log(LOGINFO, "  Channel Layout: %s", ((std::string)m_format.m_channelLayout).c_str());
        CLog::Log(LOGINFO, "  Frame Size    : %d", m_format.m_frameSize);
        CLog::Log(LOGINFO, "  Volume Level  : %f", m_volume);
        CLog::Log(LOGINFO, "  Passthrough   : %d", m_rawPassthrough);

        CSingleLock soundLock(m_soundLock);
        StopAllSounds();

        // re-init sounds and unlock
        SoundList::iterator j, jend = m_sounds.end();
        for (j = m_sounds.begin(); j != jend; ++j)
            (*j)->Initialize();

        soundLock.Leave();

        // if we are not in m_rawPassthrough reinit the streams
        if (!m_rawPassthrough)
        {
            /* re-init streams */
            streamLock.Enter();
            StreamList::iterator z, zend = m_streams.end();
            for (z = m_streams.begin(); z != zend; ++z)
                (*z)->Initialize();
            streamLock.Leave();
        }

        return m_Initialized;
    }
    //------------------------------------------------------------------------
    void CoreAudioSoundSystem::Deinitialize()
    {
        if (!m_Initialized)
            return;

        // close all open converters
        CSingleLock streamLock(m_streamLock);
        StreamList::iterator i, iend = m_streams.end();
        for (i = m_streams.begin(); i != iend; ++i)
            (*i)->CloseConverter();
        streamLock.Leave();

        m_Initialized = false;

        CSingleLock callbackLock(m_callbackLock);

        /*
        while(m_callbackRunning)
            Sleep(100);
        */

        HAL->Deinitialize();
    }
    //------------------------------------------------------------------------
    void CoreAudioSoundSystem::OnSettingsChange(const String & setting)
    {
        if (setting == "audiooutput.dontnormalizelevels")
        {
            // re-init streams remapper
            CSingleLock streamLock(m_streamLock);
            StreamList::iterator i, iend = m_streams.end();
            for (i = m_streams.begin(); i != iend; ++i)
                (*i)->InitializeRemap();
            streamLock.Leave();
        }

        if (setting == "audiooutput.passthroughdevice" ||
            setting == "audiooutput.custompassthrough" ||
            setting == "audiooutput.audiodevice"       ||
            setting == "audiooutput.customdevice"      ||
            setting == "audiooutput.mode"              ||
            setting == "audiooutput.ac3passthrough"    ||
            setting == "audiooutput.dtspassthrough"    ||
            setting == "audiooutput.channels"     ||
            setting == "audiooutput.multichannellpcm")
        {
            // only reinit the engine if we not
            // suspended (resume will initialize
            // us again in that case)
            if (!m_isSuspended)
                startup();
        }
    }
    //------------------------------------------------------------------------
    NCount CoreAudioSoundSystem::GetSampleRate()
    {
        return m_format.m_sampleRate;
    }
    //------------------------------------------------------------------------
    NCount CoreAudioSoundSystem::GetEncodedSampleRate()
    {
        return m_format.m_encodedRate;
    }
    //------------------------------------------------------------------------
    AudioChannel CoreAudioSoundSystem::GetChannelLayout()
    {
        return m_format.m_channelLayout;
    }
    //------------------------------------------------------------------------
    NCount CoreAudioSoundSystem::getChannelCount()
    {
        return m_chLayoutCount;
    }
    //------------------------------------------------------------------------
    SampleFormat CoreAudioSoundSystem::GetDataFormat()
    {
        return m_format.m_dataFormat;
    }
    //------------------------------------------------------------------------
    VoiceFormat CoreAudioSoundSystem::GetAudioFormat()
    {
        return m_format;
    }
    //------------------------------------------------------------------------
    NIId CoreAudioSoundSystem::GetDelay()
    {
        return HAL->GetDelay();
    }
    //------------------------------------------------------------------------
    NIIf CoreAudioSoundSystem::getVol()
    {
        return m_volume;
    }
    //------------------------------------------------------------------------
    void CoreAudioSoundSystem::setVol(NIIf volume)
    {
        if (m_rawPassthrough)
            return;

        m_volume = volume;
        // track volume if we are not muted
        // we need this because m_volume is init'ed via
        // SetVolume and need to also init m_volumeBeforeMute.
        if (!m_muted)
            m_volumeBeforeMute = volume;

        HAL->SetVolume(m_volume);
    }
    //------------------------------------------------------------------------
    void CoreAudioSoundSystem::setMute(bool enabled)
    {
        m_muted = enabled;
        if(m_muted)
        {
            m_volumeBeforeMute = m_volume;
            setVol(VOLUME_MINIMUM);
        }
        else
        {
            setVol(m_volumeBeforeMute);
        }
    }
    //------------------------------------------------------------------------
    bool CoreAudioSoundSystem::isMute()
    {
        return m_muted;
    }
    //------------------------------------------------------------------------
    bool CoreAudioSoundSystem::isPause()
    {
        return m_isSuspended;
    }
    //------------------------------------------------------------------------
    void CoreAudioSoundSystem::setMode(int mode)
    {
        m_soundMode = mode;

        /* stop all currently playing sounds if they are being turned off */
        if (mode == AE_SOUND_OFF || (mode == AE_SOUND_IDLE && m_streamsPlaying))
            StopAllSounds();
    }
    //------------------------------------------------------------------------
    bool CoreAudioSoundSystem::SupportsRaw()
    {
        return true;
    }
    //------------------------------------------------------------------------
    CCoreAudioAEHAL * CoreAudioSoundSystem::GetHAL()
    {
        return HAL;
    }
    //------------------------------------------------------------------------
    SoundStream * CoreAudioSoundSystem::createStream(SampleFormat sf,
      NCount sr, NCount encodedSamplerate, AudioChannel channelLayout,
        NCount options)
    {
        // if we are suspended we don't
        // want anyone to mess with us
        if (m_isSuspended && !m_softSuspend)
            return NULL;

        AudioChannel channelInfo(channelLayout);
        CLog::Log(LOGINFO, "CoreAudioSoundSystem::createStream - %s, %u, %u, %s",
            CAEUtil::DataFormatToStr(sf), sr, encodedSamplerate, ((std::string)channelInfo).c_str());

        CoreAudioSoundStream * stream = new CoreAudioSoundStream(sf, sr, encodedSamplerate, channelLayout, options);
        CSingleLock streamLock(m_streamLock);
        m_streams.push_back(stream);
        streamLock.Leave();

        if ((options & AESTREAM_PAUSED) == 0)
            Stop();

        // reinit the engine if pcm format changes or always on raw format
        if (m_Initialized && (m_lastStreamFormat != sf ||
            m_lastChLayoutCount != channelLayout.Count() ||
                m_lastSampleRate != sr || COREAUDIO_IS_RAW(sf)))
        {
            CSingleLock engineLock(m_engineLock);
            Stop();
            Deinitialize();
            m_Initialized = OpenCoreAudio(sr, COREAUDIO_IS_RAW(sf), sf);
            m_lastStreamFormat = sf;
            m_lastChLayoutCount = channelLayout.Count();
            m_lastSampleRate = sr;
        }

        if (!stream->IsValid())
            stream->Initialize();

        if ((options & AESTREAM_PAUSED) == 0)
            Start();

        m_streamsPlaying = true;

        return stream;
    }
    //------------------------------------------------------------------------
    SoundStream * CoreAudioSoundSystem::destroy(SoundStream * stream)
    {
        CSingleLock streamLock(m_streamLock);
        /* ensure the stream still exists */
        StreamList::iterator i, iend = m_streams.end();
        for (i = m_streams.begin(); i != iend;)
        {
            CoreAudioSoundStream * del = *i;
            if (*i == stream)
            {
                i = m_streams.erase(i);
                delete (CoreAudioSoundStream *)stream;
            }
            else if (del->IsDestroyed())
            {
                StreamList::iterator temp = i++;
                m_streams.erase(temp);
                delete del;
            }
            else
            {
                ++i;
            }

        }
        m_streamsPlaying = !m_streams.empty();

        streamLock.Leave();

        // When we have been in passthrough mode and are not suspended,
        // reinit the hardware to come back to anlog out
        if (/*m_streams.empty() || */ m_rawPassthrough && !m_isSuspended)
        {
            CLog::Log(LOGINFO, "CoreAudioSoundSystem::destroy Reinit, no streams left" );
            startup();
        }

        return NULL;
    }
    //------------------------------------------------------------------------
    void CoreAudioSoundSystem::play(Sound * sound)
    {
        if (m_soundMode == AE_SOUND_OFF || (m_soundMode == AE_SOUND_IDLE && m_streamsPlaying)
            || (m_isSuspended && !m_softSuspend))
            return;

        NIIf * samples = ((CoreAudioSound *)sound)->GetSamples();
        if (!samples && !m_Initialized)
            return;

        /* add the sound to the play list */
        CSingleLock soundSampleLock(m_soundSampleLock);
        SoundState ss =
        {
            ((CoreAudioSound*)sound),
            samples,
            ((CoreAudioSound*)sound)->GetSampleCount()
        };
        m_playing_sounds.push_back(ss);
    }
    //------------------------------------------------------------------------
    void CoreAudioSoundSystem::stop(Sound * sound)
    {
        CSingleLock lock(m_soundSampleLock);
        SoundStateList::iterator i, iend = m_playing_sounds.end();
        for (i = m_playing_sounds.begin(); i != iend; )
        {
            if ((*i).owner == sound)
            {
                (*i).owner->ReleaseSamples();
                i = m_playing_sounds.erase(i);
            }
            else
                ++i;
        }
    }
    //------------------------------------------------------------------------
    Sound * CoreAudioSoundSystem::create(const String & file)
    {
        // we don't make sounds
        // when suspended
        if (m_isSuspended)
            return NULL;

        CSingleLock soundLock(m_soundLock);

        // first check if we have the file cached
        SoundList::iterator i, iend = m_sounds.end();
        for (i = m_sounds.begin(); i != iend; ++i)
        {
            if ((*i)->GetFileName() == file)
            return *i;
        }

        CoreAudioSound * sound = new CoreAudioSound(file);
        if (!sound->Initialize())
        {
            delete sound;
            return NULL;
        }

        m_sounds.push_back(sound);
        return sound;
    }
    //------------------------------------------------------------------------
    void CoreAudioSoundSystem::destroy(Sound * sound)
    {
        if (!sound)
            return;

        sound->Stop();
        CSingleLock soundLock(m_soundLock);
        SoundList::iterator i, iend = m_sounds.end();
        for (i = m_sounds.begin(); i != iend; ++i)
        {
            if (*i == sound)
            {
                m_sounds.erase(i);
                break;
            }
        }
        delete (CoreAudioSound *)sound;
    }
    //------------------------------------------------------------------------
    void CoreAudioSoundSystem::StopAllSounds()
    {
        CSingleLock lock(m_soundSampleLock);
        while (!m_playing_sounds.empty())
        {
            SoundState * ss = &(*m_playing_sounds.begin());
            m_playing_sounds.pop_front();
            ss->owner->ReleaseSamples();
        }
    }
    //------------------------------------------------------------------------
    void CoreAudioSoundSystem::softMixer(NIIf * buffer, NCount samples)
    {
        if (!m_Initialized)
            return;

        SoundStateList::iterator it, itend = m_playing_sounds.end();

        CSingleLock lock(m_soundSampleLock);

        for (it = m_playing_sounds.begin(); it != itend; )
        {
            SoundState * ss = &(*it);

            // no more frames, so remove it from the list
            if (ss->sampleCount == 0)
            {
                ss->owner->ReleaseSamples();
                it = m_playing_sounds.erase(it);
                continue;
            }

            NCount mixSamples = std::min(ss->sampleCount, samples);
            NIIf volume = ss->owner->getVol();

            for (NCount i = 0; i < mixSamples; ++i)
                buffer[i] = (buffer[i] + (ss->samples[i] * volume));

            ss->sampleCount -= mixSamples;
            ss->samples += mixSamples;

            ++it;
        }
    }
    //------------------------------------------------------------------------
    void CoreAudioSoundSystem::update()
    {
#if defined(TARGET_DARWIN_OSX)
        if (g_advancedSettings.m_streamSilence)
            return;

        if (!m_streamsPlaying && m_playing_sounds.empty())
        {
            if (!m_softSuspend)
            {
                m_softSuspend = true;
                m_softSuspendTimer = XbmcThreads::SystemClockMillis() + 10000; //10.0 second delay for softSuspend
            }
        }
        else
        {
            if (m_isSuspended)
            {
                CSingleLock engineLock(m_engineLock);
                CLog::Log(LOGDEBUG, "CoreAudioSoundSystem::update - Acquire CA HAL.");
                Start();
                m_isSuspended = false;
            }
            m_softSuspend = false;
        }

        NCount curSystemClock = XbmcThreads::SystemClockMillis();
        if (!m_isSuspended && m_softSuspend && curSystemClock > m_softSuspendTimer)
        {
            pause();// locks m_engineLock internally
            CLog::Log(LOGDEBUG, "CoreAudioSoundSystem::update - Release CA HAL.");
        }
#endif // TARGET_DARWIN_OSX
    }
    //------------------------------------------------------------------------
    void CoreAudioSoundSystem::enumDev(AEDeviceList &devices, bool passthrough)
    {
        if (m_isSuspended && !m_softSuspend)
            return;

        HAL->EnumerateOutputDevices(devices, passthrough);
    }
    //------------------------------------------------------------------------
    void CoreAudioSoundSystem::Start()
    {
        if (!m_Initialized)
            return;

        HAL->Start();
    }
    //------------------------------------------------------------------------
    void CoreAudioSoundSystem::Stop()
    {
        if (!m_Initialized)
            return;

        HAL->Stop();
    }
    //------------------------------------------------------------------------
    bool CoreAudioSoundSystem::pause()
    {
        CSingleLock engineLock(m_engineLock);
        CLog::Log(LOGDEBUG, "CoreAudioSoundSystem::pause - Suspending AE processing");
        m_isSuspended = true;
        // stop all gui sounds
        StopAllSounds();
        // stop the CA thread
        Stop();

        return true;
    }
    //------------------------------------------------------------------------
    bool CoreAudioSoundSystem::resume()
    {
        // fire up the engine again
        bool ret = startup();
        CLog::Log(LOGDEBUG, "CoreAudioSoundSystem::resume - Resuming AE processing");
        m_isSuspended = false;

        return ret;
    }
    //------------------------------------------------------------------------
    // Rendering Methods
    //------------------------------------------------------------------------
    OSStatus CoreAudioSoundSystem::OnRender(AudioUnitRenderActionFlags * flags,
        const AudioTimeStamp * time, UInt32 bus, UInt32 frames,
            AudioBufferList * data)
    {
        NCount rSamples = frames * m_chLayoutCount;
        int size = frames * m_format.m_frameSize;
        //int size = frames * HAL->m_BytesPerFrame;

        for (UInt32 i = 0; i < data->mNumberBuffers; ++i)
            bzero(data->mBuffers[i].mData, data->mBuffers[i].mDataByteSize);

        if (!m_Initialized)
        {
            m_callbackRunning = false;
            return noErr;
        }

        CSingleLock callbackLock(m_callbackLock);

        m_callbackRunning = true;

        /*
        CSingleLock streamLock(m_streamLock);
        // Remove any destroyed stream
        if (!m_streams.empty())
        {
            for(StreamList::iterator itt = m_streams.begin(); itt != m_streams.end();)
            {
                CoreAudioSoundStream *stream = *itt;

                if (stream->IsDestroyed())
                {
                    itt = m_streams.erase(itt);
                    delete stream;
                    continue;
                }
                ++itt;
            }
        }
        streamLock.Leave();
        */

        // when not in passthrough output mix sounds
        if (!m_rawPassthrough && m_soundMode != AE_SOUND_OFF)
        {
            softMixer((NIIf *)data->mBuffers[0].mData, rSamples);
            data->mBuffers[0].mDataByteSize = size;
            if (!size && flags)
            *flags |=  kAudioUnitRenderAction_OutputIsSilence;
        }

        m_callbackRunning = false;

        return noErr;
    }
    //------------------------------------------------------------------------
    // Static Callback from AudioUnit
    OSStatus CoreAudioSoundSystem::Render(AudioUnitRenderActionFlags * flags,
        const AudioTimeStamp * time, UInt32 bus, UInt32 frames, AudioBufferList * data)
    {
        OSStatus ret = OnRender(flags, time, bus, frames, data);

        return ret;
    }
    //-----------------------------------------------------------------------
}
}