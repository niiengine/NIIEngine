/*
-----------------------------------------------------------------------------
���Ͷ�ý����

ʱ��: 2014-5-7

�ı�����: utf-8

������˾: �������ǿƼ����޹�˾

�������: ����������

��̷��: ͳ��ʽ

����ģʽ: �ֲ�ʽ

�ڲ��ɷ�: UI���� ������� ��Ƶ���� �������� �¼���������(��ɢ�����)

��Ҫ�ɷ�: c++(80%) c(20%)

��;: ����ϵͳ����(��Χ����ϵͳ�ں�api)
      ��άӦ������
        ������Ϣϵͳ����(GIS)
        ��Ӱ���������ع�����
        ������Ϸ����

ƫ����;: ������Ϸ����

��ҳ: www.niiengine.com ��������: niiengine@gmail.com OR niiengine@163.com

��Ȩ��ʽ:��ҵ��Ȩ(www.niiengine.com/license)(3��)
------------------------------------------------------------------------------
*/

#include "NiiPreProcess.h"
#include "NiiPulseSoundStream.h"

#include "AEFactory.h"
#include "Utils/AEUtil.h"
#include "utils/log.h"
#include "utils/MathUtils.h"
#include "threads/SingleLock.h"

namespace NII
{
namespace NII_MEDIA
{
    //-----------------------------------------------------------------------
    static const char * StreamStateToString(pa_stream_state s)
    {
        switch(s)
        {
        case PA_STREAM_UNCONNECTED:
            return "unconnected";
        case PA_STREAM_CREATING:
            return "creating";
        case PA_STREAM_READY:
            return "ready";
        case PA_STREAM_FAILED:
            return "failed";
        case PA_STREAM_TERMINATED:
            return "terminated";
        default:
            return "none";
        }
    }
    //-----------------------------------------------------------------------
    PulseSoundStream::PulseSoundStream(pa_context * context,
        pa_threaded_mainloop * mainLoop,  SampleFormat format,
            NCount sampleRate, AudioChannel channelLayout, NCount options) :
                mFader(this)
    {
        ASSERT(channelLayout.Count());
        mDestroy = false;
        mInit = false;
        mPause = false;
        mResumeCB = false;

        mStream = NULL;
        mContext = context;
        m_MainLoop = mainLoop;

        mFormat = format;
        mSampleRate = sampleRate;
        mChLayout = channelLayout;
        mOptions = options;

        mStopOP = NULL;
        mNext = NULL;

        pa_threaded_mainloop_lock(m_MainLoop);

        mSampleFormat.channels = channelLayout.Count();
        mSampleFormat.rate = mSampleRate;

        switch (mFormat)
        {
        case SF_U8:
            mSampleFormat.format = PA_SAMPLE_U8;
            break;
        case SF_S16:
            mSampleFormat.format = PA_SAMPLE_S16NE;
            break;
        case SF_S16L:
            mSampleFormat.format = PA_SAMPLE_S16LE;
            break;
        case SF_S16B:
            mSampleFormat.format = PA_SAMPLE_S16BE;
            break;
        case SF_S24W3:
            mSampleFormat.format = PA_SAMPLE_S24NE;
            break;
        case SF_S24:
            mSampleFormat.format = PA_SAMPLE_S24_32NE;
            break;
        case SF_S32:
            mSampleFormat.format = PA_SAMPLE_S32NE;
            break;
        case SF_S32L:
            mSampleFormat.format = PA_SAMPLE_S32LE;
            break;
        case SF_S32B:
            mSampleFormat.format = PA_SAMPLE_S32BE;
            break;
        case SF_F:
            mSampleFormat.format = PA_SAMPLE_FLOAT32NE;
            break;
#if PA_CHECK_VERSION(1,0,0)
        case SFE_DTS:
        case SFE_EAC3:
        case SFE_AC3:
            mSampleFormat.format = PA_SAMPLE_S16NE;
            break;
#endif
        default:
            CLog::Log(LOGERROR, "PulseAudio: Invalid format %i", format);
            pa_threaded_mainloop_unlock(m_MainLoop);
            mFormat = SF_Unknow;
            return;
        }

        if (!pa_sample_spec_valid(&mSampleFormat))
        {
            CLog::Log(LOGERROR, "PulseAudio: Invalid sample spec");
            pa_threaded_mainloop_unlock(m_MainLoop);
            Destroy();
            return /*false*/;
        }

        mFrameSize = pa_frame_size(&mSampleFormat);

        struct pa_channel_map map;
        map.channels = mChLayout.Count();

        for (NCount ch = 0; ch < mChLayout.Count(); ++ch)
        {
            switch(mChLayout[ch])
            {
            case ACT_Unknow: break;
            case ACT_RAW: break;
            case ACT_FL:
                map.map[ch] = PA_CHANNEL_POSITION_FRONT_LEFT;
                break;
            case ACT_FR:
                map.map[ch] = PA_CHANNEL_POSITION_FRONT_RIGHT;
                break;
            case ACT_FC:
                map.map[ch] = PA_CHANNEL_POSITION_FRONT_CENTER;
                break;
            case ACT_BC:
                map.map[ch] = PA_CHANNEL_POSITION_REAR_CENTER;
                break;
            case ACT_BL:
                map.map[ch] = PA_CHANNEL_POSITION_REAR_LEFT;
                break;
            case ACT_BR:
                map.map[ch] = PA_CHANNEL_POSITION_REAR_RIGHT;
                break;
            case ACT_LEF:
                map.map[ch] = PA_CHANNEL_POSITION_LFE;
                break;
            case ACT_FLOC:
                map.map[ch] = PA_CHANNEL_POSITION_FRONT_LEFT_OF_CENTER;
                break;
            case ACT_FROC:
                map.map[ch] = PA_CHANNEL_POSITION_FRONT_RIGHT_OF_CENTER;
                break;
            case ACT_SL:
                map.map[ch] = PA_CHANNEL_POSITION_SIDE_LEFT;
                break;
            case ACT_SR:
                map.map[ch] = PA_CHANNEL_POSITION_SIDE_RIGHT;
                break;
            case ACT_TC:
                map.map[ch] = PA_CHANNEL_POSITION_TOP_CENTER;
                break;
            case ACT_TFL:
                map.map[ch] = PA_CHANNEL_POSITION_TOP_FRONT_LEFT;
                break;
            case ACT_TFR:
                map.map[ch] = PA_CHANNEL_POSITION_TOP_FRONT_RIGHT;
                break;
            case ACT_TFC:
                map.map[ch] = PA_CHANNEL_POSITION_TOP_CENTER;
                break;
            case ACT_TBL:
                map.map[ch] = PA_CHANNEL_POSITION_TOP_REAR_LEFT;
                break;
            case ACT_TBR:
                map.map[ch] = PA_CHANNEL_POSITION_TOP_REAR_RIGHT;
                break;
            case ACT_TBC:
                map.map[ch] = PA_CHANNEL_POSITION_TOP_REAR_CENTER;
                break;
            default: break;
            }
        }
        mMaxVol = CAEFactory::GetEngine()->getVol();
        mVol = 1.0f;
        pa_volume_t paVolume = pa_sw_volume_from_linear((NIId)(mVol * mMaxVol));
        pa_cvolume_set(&mChVol, mSampleFormat.channels, paVolume);

#if PA_CHECK_VERSION(1,0,0)
        pa_format_info *info[1];
        info[0] = pa_format_info_new();
        switch(mFormat)
        {
        case SFE_DTS:
            info[0]->encoding = PA_ENCODING_DTS_IEC61937;
            break;
        case SFE_EAC3:
            info[0]->encoding = PA_ENCODING_EAC3_IEC61937;
            break;
        case SFE_AC3:
            info[0]->encoding = PA_ENCODING_AC3_IEC61937;
            break;
        default:
            info[0]->encoding = PA_ENCODING_PCM;
            break;
        }
        pa_format_info_set_rate(info[0], mSampleFormat.rate);
        pa_format_info_set_channels(info[0], mSampleFormat.channels);
        pa_format_info_set_channel_map(info[0], &map);
        pa_format_info_set_sample_format(info[0], mSampleFormat.format);
        mStream = pa_stream_new_extended(mContext, "audio stream", info, 1, NULL);
        pa_format_info_free(info[0]);
#else
        mStream = pa_stream_new(mContext, "audio stream", &mSampleFormat, &map);
#endif
        if (mStream == NULL)
        {
            CLog::Log(LOGERROR, "PulseAudio: Could not create a stream");
            pa_threaded_mainloop_unlock(m_MainLoop);
            Destroy();
            return /*false*/;
        }

        pa_stream_set_state_callback(mStream, PulseSoundStream::StreamStateCallback, this);
        pa_stream_set_write_callback(mStream, PulseSoundStream::StreamRequestCallback, this);
        pa_stream_set_latency_update_callback(mStream, PulseSoundStream::StreamLatencyUpdateCallback, this);
        pa_stream_set_underflow_callback(mStream, PulseSoundStream::StreamUnderflowCallback, this);

        int flags = PA_STREAM_INTERPOLATE_TIMING | PA_STREAM_AUTO_TIMING_UPDATE;
        if (options && AESTREAM_FORCE_RESAMPLE)
            flags |= PA_STREAM_VARIABLE_RATE;

        if (pa_stream_connect_playback(mStream, NULL, NULL, (pa_stream_flags)flags, &mChVol, NULL) < 0)
        {
            CLog::Log(LOGERROR, "PulseAudio: Failed to connect stream to output");
            pa_threaded_mainloop_unlock(m_MainLoop);
            Destroy();
            return /*false*/;
        }

        /* Wait until the stream is ready */
        do
        {
            pa_threaded_mainloop_wait(m_MainLoop);
            CLog::Log(LOGDEBUG, "PulseAudio: Stream %s", StreamStateToString(pa_stream_get_state(mStream)));
        }
        while(pa_stream_get_state(mStream) != PA_STREAM_READY && pa_stream_get_state(mStream) != PA_STREAM_FAILED);

        if (pa_stream_get_state(mStream) == PA_STREAM_FAILED)
        {
            CLog::Log(LOGERROR, "PulseAudio: Waited for the stream but it failed");
            pa_threaded_mainloop_unlock(m_MainLoop);
            Destroy();
            return /*false*/;
        }

        const pa_buffer_attr * streamBuffer;
        streamBuffer = pa_stream_get_buffer_attr(mStream);
        mCacheSize = streamBuffer->maxlength;

        pa_threaded_mainloop_unlock(m_MainLoop);

        mInit = true;

        CLog::Log(LOGINFO, "PulseAEStream::Initialized");
        CLog::Log(LOGINFO, "  Sample Rate   : %d", mSampleRate);
        CLog::Log(LOGINFO, "  Sample Format : %s", CAEUtil::DataFormatToStr(mFormat));
        CLog::Log(LOGINFO, "  Channel Count : %d", mChLayout.Count());
        CLog::Log(LOGINFO, "  Channel Layout: %s", ((std::string)mChLayout).c_str());
        CLog::Log(LOGINFO, "  Frame Size    : %d", mFrameSize);
        CLog::Log(LOGINFO, "  Cache Size    : %d", mCacheSize);

        resume();

        return /*true*/;
    }
    //-----------------------------------------------------------------------
    PulseSoundStream::~PulseSoundStream()
    {
        Destroy();
    }
    //-----------------------------------------------------------------------
    /*
      this method may be called inside the pulse main loop,
      so be VERY careful with locking
    */
    void PulseSoundStream::Destroy()
    {
        if(!mInit)
            return;

        if(mDestroy)
            return;

        mFader.StopThread(true);

        pa_threaded_mainloop_lock(m_MainLoop);

        if (mStopOP)
        {
            pa_operation_cancel(mStopOP);
            pa_operation_unref(mStopOP);
            mStopOP = NULL;
        }

        if (mStream)
        {
            pa_stream_set_state_callback(mStream, NULL, NULL);
            pa_stream_set_write_callback(mStream, NULL, NULL);
            pa_stream_set_latency_update_callback(mStream, NULL, NULL);
            pa_stream_set_underflow_callback(mStream, NULL, NULL);
            pa_stream_disconnect(mStream);
            pa_stream_unref(mStream);
            mStream = NULL;
        }

        /* signal PulseSoundSystem to free us */
        mDestroy = true;
        mInit = false;

        pa_threaded_mainloop_unlock(m_MainLoop);
    }
    //-----------------------------------------------------------------------
    NCount PulseSoundStream::getValidSize()
    {
        if (!mInit)
            return 0;

        pa_threaded_mainloop_lock(m_MainLoop);
        NCount size = pa_stream_writable_size(mStream);
        pa_threaded_mainloop_unlock(m_MainLoop);

        if(size > mCacheSize)
            mCacheSize = size;

        return size;
    }
    //-----------------------------------------------------------------------
    NCount PulseSoundStream::add(void * data, NCount size)
    {
        if (!mInit)
            return size;

        pa_threaded_mainloop_lock(m_MainLoop);

        int length = std::min((int)pa_stream_writable_size(mStream), (int)size);
        if (length == 0)
        {
            pa_threaded_mainloop_unlock(m_MainLoop);
            return 0;
        }

        int written = pa_stream_write(mStream, data, length, NULL, 0, PA_SEEK_RELATIVE);
        pa_threaded_mainloop_unlock(m_MainLoop);

        if (written < 0)
        {
            CLog::Log(LOGERROR, "PulseAudio: AddPackets - pa_stream_write failed\n");
            return 0;
        }

        return length;
    }
    //-----------------------------------------------------------------------
    NIId PulseSoundStream::getDataWait()
    {
        if (!mInit)
            return 0.0;

        pa_usec_t latency = 0;
        pa_threaded_mainloop_lock(m_MainLoop);

        if (pa_stream_get_latency(mStream, &latency, NULL) == PA_ERR_NODATA)
            CLog::Log(LOGERROR, "PulseAudio: pa_stream_get_latency() failed");

        pa_threaded_mainloop_unlock(m_MainLoop);
        return (NIId)((NIId)latency / 1000000.0);
    }
    //-----------------------------------------------------------------------
    NIId PulseSoundStream::getRemainTime()
    {
        if (!mInit)
            return 0.0;

        return (NIId)(mCacheSize - getValidSize()) / (NIId)(mSampleRate * mFrameSize);
    }
    //-----------------------------------------------------------------------
    NIId PulseSoundStream::getCapacityTime()
    {
        if (!mInit)
            return 0.0;

        return (NIId)mCacheSize / (NIId)(mSampleRate * mFrameSize);
    }
    //-----------------------------------------------------------------------
    bool PulseSoundStream::IsPaused()
    {
        return mPause;
    }
    //-----------------------------------------------------------------------
    bool PulseSoundStream::IsDraining()
    {
        if (mStopOP)
        {
            if (pa_operation_get_state(mStopOP) == PA_OPERATION_RUNNING)
                return true;

            pa_operation_unref(mStopOP);
            mStopOP = NULL;
        }
        ProcessCallbacks();
        return false;
    }
    //-----------------------------------------------------------------------
    bool PulseSoundStream::isStop()
    {
        bool ret = (mStopOP == NULL);
        ProcessCallbacks();

        return ret;
    }
    //-----------------------------------------------------------------------
    bool PulseSoundStream::IsDestroyed()
    {
        return mDestroy;
    }
    //-----------------------------------------------------------------------
    void PulseSoundStream::pause()
    {
        if (mInit)
            mPause = Cork(true);
    }
    //-----------------------------------------------------------------------
    void PulseSoundStream::resume()
    {
        if (mInit)
            mPause = Cork(false);
    }
    //-----------------------------------------------------------------------
    void PulseSoundStream::stop()
    {
        if (!mInit)
            return;

        if (mStopOP)
            return;

        pa_threaded_mainloop_lock(m_MainLoop);
        mStopOP = pa_stream_drain(mStream, PulseSoundStream::StreamDrainComplete, this);
        pa_threaded_mainloop_unlock(m_MainLoop);
    }
    //-----------------------------------------------------------------------
    void PulseSoundStream::clear()
    {
        if (!mInit)
            return;

        pa_threaded_mainloop_lock(m_MainLoop);
        pa_operation_unref(pa_stream_flush(mStream, NULL, NULL));
        pa_threaded_mainloop_unlock(m_MainLoop);
    }
    //-----------------------------------------------------------------------
    NIIf PulseSoundStream::getVol()
    {
        return mVol;
    }
    //-----------------------------------------------------------------------
    NIIf PulseSoundStream::GetReplayGain()
    {
        return 0.0f;
    }
    //-----------------------------------------------------------------------
    void PulseSoundStream::setVol(NIIf volume)
    {
        if (!mInit)
            return;

        if (!pa_threaded_mainloop_in_thread(m_MainLoop))
            pa_threaded_mainloop_lock(m_MainLoop);

        if (volume > 0.f)
        {
            mVol = volume;
            pa_volume_t paVolume = pa_sw_volume_from_linear((NIId)(mVol * mMaxVol));

            pa_cvolume_set(&mChVol, mSampleFormat.channels, paVolume);
        }
        else
            pa_cvolume_mute(&mChVol,mSampleFormat.channels);

        pa_operation *op = pa_context_set_sink_input_volume(mContext, pa_stream_get_index(mStream), &mChVol, NULL, NULL);

        if (op == NULL)
            CLog::Log(LOGERROR, "PulseAudio: Failed to set volume");
        else
            pa_operation_unref(op);

        if (!pa_threaded_mainloop_in_thread(m_MainLoop))
            pa_threaded_mainloop_unlock(m_MainLoop);
    }
    //-----------------------------------------------------------------------
    void PulseSoundStream::UpdateVolume(NIIf max)
    {
        if (!mInit)
            return;

        mMaxVol = max;
        setVol(mVol);
    }
    //-----------------------------------------------------------------------
    void PulseSoundStream::setMute(bool mute)
    {
        if (mute)
            setVol(-1.f);
        else
            setVol(mVol);
    }
    //-----------------------------------------------------------------------
    void PulseSoundStream::SetReplayGain(NIIf factor)
    {
        // nothing
    }
    //-----------------------------------------------------------------------
    NCount PulseSoundStream::getFrameSize() const
    {
        return mFrameSize;
    }
    //-----------------------------------------------------------------------
    NCount PulseSoundStream::getChannelCount() const
    {
        return mChLayout.Count();
    }
    //-----------------------------------------------------------------------
    NCount PulseSoundStream::getSampleRate() const
    {
        return mSampleRate;
    }
    //-----------------------------------------------------------------------
    SampleFormat PulseSoundStream::getSampleFormat() const
    {
        return mFormat;
    }
    //-----------------------------------------------------------------------
    NIId PulseSoundStream::getResampleFactor()
    {
        return 1.0;
    }
    //-----------------------------------------------------------------------
    bool PulseSoundStream::setResampleFactor(NIId ratio)
    {
        return false;
    }
    //-----------------------------------------------------------------------
    void PulseSoundStream::add(IAudioCallback * lis)
    {
        mAudioCB = lis;
    }
    //-----------------------------------------------------------------------
    void PulseSoundStream::remove(IAudioCallback * lis)
    {
        mAudioCB = NULL;
    }
    //-----------------------------------------------------------------------
    void PulseSoundStream::rollOff(NIIf from, NIIf target, NCount time)
    {
        if (!mInit)
            return;

        mFader.SetupFader(from, target, time);
    }
    //-----------------------------------------------------------------------
    bool PulseSoundStream::isRollOff()
    {
        return mFader.IsRunning();
    }
    //-----------------------------------------------------------------------
    void PulseSoundStream::StreamRequestCallback(pa_stream *s, NCount length,
        void * data)
    {
        PulseSoundStream * stream = (PulseSoundStream *)data;
        pa_threaded_mainloop_signal(stream->m_MainLoop, 0);
    }
    //-----------------------------------------------------------------------
    void PulseSoundStream::StreamLatencyUpdateCallback(pa_stream *s, void * data)
    {
        PulseSoundStream * stream = (PulseSoundStream *)data;
        pa_threaded_mainloop_signal(stream->m_MainLoop, 0);
    }
    //-----------------------------------------------------------------------
    void PulseSoundStream::StreamStateCallback(pa_stream *s, void * data)
    {
        PulseSoundStream * stream = (PulseSoundStream *)data;
        pa_stream_state_t state = pa_stream_get_state(s);

        switch (state)
        {
        case PA_STREAM_UNCONNECTED:
        case PA_STREAM_CREATING:
        case PA_STREAM_READY:
        case PA_STREAM_FAILED:
        case PA_STREAM_TERMINATED:
            pa_threaded_mainloop_signal(stream->m_MainLoop, 0);
            break;
        }
    }
    //-----------------------------------------------------------------------
    void PulseSoundStream::StreamUnderflowCallback(pa_stream *s, void * data)
    {
        PulseSoundStream * stream = (PulseSoundStream *)data;
        CLog::Log(LOGWARNING, "PulseAudio: Stream underflow");
        pa_threaded_mainloop_signal(stream->m_MainLoop, 0);
    }
    //-----------------------------------------------------------------------
    void PulseSoundStream::StreamDrainComplete(pa_stream *s, int success, void * data)
    {
        PulseSoundStream * stream = (PulseSoundStream *)data;
        if(stream)
        {
            stream->SetDrained();
            pa_threaded_mainloop_signal(stream->m_MainLoop, 0);
        }
    }
    //-----------------------------------------------------------------------
    void PulseSoundStream::ProcessCallbacks()
    {
        if(mResumeCB && mNext)
            mNext->resume();

        mResumeCB = false;
    }
    //-----------------------------------------------------------------------
    inline bool PulseSoundStream::WaitForOperation(pa_operation * op,
        pa_threaded_mainloop * mainloop, const char * LogEntry = "")
    {
        if (op == NULL)
            return false;

        bool sucess = true;
        ASSERT(!pa_threaded_mainloop_in_thread(mainloop));

        while (pa_operation_get_state(op) == PA_OPERATION_RUNNING)
            pa_threaded_mainloop_wait(mainloop);

        if (pa_operation_get_state(op) != PA_OPERATION_DONE)
        {
            CLog::Log(LOGERROR, "PulseAudio: %s Operation failed", LogEntry);
            sucess = false;
        }

        pa_operation_unref(op);
        return sucess;
    }
    //-----------------------------------------------------------------------
    bool PulseSoundStream::Cork(bool cork)
    {
        pa_threaded_mainloop_lock(m_MainLoop);

        pa_operation * op = pa_stream_cork(mStream, cork ? 1 : 0, NULL, NULL);
        if (!WaitForOperation(op, m_MainLoop, cork ? "pause" : "resume"))
            cork = !cork;

        pa_threaded_mainloop_unlock(m_MainLoop);
        return cork;
    }
    //-----------------------------------------------------------------------
    void PulseSoundStream::setNext(SoundStream * stream)
    {
        mNext = stream;
    }
    //-----------------------------------------------------------------------
    PulseSoundStream::CLinearFader::CLinearFader(SoundStream * stream) :
        CThread("AE Stream"),
        mStream(stream)
    {
        mSrc = 0;
        mDest = 0;
        mTime = 0;
        mRun = false;
    }
    //-----------------------------------------------------------------------
    void PulseSoundStream::CLinearFader::SetupFader(NIIf from, NIIf target,
        NCount time)
    {
        StopThread(true);

        mSrc = from;
        mDest = target;
        mTime = time;

        if (mTime > 0)
            Create();
        else
            mStream->setVol(mDest);
    }
    //-----------------------------------------------------------------------
    void PulseSoundStream::CLinearFader::Process()
    {
        if (mStream == NULL)
            return;

        mRun = true;
        mStream->setVol(mSrc);
        NIIf k = mDest - mSrc;

        NCount begin = XbmcThreads::SystemClockMillis();
        NCount end = begin + mTime;
        NCount current = begin;
        NCount step = std::max(1u, mTime / 100);

        do
        {
            NIIf x = ((NIIf)current - (NIIf)begin) / (NIIf)mTime;

            mStream->setVol(mSrc + k * x);
            usleep(step * 1000);
            current = XbmcThreads::SystemClockMillis();
        } while (current <= end && !m_bStop);

        mStream->setVol(mDest);
        mRun = false;
    }
    //-----------------------------------------------------------------------
    bool PulseSoundStream::CLinearFader::IsRunning()
    {
        return !mRun;
    }
    //-----------------------------------------------------------------------
}
}