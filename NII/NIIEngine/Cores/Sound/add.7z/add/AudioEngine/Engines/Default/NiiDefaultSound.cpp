/*
-----------------------------------------------------------------------------
���Ͷ�ý����

ʱ��: 2014-5-7

�ı�����: utf-8

������˾: �������ǿƼ����޹�˾

�������: ����������

��̷��: ͳ��ʽ

����ģʽ: �ֲ�ʽ

�ڲ��ɷ�: UI���� ������� ��Ƶ���� �������� �¼���������(��ɢ�����)

��Ҫ�ɷ�: c++(80%) c(20%)

��;: ����ϵͳ����(��Χ����ϵͳ�ں�api)
      ��άӦ������
        ������Ϣϵͳ����(GIS)
        ��Ӱ���������ع�����
        ������Ϸ����

ƫ����;: ������Ϸ����

��ҳ: www.niiengine.com ��������: niiengine@gmail.com OR niiengine@163.com

��Ȩ��ʽ:��ҵ��Ȩ(www.niiengine.com/license)(3��)
------------------------------------------------------------------------------
*/

#include "NiiPreProcess.h"
#include "NiiSound.h"

#include <samplerate.h>
#include "threads/SingleLock.h"
#include "utils/log.h"
#include "utils/EndianSwap.h"

#include "AEFactory.h"
#include "NiiAudioFormat.h"

#include "NiiDefaultSoundSystem.h"
#include "NiiDefaultSound.h"

/* typecast AE to DefaultSoundSystem */
#define AE (*((DefaultSoundSystem*)CAEFactory::GetEngine()))

namespace NII
{
namespace NII_MEDIA
{
    //------------------------------------------------------------------------
    DefaultSound::DefaultSound(const String & file) :
        Sound(file),
        mFile(file),
        mVol(1.0f),
        mUse(0)
    {
        mWavLoader.Load(file);
    }
    //------------------------------------------------------------------------
    DefaultSound::~DefaultSound()
    {
    }
    //------------------------------------------------------------------------
    bool DefaultSound::Initialize()
    {
        if (!mWavLoader.IsValid())
            return false;

        return mWavLoader.Initialize(AE.GetSampleRate(), AE.GetChannelLayout(),
            AE.GetStdChLayout());
    }
    //------------------------------------------------------------------------
    void DefaultSound::DeInitialize()
    {
    }
    //------------------------------------------------------------------------
    bool DefaultSound::IsCompatible()
    {
        if (!mWavLoader.IsValid())
            return false;

        return mWavLoader.IsCompatible(AE.GetSampleRate(), AE.GetChannelLayout());
    }
    //------------------------------------------------------------------------
    void DefaultSound::play()
    {
        AE.play(this);
    }
    //------------------------------------------------------------------------
    void DefaultSound::stop()
    {
        AE.play(this);
    }
    //------------------------------------------------------------------------
    unsigned int DefaultSound::GetSampleCount()
    {
        CSingleLock cs(mLock);
        if (mWavLoader.IsValid())
            return mWavLoader.GetSampleCount();
        return 0;
    }
    //------------------------------------------------------------------------
    NIIf * DefaultSound::GetSamples()
    {
        CSingleLock cs(mLock);
        if (!mWavLoader.IsValid())
            return NULL;

        ++mUse;
        return mWavLoader.GetSamples();
    }
    //------------------------------------------------------------------------
    void DefaultSound::ReleaseSamples()
    {
        CSingleLock cs(mLock);
        ASSERT(mUse > 0);
        --mUse;
    }
    //------------------------------------------------------------------------
    bool DefaultSound::isPlay()
    {
        CSingleLock cs(mLock);
        return (mUse > 0);
    }
    //------------------------------------------------------------------------
    void DefaultSound::setVol(NIIf vol)
    {
        mVol = std::max(0.0f, std::min(1.0f, vol));
    }
    //------------------------------------------------------------------------
    NIIf DefaultSound::getVol()
    {
        return mVol;
    }
    //------------------------------------------------------------------------
    void DefaultSound::setPos(const Vector3f & pos)
    {
    }
    //------------------------------------------------------------------------
    void DefaultSound::getPos(Vector3f & pos) const
    {
    }
    //------------------------------------------------------------------------
    void DefaultSound::setVel(const Vector3f & vel)
    {
    }
    //------------------------------------------------------------------------
    void DefaultSound::getVel(Vector3f & vel) const
    {
    }
    //------------------------------------------------------------------------
    void DefaultSound::setDir(const Vector3f & dir)
    {
    }
    //------------------------------------------------------------------------
    void DefaultSound::getDir(Vector3f & dir) const
    {

    }
    //------------------------------------------------------------------------
}
