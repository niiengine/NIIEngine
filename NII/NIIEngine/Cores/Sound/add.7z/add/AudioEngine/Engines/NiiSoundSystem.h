/*
-----------------------------------------------------------------------------
���Ͷ�ý����

ʱ��: 2014-5-8

�ı�����: utf-8

������˾: �������ǿƼ����޹�˾

�������: ����������

��̷��: ͳ��ʽ

����ģʽ: �ֲ�ʽ

�ڲ��ɷ�: UI���� ������� ��Ƶ���� �������� �¼���������(��ɢ�����)

��Ҫ�ɷ�: c++(80%) c(20%)

��;: ����ϵͳ����(��Χ����ϵͳ�ں�api)
      ��άӦ������
        ��������������������(CAD)
        ������Ϣϵͳ����(GIS)
        ��Ӱ���������ع�����
        ������Ϸ����

ƫ����;: ������Ϸ����

��ҳ: www.niiengine.com ��������: niiengine@gmail.com OR niiengine@163.com

��Ȩ��ʽ:��ҵ��Ȩ(www.niiengine.com/license)(3��)
------------------------------------------------------------------------------
*/

#ifndef _NII_SOUND_SYSTEM_H_
#define _NII_SOUND_SYSTEM_H_

#include "NiiPreInclude.h"

#include "threads/CriticalSection.h"
#include "NiiAudioFormat.h"

namespace NII
{
namespace NII_MEDIA
{
    typedef std::pair<String, String> AEDevice;
    typedef std::vector<AEDevice> AEDeviceList;

    /* forward declarations */
    class SoundStream;
    class Sound;
    class IAEPacketizer;

    /* sound options */
    #define AE_SOUND_OFF    0 /* disable sounds */
    #define AE_SOUND_IDLE   1 /* only play sounds while no streams are running */
    #define AE_SOUND_ALWAYS 2 /* always play sounds */

    /** ��Ƶϵͳ
    @remark ��Ϊ�豸����Ƶϵͳ��ϵͳ����Ƶϵͳ
    */
    class SoundSystem
    {
        friend class CAEFactory;
    public:
        /** ��ʼ������ϵͳ
        @param[out]
        @param[out]
        */
        virtual bool startup(VoiceFormat & format, String & device) = 0;

        /** �ر�����ϵͳ
        */
        virtual void shutdown() = 0;

        /** ���ָ�����Ÿ�ʽ�Ͳ����豸�뵱ǰƥ��
        @remark
        @param[in] vf
        @param[in] device
        */
        virtual bool check(VoiceFormat vf, String device) = 0;

        /** ö�ٳ���Ƶ�豸
        @param[out] devs
        @param[in] force
        */
        virtual void enumDev(AEDeviceInfoList & devs, bool force = false) const;

        /**
        @remark
        */
        virtual void play(Sound * sound);

        /**
        @remark
        */
        virtual void pause(Sound * sound);

        /**
        @remark
        */
        virtual void resume(Sound * sound);

        /**
        @remark
        */
        virtual void stop(Sound * sound);

        /**
        @remark
        */
        virtual void play(SoundStream * stream);

        /**
        @remark
        */
        virtual void pause(SoundStream * stream);

        /**
        @remark
        */
        virtual void resume(SoundStream * stream);

        /**
        @remark
        */
        virtual void stop(SoundStream * stream);

        /*
        This method returns the time in seconds that it will take
        for the next added packet to be heard from the speakers.
        */
        virtual NIId getDataWait() = 0;

        /*
        This method returns the time in seconds that it will take
        to underrun the cache if no sample is added.
        */
        virtual NIId getRemainTime() = 0;

        /*
        This method returns the total time in seconds of the cache.
        */
        virtual NIId getCapacityTime() = 0;

        /*
        Adds packets to be sent out, this routine MUST block or sleep.
        */
        virtual NCount AddPackets(uint8_t * data, NCount frames, bool hasAudio) = 0;

        /*
        Drain the sink
        */
        virtual void Drain() {};

        /*
        Indicates if sink can handle volume control.
        */
        virtual bool HasVolume() {return false;};

        /*
        This method sets the volume control, volume ranges from 0.0 to 1.0.
        */
        virtual void SetVolume(NIIf volume) {};

        /*
        Requests sink to plan itself for a suspend state
        @return false if sink cannot be suspended
        */
        virtual bool SoftSuspend() {return false;};

        /*
        Notify sink to plan to resume processing after suspend state
        @return false if sink must be reinitialized
        */
        virtual bool SoftResume() {return false;};

        /** Suspends output and de-initializes sink Used to avoid conflicts with
            external players or to reduce power consumption
        @return True if successful
        */
        virtual bool pause() = 0;

        /** Resumes output and re-initializes sink Used to resume output from
            pause() state above
        @return True if successful
        */
        virtual bool resume() = 0;

        /**
        * Callback by CApplication for Garbage Collection. This method is called by CApplication every 500ms and can be used to clean up and free no-longer used resources.
        */
        virtual void update() = 0;

        /** Set the mute state (does not affect volume level value)
        @param set The mute state
        */
        virtual void setMute(bool set) = 0;

        /** Sets the sound mode
        @param mode One of AE_SOUND_OFF, AE_SOUND_IDLE or AE_SOUND_ALWAYS
        */
        virtual void setMode(Nui32 mode) = 0;

        /** Returns the current master volume level of the AudioEngine
        @return The volume level between 0.0 and 1.0
        */
        virtual float getVol() = 0;

        /** Sets the master volume level of the AudioEngine
        @param volume The new volume level between 0.0 and 1.0
        */
        virtual void setVol(float volume) = 0;

        /** Get the current mute state
        @return The current mute state
        */
        virtual bool isMute() = 0;

        /** Get the current pause() state Used by players to determine if audio
            is being processed Default is true so players drop audio or pause
            if engine unloaded
        @return True if processing suspended
        */
        virtual bool isPause();

        /** Creates a new Sound that is ready to play the specified file
        @param file The WAV file to load, this supports XBMC's VFS
        @return A new Sound if the file could be loaded, otherwise NULL
        */
        virtual Sound * create(const String & file) = 0;

        /** Free the supplied Sound object
        @param sound The Sound object to free
        */
        virtual void destroy(Sound * sound) = 0;

        /** Creates and returns a new SoundStream in the format specified, this
            function should never fail
        @param sf The data format the incoming audio will be in (eg, SF_S16L)
        @param sr The sample rate of the audio data (eg, 48000)
        @prarm encodedsr The sample rate of the encoded audio data if AE_IS_RAW(dataFormat)
        @param channelLayout The order of the channels in the audio data
        @param options A bit field of stream options (see: enum AEStreamOptions)
        @return a new SoundStream that will accept data in the requested format
        */
        virtual SoundStream * createStream(enum SampleFormat sf, NCount sr,
                NCount encodedsr, AudioChannel channelLayout, NCount options = 0) = 0;

        /** This method will remove the specifyed stream from the engine.
            For OSX/IOS this is essential to reconfigure the audio output.
        @param stream The stream to be altered
        @return NULL
        */
        virtual SoundStream * destroy(SoundStream * stream) = 0;

        /** Enumerate the supported audio output devices
        @param devices The device list to append supported devices to
        @param passthrough True if only passthrough devices are wanted
        */
        virtual void enumDev(AEDeviceList & devices, bool passthrough) = 0;

        /** Returns the default audio device
        @param passthrough True if the default passthrough device is wanted
        @return the default audio device
        */
        virtual String getDefaultDev(bool passthrough);

        /** Returns true if the AudioEngine supports AE_FMT_RAW streams for
            use with formats such as IEC61937
        @see CAEPackIEC61937::CAEPackIEC61937()
        @returns true if the AudioEngine is capable of RAW output
        */
        virtual bool SupportsRaw();

        /** return the name of this sync for logging
        */
        virtual const char * GetName() = 0;
    public:
        /** Callback to alert the AudioEngine of setting changes
        @param setting The name of the setting that was changed
        */
        virtual void OnSettingsChange(const String & setting);
    protected:
        SoundSystem();
        virtual ~SoundSystem();
    };
}
}
#endif