/*
-----------------------------------------------------------------------------
���Ͷ�ý����

ʱ��: 2014-5-8

�ı�����: utf-8

������˾: �������ǿƼ����޹�˾

�������: ����������

��̷��: ͳ��ʽ

����ģʽ: �ֲ�ʽ

�ڲ��ɷ�: UI���� ������� ��Ƶ���� �������� �¼���������(��ɢ�����)

��Ҫ�ɷ�: c++(80%) c(20%)

��;: ����ϵͳ����(��Χ����ϵͳ�ں�api)
      ��άӦ������
        ��������������������(CAD)
        ������Ϣϵͳ����(GIS)
        ��Ӱ���������ع�����
        ������Ϸ����

ƫ����;: ������Ϸ����

��ҳ: www.niiengine.com ��������: niiengine@gmail.com OR niiengine@163.com

��Ȩ��ʽ:��ҵ��Ȩ(www.niiengine.com/license)(3��)
------------------------------------------------------------------------------
*/

#ifndef _NII_COREAUDIO_SOUNDSTREAM_H_
#define _NII_COREAUDIO_SOUNDSTREAM_H_

#include <samplerate.h>
#include <list>

#include "CoreAudioRingBuffer.h"
#include "ICoreAudioSource.h"
#include "NiiAudioFormat.h"
#include "NiiSoundStream.h"
#include "cores/AudioEngine/Utils/AEConvert.h"
#include "cores/AudioEngine/Utils/AERemap.h"
#include "cores/AudioEngine/Utils/AELimiter.h"

#if defined(TARGET_DARWIN_IOS)
    #include "CoreAudioAEHALIOS.h"
#else
    #include "CoreAudioAEHALOSX.h"
#endif

namespace NII
{
namespace NII_MEDIA
{
    class CoreAudioRingBuffer;

    class CoreAudioSoundStream : public SoundStream, public ICoreAudioSource
    {
    protected:
        friend class CoreAudioSoundSystem;
        CoreAudioSoundStream(enum SampleFormat format, NCount sampleRate,
            NCount encodedSamplerate, AudioChannel channelLayout, NCount options);
        virtual ~CoreAudioSoundStream();

        CAUOutputDevice * m_outputUnit;
    public:
        /// @copydetails SoundStream::play
        virtual void play();

        /// @copydetails SoundStream::pause
        virtual void pause();

        /// @copydetails SoundStream::resume
        virtual void resume();

        /// @copydetails SoundStream::stop
        virtual void stop();

        /// @copydetails SoundStream::add
        virtual NCount add(void * data, NCount size);

        /// @copydetails SoundStream::add
        virtual NCount add(const SoundStream * data);

        /// @copydetails SoundStream::add
        virtual NCount add(const Sound * data);

        /// @copydetails SoundStream::clear
        virtual void clear();

        /// @copydetails SoundStream::add
        virtual void add(IAudioCallback * lis);

        /// @copydetails SoundStream::remove
        virtual void remove(IAudioCallback * lis);

        /// @copydetails SoundStream::setVol
        virtual void setVol(NIIf volume);

        /// @copydetails SoundStream::getVol
        virtual NIIf getVol();

        /// @copydetails SoundStream::setPos
        virtual void setPos();

        /// @copydetails SoundStream::getPos
        virtual void getPos();

        /// @copydetails SoundStream::setVel
        virtual void setVel();

        /// @copydetails SoundStream::getVel
        virtual void getVel();

        /// @copydetails SoundStream::setDir
        virtual void setDir();

        /// @copydetails SoundStream::getDir
        virtual void getDir();

        /// @copydetails SoundStream::isStop
        virtual bool isStop();

        /// @copydetails SoundStream::isDataIn
        virtual bool isDataIn();

        /// @copydetails SoundStream::isDataOut
        virtual bool isDataOut();

        /// @copydetails SoundStream::isRollOff
        virtual bool isRollOff();

        /// @copydetails SoundStream::rollOff
        virtual void rollOff(NIIf from, NIIf to, NCount time);

        /// @copydetails SoundStream::getValidSize
        virtual NCount getValidSize();

        /// @copydetails SoundStream::getRemainTime
        virtual NIId getRemainTime();

        /// @copydetails SoundStream::getCapacityTime
        virtual NIId getCapacityTime();

        /// @copydetails SoundStream::getDataWait
        virtual NIId getDataWait();

        /// @copydetails SoundStream::IsDraining
        virtual bool IsDraining();

        /// @copydetails SoundStream::GetReplayGain
        virtual NIIf GetReplayGain();

        /// @copydetails SoundStream::SetReplayGain
        virtual void SetReplayGain(NIIf factor);

        /// @copydetails SoundStream::GetAmplification
        virtual NIIf GetAmplification() { return m_limiter.GetAmplification(); }

        /// @copydetails SoundStream::SetAmplification
        virtual void SetAmplification(NIIf amplify){ m_limiter.SetAmplification(amplify); }

        /// @copydetails SoundStream::getFrameSize
        virtual NCount getFrameSize() const;

        /// @copydetails SoundStream::getChannelCount
        virtual NCount getChannelCount() const;

        /// @copydetails SoundStream::getSampleRate
        virtual NCount getSampleRate() const;

        /// @copydetails SoundStream::getEncodeSampleRate
        virtual NCount getEncodeSampleRate() const;

        /// @copydetails SoundStream::getSampleFormat
        virtual enum SampleFormat getSampleFormat() const;

        /// @copydetails SoundStream::getResampleFactor
        virtual NIId getResampleFactor();

        /// @copydetails SoundStream::setResampleFactor
        virtual bool setResampleFactor(NIId ratio);

        /// @copydetails SoundStream::setNext
        virtual void setNext(SoundStream * stream);

        OSStatus Render(AudioUnitRenderActionFlags * flags, const AudioTimeStamp * time,
            UInt32 bus, UInt32 frames, AudioBufferList * data);

        virtual const bool IsRaw() const;

        void ReinitConverter();
        void CloseConverter();
        void OpenConverter();

        void Initialize();
        void InitializeRemap();
        virtual void Destroy();

        bool IsPaused();

        NCount GetFrames(uint8_t * buffer, NCount size);

        virtual NIIf RunLimiter(NIIf * frame, int channels) { return m_limiter.Run(frame, channels); }

        bool IsDestroyed();

        bool IsValid();
    private:
        void InternalFlush();

        OSStatus OnRender(AudioUnitRenderActionFlags * flags, const AudioTimeStamp * time,
            UInt32 bus, UInt32 frames, AudioBufferList * data);
    private:
        SampleFormat m_rawDataFormat;

        VoiceFormat m_OutputFormat;
        NCount m_chLayoutCountOutput;
        VoiceFormat m_StreamFormat;
        NCount m_chLayoutCountStream;
        NCount m_StreamBytesPerSample;
        NCount m_OutputBytesPerSample;

        //bool m_forceResample; /* true if we are to force resample even when the rates match */
        //bool m_resample;      /* true if the audio needs to be resampled  */
        bool m_convert;         /* true if the bitspersample needs converting */
        bool m_valid;           /* true if the stream is valid */
        bool m_delete;          /* true if CoreAudioSoundSystem is to free this object */
        AudioChConvert m_remap;       /* the remapper */
        NIIf m_volume;         /* the volume level */
        NIIf m_rgain;          /* replay gain level */
        CAELimiter m_limiter;   /* volume amplification/limiter*/
        SoundStream * m_slave;  /* slave aestream */

        CAEConvert::AEConvertToFn m_convertFn;

        CoreAudioRingBuffer * m_Buffer;
        NIIf * m_convertBuffer;      /* buffer for converted data */
        int m_convertBufferSize;
        //NIIf * m_resampleBuffer;     /* buffer for resample data */
        //int m_resampleBufferSize;
        uint8_t * m_upmixBuffer;        /* buffer for remap data */
        int m_upmixBufferSize;
        uint8_t * m_remapBuffer;        /* buffer for remap data */
        int m_remapBufferSize;
        uint8_t * m_vizRemapBuffer;     /* buffer for remap data */
        int m_vizRemapBufferSize;

        SRC_STATE * m_ssrc;
        SRC_DATA m_ssrcData;
        bool m_paused;
        bool m_draining;
        NCount m_AvgBytesPerSec;

        /* vizualization internals */
        AudioChConvert m_vizRemap;
        IAudioCallback * m_audioCallback;

        /* fade values */
        bool m_fadeRunning;
        bool m_fadeDirUp;
        NIIf m_fadeStep;
        NIIf m_fadeTarget;
        NCount m_fadeTime;
        bool m_isRaw;
        NCount m_frameSize;
        bool m_doRemap;
        void Upmix(void * input, NCount channelsInput, void * output,
            NCount channelsOutput, NCount frames, SampleFormat dataFormat);
        bool m_firstInput;
    };
}
}
#endif