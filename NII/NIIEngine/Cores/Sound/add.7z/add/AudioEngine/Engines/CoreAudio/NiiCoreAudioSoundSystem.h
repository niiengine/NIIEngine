/*
-----------------------------------------------------------------------------
���Ͷ�ý����

ʱ��: 2013-8-21

�ı�����: utf-8

������˾: �������ǿƼ����޹�˾

�������: ����������

��̷��: ͳ��ʽ

����ģʽ: �ֲ�ʽ

�ڲ��ɷ�: UI���� ������� ��Ƶ���� �������� �¼���������(��ɢ�����)

��Ҫ�ɷ�: c++(80%) c(20%)

��;: ����ϵͳ����(��Χ����ϵͳ�ں�api)
      ��άӦ������
        ��������������������(CAD)
        ������Ϣϵͳ����(GIS)
        ��Ӱ���������ع�����
        ������Ϸ����

��ҳ: www.niiengine.com ��������: niiengine@gmail.com OR niiengine@163.com

��Ȩ��ʽ:��ҵ��Ȩ(www.niiengine.com/license)(3��)
------------------------------------------------------------------------------
*/

#ifndef _NII_COREAUDIO_SOUNDSYSTEM_H_
#define _NII_COREAUDIO_SOUNDSYSTEM_H_

#include "NiiPreInclude.h"

#include "cores/AudioEngine/Interfaces/AE.h"
#include "ICoreAudioAEHAL.h"
#include "ICoreAudioSource.h"
#include "NiiCoreAudioSoundStream.h"
#include "NiiCoreAudioSound.h"
#include "threads/CriticalSection.h"

#if defined(TARGET_DARWIN_IOS)
    #include "CoreAudioAEHALIOS.h"
#else
    #include "CoreAudioAEHALOSX.h"
#endif

#define COREAUDIO_IS_RAW(x) \
(                           \
  (x) == SFE_AC3   ||    \
  (x) == SFE_DTS   ||    \
  (x) == SFE_LPCM  ||    \
  (x) == SFE_EAC3  ||    \
  (x) == SFE_DTSHD ||    \
  (x) == SFE_TRUEHD      \
)

#if defined(TARGET_DARWIN_IOS)
    #define CCoreAudioAEHAL CCoreAudioAEHALIOS
#else
    #define CCoreAudioAEHAL CCoreAudioAEHALOSX
#endif

namespace NII
{
namespace NII_MEDIA
{
    class CoreAudioSoundStream;
    class CoreAudioSound;
    class CCoreAudioAEEventThread;

    class CoreAudioSoundSystem : public SoundSystem, public ICoreAudioSource
    {
        friend class CCoreAudioAEHAL;
        friend class CAEFactory;
    public:
        /// @copydetails SoundSystem::startup
        virtual bool startup(VoiceFormat & vf, String & device);

        /// @copydetails SoundSystem::shutdown
        virtual void shutdown();

        /// @copydetails SoundSystem::pause
        virtual bool pause(); /* pause output and de-startup "hog-mode" sink for external players and power savings */

        /// @copydetails SoundSystem::resume
        virtual bool resume();  /* resume ouput and re-startup sink after pause() above */

        /// @copydetails SoundSystem::update
        virtual void update();

        /// @copydetails SoundSystem::setMute
        virtual void setMute(bool set);

        /// @copydetails SoundSystem::setMode
        virtual void setMode(int mode);

        /// @copydetails SoundSystem::getVol
        virtual NIIf getVol();

        /// @copydetails SoundSystem::setVol
        virtual void setVol(NIIf volume);

        /// @copydetails SoundSystem::isMute
        virtual bool isMute();

        /// @copydetails SoundSystem::isPause
        virtual bool isPause(); /* Returns true if in pause mode - used by players */

        /// @copydetails SoundSystem::create
        virtual Sound * create(const String & file);

        /// @copydetails SoundSystem::destroy
        virtual void destroy(Sound * sound);

        /// @copydetails SoundSystem::createStream
        virtual SoundStream * createStream(SampleFormat dataFormat,
            NCount sampleRate,NCount encodedSamplerate,
                AudioChannel channelLayout, NCount options = 0);

        /// @copydetails SoundSystem::destroy
        virtual SoundStream * destroy(SoundStream * stream);

        /// @copydetails SoundSystem::enumDev
        virtual void enumDev(AEDeviceList & devices, bool passthrough);

        /// @copydetails SoundSystem::SupportsRaw
        virtual bool SupportsRaw();
    public:
        /// @copydetails SoundSystem::OnSettingsChange
        virtual void OnSettingsChange(const String & setting);
    public:
        /// @copydetails SoundSystem::Render
        virtual OSStatus Render(AudioUnitRenderActionFlags * flags,
            const AudioTimeStamp * time, UInt32 bus,UInt32 frames,
                AudioBufferList * data);
    public:
        virtual void play(Sound * sound);
        virtual void stop(Sound * sound);
        void StopAllSounds();
        void softMixer(NIIf * buffer, NCount samples);
        NCount GetSampleRate();
        NCount GetEncodedSampleRate();
        AudioChannel GetChannelLayout();
        NCount GetChannelCount();
        SampleFormat GetDataFormat();
        VoiceFormat GetAudioFormat();

        virtual NIId GetDelay();

        CCoreAudioAEHAL * GetHAL();

        void AudioDevicesChanged();
    protected:
        CoreAudioSoundSystem();
        virtual ~CoreAudioSoundSystem();

        OSStatus OnRender(AudioUnitRenderActionFlags * flags,
            const AudioTimeStamp * time, UInt32 bus,UInt32 frames,
                AudioBufferList * data);
    protected:
        CCoreAudioAEHAL * HAL;

    private:
        void Deinitialize();
        void Start();
        void Stop();

        bool OpenCoreAudio(NCount sampleRate, bool forceRaw, SampleFormat rawDataFormat);

        CCriticalSection m_callbackLock;
        CCriticalSection m_engineLock;
        CCriticalSection m_streamLock;
        CCriticalSection m_soundLock;
        CCriticalSection m_soundSampleLock;

        // currently playing sounds
        typedef struct
        {
            CoreAudioSound * owner;
            NIIf * samples;
            NCount sampleCount;
        }SoundState;

        typedef std::list<CoreAudioSoundStream *> StreamList;
        typedef std::list<CoreAudioSound *> SoundList;
        typedef std::list<SoundState> SoundStateList;

        StreamList m_streams;
        SoundList m_sounds;
        SoundStateList m_playing_sounds;

        // Prevent multiple init/deinit
        bool m_Initialized;
        bool m_callbackRunning;

        VoiceFormat m_format;
        SampleFormat m_lastStreamFormat;
        NCount m_lastChLayoutCount;
        NCount m_lastSampleRate;
        NCount m_chLayoutCount;
        bool m_rawPassthrough;

        AudioLayoutType m_stdChLayout;

        NIIf m_volume;
        NIIf m_volumeBeforeMute;
        bool m_muted;
        int m_soundMode;
        bool m_streamsPlaying;
        bool m_isSuspended;
        bool m_softSuspend;
        NCount m_softSuspendTimer;
    };
}
}