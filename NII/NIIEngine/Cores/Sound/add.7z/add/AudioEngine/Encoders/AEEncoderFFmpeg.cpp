/*
-----------------------------------------------------------------------------
���Ͷ�ý����

ʱ��: 2014-5-7

�ı�����: utf-8

������˾: �������ǿƼ����޹�˾

�������: ����������

��̷��: ͳ��ʽ

����ģʽ: �ֲ�ʽ

�ڲ��ɷ�: UI���� ������� ��Ƶ���� �������� �¼���������(��ɢ�����)

��Ҫ�ɷ�: c++(80%) c(20%)

��;: ����ϵͳ����(��Χ����ϵͳ�ں�api)
      ��άӦ������
        ������Ϣϵͳ����(GIS)
        ��Ӱ���������ع�����
        ������Ϸ����

ƫ����;: ������Ϸ����

��ҳ: www.niiengine.com ��������: niiengine@gmail.com OR niiengine@163.com

��Ȩ��ʽ:��ҵ��Ȩ(www.niiengine.com/license)(3��)
------------------------------------------------------------------------------
*/

#define AC3_ENCODE_BITRATE 640000
#define DTS_ENCODE_BITRATE 1411200

#include "AEEncoderFFmpeg.h"
#include "cores/AudioEngine/Utils/AEUtil.h"
#include "utils/log.h"
#include "settings/AdvancedSettings.h"
#include "settings/GUISettings.h"
#include <string.h>

namespace NII
{
namespace NII_MEDIA
{
    //------------------------------------------------------------------------
    CAEEncoderFFmpeg::CAEEncoderFFmpeg():
        m_CodecCtx(NULL),
        m_BitRate(0),
        m_BufferSize(0),
        m_OutputSize(0),
        m_OutputRatio(0.0),
        m_SampleRateMul(0.0),
        m_NeededFrames(0)
    {
    }
    //------------------------------------------------------------------------
    CAEEncoderFFmpeg::~CAEEncoderFFmpeg()
    {
        Reset();
        m_dllAvUtil.av_freep(&m_CodecCtx);
    }
    //------------------------------------------------------------------------
    bool CAEEncoderFFmpeg::IsCompatible(VoiceFormat format)
    {
        if (!m_CodecCtx)
            return false;

        bool match = (
            format.m_dataFormat == m_CurrentFormat.m_dataFormat &&
            format.m_sampleRate == m_CurrentFormat.m_sampleRate);

        if (match)
        {
            AudioChannel layout;
            BuildChannelLayout(AV_CH_LAYOUT_5POINT1_BACK, layout); /* hard coded for AC3 & DTS currently */
            match = (m_CurrentFormat.m_channelLayout == layout);
        }

        return match;
    }
    //------------------------------------------------------------------------
    NCount CAEEncoderFFmpeg::BuildChannelLayout(const int64_t ffmap,
        AudioChannel & layout)
    {
        /* build the channel layout and count the channels */
        layout.Reset();
        if(ffmap & AV_CH_FRONT_LEFT)
            layout += AE_CH_FL;
        if(ffmap & AV_CH_FRONT_RIGHT)
            layout += ACT_FR;
        if(ffmap & AV_CH_FRONT_CENTER)
            layout += ACT_FC;
        if(ffmap & AV_CH_LOW_FREQUENCY)
            layout += ACT_LEF;
        if(ffmap & AV_CH_BACK_LEFT)
            layout += ACT_BL;
        if(ffmap & AV_CH_BACK_RIGHT)
            layout += ACT_BR;
        if(ffmap & AV_CH_FRONT_LEFT_OF_CENTER)
            layout += ACT_FLOC;
        if(ffmap & AV_CH_FRONT_RIGHT_OF_CENTER)
            layout += ACT_FROC;
        if(ffmap & AV_CH_BACK_CENTER)
            layout += ACT_BC;
        if(ffmap & AV_CH_SIDE_LEFT)
            layout += ACT_SL;
        if(ffmap & AV_CH_SIDE_RIGHT)
            layout += ACT_SR;
        if(ffmap & AV_CH_TOP_CENTER)
            layout += ACT_TC;
        if(ffmap & AV_CH_TOP_FRONT_LEFT)
            layout += ACT_TFL;
        if(ffmap & AV_CH_TOP_FRONT_CENTER)
            layout += ACT_TFC;
        if(ffmap & AV_CH_TOP_FRONT_RIGHT)
            layout += ACT_TFR;
        if(ffmap & AV_CH_TOP_BACK_LEFT)
            layout += ACT_TBL;
        if(ffmap & AV_CH_TOP_BACK_CENTER)
            layout += ACT_TBC;
        if(ffmap & AV_CH_TOP_BACK_RIGHT)
            layout += ACT_TBR;

        return layout.Count();
    }
    //------------------------------------------------------------------------
    bool CAEEncoderFFmpeg::Initialize(VoiceFormat & format)
    {
        Reset();

        if (!m_dllAvUtil.Load() || !m_dllAvCodec.Load())
            return false;

        m_dllAvCodec.avcodec_register_all();

        bool ac3 = g_guiSettings.GetBool("audiooutput.ac3passthrough");

        AVCodec * codec = NULL;
#if 0
        /* the DCA encoder is currently useless for transcode, it creates a 196 kHz DTS-HD like mongrel which is useless for SPDIF */
        bool dts = g_guiSettings.GetBool("audiooutput.dtspassthrough");
        if (dts && (!ac3 || g_advancedSettings.m_audioTranscodeTo.Equals("dts")))
        {
            m_CodecName = "DTS";
            m_CodecID = CODEC_ID_DTS;
            m_PackFunc = &CAEPackIEC61937::PackDTS_1024;
            m_BitRate = DTS_ENCODE_BITRATE;
            codec = m_dllAvCodec.avcodec_find_encoder(m_CodecID);
        }
#endif

        /* fallback to ac3 if we support it, we might not have DTS support */
        if (!codec && ac3)
        {
            m_CodecName = "AC3";
            m_CodecID = CODEC_ID_AC3;
            m_PackFunc = &CAEPackIEC61937::PackAC3;
            m_BitRate = AC3_ENCODE_BITRATE;
            codec = m_dllAvCodec.avcodec_find_encoder(m_CodecID);
        }

        /* check we got the codec */
        if (!codec)
            return false;

        m_CodecCtx = m_dllAvCodec.avcodec_alloc_context3(codec);
        m_CodecCtx->bit_rate = m_BitRate;
        m_CodecCtx->sample_rate = format.m_sampleRate;
        m_CodecCtx->channel_layout = AV_CH_LAYOUT_5POINT1_BACK;

        /* select a suitable data format */
        if (codec->sample_fmts)
        {
            bool hasFloat = false;
            bool hasDouble = false;
            bool hasS32 = false;
            bool hasS16 = false;
            bool hasU8 = false;

            for(int i = 0; codec->sample_fmts[i] != AV_SAMPLE_FMT_NONE; ++i)
            {
                switch (codec->sample_fmts[i])
                {
                case AV_SAMPLE_FMT_FLT:
                    hasFloat = true;
                    break;
                case AV_SAMPLE_FMT_DBL:
                    hasDouble = true;
                    break;
                case AV_SAMPLE_FMT_S32:
                    hasS32 = true;
                    break;
                case AV_SAMPLE_FMT_S16:
                    hasS16 = true;
                    break;
                case AV_SAMPLE_FMT_U8 :
                    hasU8 = true;
                    break;

                default:
                    return false;
                }
            }

            if (hasFloat)
            {
                m_CodecCtx->sample_fmt = AV_SAMPLE_FMT_FLT;
                format.m_dataFormat = SF_F;
            }
            else if (hasDouble)
            {
                m_CodecCtx->sample_fmt = AV_SAMPLE_FMT_DBL;
                format.m_dataFormat = SF_D;
            }
            else if (hasS32)
            {
                m_CodecCtx->sample_fmt = AV_SAMPLE_FMT_S32;
                format.m_dataFormat = SF_S32;
            }
            else if (hasS16)
            {
                m_CodecCtx->sample_fmt = AV_SAMPLE_FMT_S16;
                format.m_dataFormat = SF_S16;
            }
            else if (hasU8)
            {
                m_CodecCtx->sample_fmt = AV_SAMPLE_FMT_U8;
                format.m_dataFormat = SF_U8;
            }
            else
            {
                CLog::Log(LOGERROR, "CAEEncoderFFmpeg::Initialize - Unable to find a suitable data format for the codec (%s)", m_CodecName.c_str());
                return false;
            }
        }

        m_CodecCtx->channels = BuildChannelLayout(m_CodecCtx->channel_layout, m_Layout);

        /* open the codec */
        if (m_dllAvCodec.avcodec_open2(m_CodecCtx, codec, NULL))
        {
            m_dllAvUtil.av_freep(&m_CodecCtx);
            return false;
        }

        format.m_dataFormat = SF_F;
        format.m_frames = m_CodecCtx->frame_size;
        format.m_frameSamples = m_CodecCtx->frame_size * m_CodecCtx->channels;
        format.m_frameSize = m_CodecCtx->channels * (CAEUtil::DataFormatToBits(format.m_dataFormat) >> 3);
        format.m_channelLayout = m_Layout;

        m_CurrentFormat = format;
        m_NeededFrames = format.m_frames;
        m_OutputSize = m_PackFunc(NULL, 0, m_Buffer);
        m_OutputRatio = (NIId)m_NeededFrames / m_OutputSize;
        m_SampleRateMul = 1.0 / (NIId)m_CodecCtx->sample_rate;

        CLog::Log(LOGNOTICE, "CAEEncoderFFmpeg::Initialize - %s encoder ready", m_CodecName.c_str());
        return true;
    }
    //------------------------------------------------------------------------
    void CAEEncoderFFmpeg::Reset()
    {
        m_BufferSize = 0;
    }
    //------------------------------------------------------------------------
    NCount CAEEncoderFFmpeg::GetBitRate()
    {
        return m_BitRate;
    }
    //------------------------------------------------------------------------
    CodecID CAEEncoderFFmpeg::GetCodecID()
    {
        return m_CodecID;
    }
    //------------------------------------------------------------------------
    NCount CAEEncoderFFmpeg::GetFrames()
    {
        return m_NeededFrames;
    }
    //------------------------------------------------------------------------
    int CAEEncoderFFmpeg::Encode(NIIf * data, NCount frames)
    {
        if (!m_CodecCtx || frames < m_NeededFrames)
            return 0;

        /* encode it */
        int size = m_dllAvCodec.avcodec_encode_audio(m_CodecCtx, m_Buffer + IEC61937_DATA_OFFSET, FF_MIN_BUFFER_SIZE, (short*)data);

        /* pack it into an IEC958 frame */
        m_BufferSize = m_PackFunc(NULL, size, m_Buffer);
        if (m_BufferSize != m_OutputSize)
        {
            m_OutputSize = m_BufferSize;
            m_OutputRatio = (NIId)m_NeededFrames / m_OutputSize;
        }

        /* return the number of frames used */
        return m_NeededFrames;
    }
    //------------------------------------------------------------------------
    int CAEEncoderFFmpeg::GetData(uint8_t ** data)
    {
        int size;
        *data = m_Buffer;
        size  = m_BufferSize;
        m_BufferSize = 0;
        return size;
    }
    //------------------------------------------------------------------------
    NIId CAEEncoderFFmpeg::GetDelay(NCount bufferSize)
    {
        if (!m_CodecCtx)
            return 0;

        int frames = m_CodecCtx->delay;
        if (m_BufferSize)
            frames += m_NeededFrames;

        return ((NIId)frames + ((NIId)bufferSize * m_OutputRatio)) * m_SampleRateMul;
    }
    //------------------------------------------------------------------------
}
}
