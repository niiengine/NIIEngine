/*
-----------------------------------------------------------------------------
���Ͷ�ý����

ʱ��: 2014-5-7

�ı�����: utf-8

������˾: �������ǿƼ����޹�˾

�������: ����������

��̷��: ͳ��ʽ

����ģʽ: �ֲ�ʽ

�ڲ��ɷ�: UI���� ������� ��Ƶ���� �������� �¼���������(��ɢ�����)

��Ҫ�ɷ�: c++(80%) c(20%)

��;: ����ϵͳ����(��Χ����ϵͳ�ں�api)
      ��άӦ������
        ������Ϣϵͳ����(GIS)
        ��Ӱ���������ع�����
        ������Ϸ����

ƫ����;: ������Ϸ����

��ҳ: www.niiengine.com ��������: niiengine@gmail.com OR niiengine@163.com

��Ȩ��ʽ:��ҵ��Ȩ(www.niiengine.com/license)(3��)
------------------------------------------------------------------------------
*/

#include "DVDAudioCodecPassthrough.h"
#include "DVDCodecs/DVDCodecs.h"
#include "DVDStreamInfo.h"
#include "settings/GUISettings.h"
#include "settings/Settings.h"
#include "utils/log.h"

#include "cores/AudioEngine/AEFactory.h"

CDVDAudioCodecPassthrough::CDVDAudioCodecPassthrough(void) :
    m_buffer(NULL),
    m_bufferSize(0)
{
}

CDVDAudioCodecPassthrough::~CDVDAudioCodecPassthrough(void)
{
    Dispose();
}

bool CDVDAudioCodecPassthrough::Open(CDVDStreamInfo &hints, CDVDCodecOptions &options)
{
    /* dont open if AE doesnt support RAW */
    if (!CAEFactory::SupportsRaw())
        return false;

    bool bSupportsAC3Out    = false;
    bool bSupportsDTSOut    = false;
    bool bSupportsTrueHDOut = false;
    bool bSupportsDTSHDOut  = false;

    int audioMode = g_guiSettings.GetInt("audiooutput.mode");
    if (AUDIO_IS_BITSTREAM(audioMode))
    {
        bSupportsAC3Out = g_guiSettings.GetBool("audiooutput.ac3passthrough");
        bSupportsDTSOut = g_guiSettings.GetBool("audiooutput.dtspassthrough");
    }

    if (audioMode == AUDIO_HDMI)
    {
        bSupportsTrueHDOut = g_guiSettings.GetBool("audiooutput.truehdpassthrough");
        bSupportsDTSHDOut  = g_guiSettings.GetBool("audiooutput.dtshdpassthrough" ) && bSupportsDTSOut;
    }

    /* only get the dts core from the parser if we don't support dtsHD */
    m_info.SetCoreOnly(!bSupportsDTSHDOut);
    m_bufferSize = 0;

    if ((hints.codec == CODEC_ID_AC3 && bSupportsAC3Out) ||
        (hints.codec == CODEC_ID_DTS && bSupportsDTSOut) ||
            (audioMode == AUDIO_HDMI &&
                ((hints.codec == CODEC_ID_EAC3   && bSupportsAC3Out) ||
                    (hints.codec == CODEC_ID_TRUEHD && bSupportsTrueHDOut))))
        return true;

    return false;
}

int CDVDAudioCodecPassthrough::GetSampleRate()
{
    return m_info.GetOutputRate();
}

int CDVDAudioCodecPassthrough::GetEncodedSampleRate()
{
    return m_info.GetSampleRate();
}

enum SampleFormat CDVDAudioCodecPassthrough::GetDataFormat()
{
    switch(m_info.GetDataType())
    {
    case SoundUnit::STREAM_TYPE_AC3:
        return SFE_AC3;

    case SoundUnit::STREAM_TYPE_DTS_512:
    case SoundUnit::STREAM_TYPE_DTS_1024:
    case SoundUnit::STREAM_TYPE_DTS_2048:
    case SoundUnit::STREAM_TYPE_DTSHD_CORE:
        return SFE_DTS;

    case SoundUnit::STREAM_TYPE_EAC3:
        return SFE_EAC3;

    case SoundUnit::STREAM_TYPE_TRUEHD:
        return SFE_TRUEHD;

    case SoundUnit::STREAM_TYPE_DTSHD:
        return SFE_DTSHD;

    default:
        return SF_Unknow; //Unknown stream type
    }
}

int CDVDAudioCodecPassthrough::GetChannels()
{
    return m_info.GetOutputChannels();
}

int CDVDAudioCodecPassthrough::GetEncodedChannels()
{
    return m_info.GetChannels();
}

AudioChannel CDVDAudioCodecPassthrough::GetChannelMap()
{
    return m_info.GetChannelMap();
}

void CDVDAudioCodecPassthrough::Dispose()
{
    if (m_buffer)
    {
        delete[] m_buffer;
        m_buffer = NULL;
    }

    m_bufferSize = 0;
}

int CDVDAudioCodecPassthrough::Decode(BYTE* pData, int iSize)
{
    if (iSize <= 0) 
        return 0;

    unsigned int size = m_bufferSize;
    unsigned int used = m_info.AddData(pData, iSize, &m_buffer, &size);
    m_bufferSize = std::max(m_bufferSize, size);

    /* if we have a frame */
    if (size)
        m_packer.Pack(m_info, m_buffer, size);

    return used;
}

int CDVDAudioCodecPassthrough::GetData(BYTE** dst)
{
    int size = m_packer.GetSize();
    *dst     = m_packer.GetBuffer();
    return size;
}

void CDVDAudioCodecPassthrough::Reset()
{
}

int CDVDAudioCodecPassthrough::GetBufferSize()
{
    return (int)m_info.GetBufferSize();
}
