------------------------------------------------------------
Resource created by Chris Farina for facecjf.com
------------------------------------------------------------

TERMS OF USE:

All resources made available on facecjf.com, including but not limited to, icons, images, brushes, shapes, layer styles, layered PSD�s, patterns, textures, web elements and themes are free for use in both personal and commercial projects.

You may freely use facecjf.com resources, without restriction, in software programs, web templates and other materials intended for sale or distribution. No attribution or backlinks are required, but any form of spreading the word is always appreciated!

You are not permitted to make the resources found on facecjf.com available for distribution elsewhere �as is� without prior consent.


Chris Farina
_________________________
www.facecjf.com
