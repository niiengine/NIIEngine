/*
 * libjingle
 * Copyright 2006, Google Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *  3. The name of the author may not be used to endorse or promote products
 *     derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
 * EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <iostream>
#include <string>

#include "talk/base/thread.h"
#include "talk/libjingle-plus/libjingleplus.h"
#include "talk/libjingle-plus/testutil/libjingleplus_test_notifier.h"

#if defined(_MSC_VER) && (_MSC_VER < 1400)
void __cdecl std::_Throw(const std::exception &) {}
std::_Prhand std::_Raise_handler =0;
#endif


void SetConsoleEcho(bool on) {
#ifdef WIN32
  HANDLE hIn = GetStdHandle(STD_INPUT_HANDLE);
  if ((hIn == INVALID_HANDLE_VALUE) || (hIn == NULL))
    return;

  DWORD mode;
  if (!GetConsoleMode(hIn, &mode))
    return;

  if (on) {
    mode = mode | ENABLE_ECHO_INPUT;
  } else {
    mode = mode & ~ENABLE_ECHO_INPUT;
  }

  SetConsoleMode(hIn, mode);
#else
  if (on)
    system("stty echo");
  else
    system("stty -echo");
#endif
}

int main (int argc, char **argv)
{
  std::string username;
  std::string password;

  bool gaia = false;
  
  for (int i = 1; i < argc; i++) {
    if (!strcmp(argv[i], "-gaia"))
      gaia = true;
  }
 
  std::cout << "Username: ";
  std::cin >> username;
  std::cout << (gaia ? "Gaia cookie: " : "Password: ");
  SetConsoleEcho(false);
  std::cin >> password;
  SetConsoleEcho(true);

  // Create a LibjinglePlus object and give it the notifier interface
  LibjinglePlus ljp(new Notifier);
  
  // Login
  ljp.Login(username, password, "talk.google.com", false, gaia);
  
  buzz::Status s;
  s.set_available(true);
  s.set_show(buzz::Status::SHOW_ONLINE);
  s.set_status("I'm online.");
  
  buzz::XmppMessage m;
  m.set_to(buzz::Jid(username + "@gmail.com"));
  m.set_body("What's up?");
  
  // Typically, you would wait for WakeupMainThread to be called, and then call
  // DoCallbacks. Because I have nothing else to do on the main thread, I'm just going
  // to do a few things after 10 seconds and then poll every 2ms.
  Sleep(10000);
  //  ljp.DoCallbacks();
  ljp.SendPresence(s);
  ljp.SendXmppMessage(m);

#ifdef WIN32  
  MSG msg;
  while (GetMessage(&msg, NULL, 0, 0)) {
    DispatchMessage(&msg);
  }
#else
  for (;;) {
    ljp.DoCallbacks();
    Sleep(2);
  }
#endif
}
