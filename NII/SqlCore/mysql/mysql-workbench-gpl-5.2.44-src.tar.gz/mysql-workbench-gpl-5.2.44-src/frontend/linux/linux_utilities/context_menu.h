#ifndef _CONTEXT_MENU_H_
#define _CONTEXT_MENU_H_

class ContextMenu 
{
};

#endif /* _CONTEXT_MENU_H_ */
