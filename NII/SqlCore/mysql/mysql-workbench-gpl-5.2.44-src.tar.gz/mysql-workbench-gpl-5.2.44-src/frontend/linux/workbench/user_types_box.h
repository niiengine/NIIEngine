//!
//! \addtogroup linuxui Linux UI
//! @{
//! 

#ifndef _USER_TYPES_BOX_H_
#define _USER_TYPES_BOX_H_

#include <gtkmm/scrolledwindow.h>
#include <gtkmm/treeview.h>
#include "workbench/wb_context_ui.h"
#include "listmodel_wrapper.h"

class UserTypesBox : public Gtk::ScrolledWindow {
  wb::WBContextUI *_wbui;
  Gtk::TreeView _tree;
  Glib::RefPtr<ListModelWrapper> _model;

public:
  UserTypesBox(wb::WBContextUI *wbui);
  
  void refresh();
};


#endif /* _USER_TYPES_BOX_H_ */

//!                                                                                                                                     
//! @}                                                                                                                                  
//!
