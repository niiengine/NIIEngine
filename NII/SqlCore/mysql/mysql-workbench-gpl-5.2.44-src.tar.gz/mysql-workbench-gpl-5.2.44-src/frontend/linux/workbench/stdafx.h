#ifndef _STDAFX_H
#define _STDAFX_H

#include <gtkmm.h>
#include <cairo/cairo.h>
#include <string>
#include <map>
#include <list>
#include <vector>

#include "grtpp.h"
#include "grtpp_util.h"
#include "grt/common.h"

#include "grts/structs.app.h"
#include "grts/structs.db.h"
#include "grts/structs.db.mgmt.h"
#include "grts/structs.db.mysql.h"
#include "grts/structs.db.query.h"
#include "grts/structs.h"
#include "grts/structs.model.h"
#include "grts/structs.workbench.h"
#include "grts/structs.workbench.model.h"
#include "grts/structs.workbench.physical.h"

//#include <mdc.h>
//#include <workbench/wb_context.h>
//#include <workbench/wb_context_ui.h>

#endif
