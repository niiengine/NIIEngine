﻿namespace MySQL.Grt.Db
{
  partial class RecordsetView
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        if (model != null)
        {
          // Remove the callbacks to free the fixed pointers the wrapper keeps to this object.
          model.refresh_ui_cb(null);
          model.refresh_ui_status_bar_cb(null);
        }
        gridView.Dispose(); // Will dispose the model too.

        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      this.recordsetPanel = new System.Windows.Forms.Panel();
      this.splitContainer1 = new System.Windows.Forms.SplitContainer();
      this.viewPanel = new System.Windows.Forms.Panel();
      this.logPanel = new System.Windows.Forms.Panel();
      this.messagesTB = new System.Windows.Forms.TextBox();
      this.mainToolStrip = new System.Windows.Forms.ToolStrip();
      this.statusStrip1 = new System.Windows.Forms.StatusStrip();
      this.fetchedRowsCountLabel = new System.Windows.Forms.ToolStripStatusLabel();
      this.tsSeparator0 = new System.Windows.Forms.ToolStripSeparator();
      this.updatedRowsCountLabel = new System.Windows.Forms.ToolStripStatusLabel();
      this.tsSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.insertedRowsCountLabel = new System.Windows.Forms.ToolStripStatusLabel();
      this.tsSeparator2 = new System.Windows.Forms.ToolStripSeparator();
      this.deletedRowsCountLabel = new System.Windows.Forms.ToolStripStatusLabel();
      this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
      this.setNullMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.deleteRowsMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
      this.copyRowValuesMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.CopyFieldContentMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
      this.columnHeaderContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
      this.setColumnFilterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.resetColumnFilterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.resetAllColumnFiltersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.recordsetPanel.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
      this.splitContainer1.Panel1.SuspendLayout();
      this.splitContainer1.Panel2.SuspendLayout();
      this.splitContainer1.SuspendLayout();
      this.logPanel.SuspendLayout();
      this.statusStrip1.SuspendLayout();
      this.contextMenuStrip.SuspendLayout();
      this.columnHeaderContextMenuStrip.SuspendLayout();
      this.SuspendLayout();
      // 
      // recordsetPanel
      // 
      this.recordsetPanel.Controls.Add(this.splitContainer1);
      this.recordsetPanel.Controls.Add(this.mainToolStrip);
      this.recordsetPanel.Controls.Add(this.statusStrip1);
      this.recordsetPanel.Dock = System.Windows.Forms.DockStyle.Fill;
      this.recordsetPanel.Location = new System.Drawing.Point(0, 0);
      this.recordsetPanel.Margin = new System.Windows.Forms.Padding(0);
      this.recordsetPanel.Name = "recordsetPanel";
      this.recordsetPanel.Size = new System.Drawing.Size(811, 375);
      this.recordsetPanel.TabIndex = 0;
      // 
      // splitContainer1
      // 
      this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
      this.splitContainer1.Location = new System.Drawing.Point(0, 25);
      this.splitContainer1.Margin = new System.Windows.Forms.Padding(0);
      this.splitContainer1.Name = "splitContainer1";
      this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
      // 
      // splitContainer1.Panel1
      // 
      this.splitContainer1.Panel1.Controls.Add(this.viewPanel);
      this.splitContainer1.Panel1MinSize = 0;
      // 
      // splitContainer1.Panel2
      // 
      this.splitContainer1.Panel2.Controls.Add(this.logPanel);
      this.splitContainer1.Panel2Collapsed = true;
      this.splitContainer1.Panel2MinSize = 0;
      this.splitContainer1.Size = new System.Drawing.Size(811, 350);
      this.splitContainer1.SplitterDistance = 321;
      this.splitContainer1.TabIndex = 2;
      // 
      // viewPanel
      // 
      this.viewPanel.Dock = System.Windows.Forms.DockStyle.Fill;
      this.viewPanel.Location = new System.Drawing.Point(0, 0);
      this.viewPanel.Margin = new System.Windows.Forms.Padding(0);
      this.viewPanel.Name = "viewPanel";
      this.viewPanel.Size = new System.Drawing.Size(811, 350);
      this.viewPanel.TabIndex = 0;
      // 
      // logPanel
      // 
      this.logPanel.Controls.Add(this.messagesTB);
      this.logPanel.Dock = System.Windows.Forms.DockStyle.Fill;
      this.logPanel.Location = new System.Drawing.Point(0, 0);
      this.logPanel.Margin = new System.Windows.Forms.Padding(0);
      this.logPanel.Name = "logPanel";
      this.logPanel.Size = new System.Drawing.Size(150, 46);
      this.logPanel.TabIndex = 0;
      // 
      // messagesTB
      // 
      this.messagesTB.BackColor = System.Drawing.SystemColors.Window;
      this.messagesTB.Dock = System.Windows.Forms.DockStyle.Fill;
      this.messagesTB.ForeColor = System.Drawing.SystemColors.WindowText;
      this.messagesTB.Location = new System.Drawing.Point(0, 0);
      this.messagesTB.Margin = new System.Windows.Forms.Padding(0);
      this.messagesTB.Multiline = true;
      this.messagesTB.Name = "messagesTB";
      this.messagesTB.ReadOnly = true;
      this.messagesTB.ScrollBars = System.Windows.Forms.ScrollBars.Both;
      this.messagesTB.Size = new System.Drawing.Size(150, 46);
      this.messagesTB.TabIndex = 0;
      this.toolTip1.SetToolTip(this.messagesTB, "Messages from data source");
      // 
      // mainToolStrip
      // 
      this.mainToolStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(199)))), ((int)(((byte)(222)))));
      this.mainToolStrip.GripMargin = new System.Windows.Forms.Padding(2, 4, 2, 5);
      this.mainToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
      this.mainToolStrip.ImageScalingSize = new System.Drawing.Size(18, 18);
      this.mainToolStrip.Location = new System.Drawing.Point(0, 0);
      this.mainToolStrip.Name = "mainToolStrip";
      this.mainToolStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
      this.mainToolStrip.Size = new System.Drawing.Size(811, 25);
      this.mainToolStrip.TabIndex = 0;
      this.mainToolStrip.Text = "mainToolStrip";
      // 
      // statusStrip1
      // 
      this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fetchedRowsCountLabel,
            this.tsSeparator0,
            this.updatedRowsCountLabel,
            this.tsSeparator1,
            this.insertedRowsCountLabel,
            this.tsSeparator2,
            this.deletedRowsCountLabel,
            this.toolStripSeparator3});
      this.statusStrip1.Location = new System.Drawing.Point(0, 352);
      this.statusStrip1.Name = "statusStrip1";
      this.statusStrip1.Size = new System.Drawing.Size(811, 23);
      this.statusStrip1.SizingGrip = false;
      this.statusStrip1.TabIndex = 0;
      this.statusStrip1.Text = "statusStrip1";
      this.statusStrip1.Visible = false;
      // 
      // fetchedRowsCountLabel
      // 
      this.fetchedRowsCountLabel.Name = "fetchedRowsCountLabel";
      this.fetchedRowsCountLabel.Size = new System.Drawing.Size(52, 18);
      this.fetchedRowsCountLabel.Text = "Fetched:";
      // 
      // tsSeparator0
      // 
      this.tsSeparator0.Name = "tsSeparator0";
      this.tsSeparator0.Size = new System.Drawing.Size(6, 23);
      // 
      // updatedRowsCountLabel
      // 
      this.updatedRowsCountLabel.Name = "updatedRowsCountLabel";
      this.updatedRowsCountLabel.Size = new System.Drawing.Size(55, 18);
      this.updatedRowsCountLabel.Text = "Updated:";
      // 
      // tsSeparator1
      // 
      this.tsSeparator1.Name = "tsSeparator1";
      this.tsSeparator1.Size = new System.Drawing.Size(6, 23);
      // 
      // insertedRowsCountLabel
      // 
      this.insertedRowsCountLabel.Name = "insertedRowsCountLabel";
      this.insertedRowsCountLabel.Size = new System.Drawing.Size(52, 18);
      this.insertedRowsCountLabel.Text = "Inserted:";
      // 
      // tsSeparator2
      // 
      this.tsSeparator2.Name = "tsSeparator2";
      this.tsSeparator2.Size = new System.Drawing.Size(6, 23);
      // 
      // deletedRowsCountLabel
      // 
      this.deletedRowsCountLabel.Name = "deletedRowsCountLabel";
      this.deletedRowsCountLabel.Size = new System.Drawing.Size(50, 18);
      this.deletedRowsCountLabel.Text = "Deleted:";
      // 
      // toolStripSeparator3
      // 
      this.toolStripSeparator3.Name = "toolStripSeparator3";
      this.toolStripSeparator3.Size = new System.Drawing.Size(6, 23);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(149, 6);
      // 
      // contextMenuStrip
      // 
      this.contextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.setNullMenuItem,
            this.deleteRowsMenuItem,
            this.toolStripSeparator4,
            this.copyRowValuesMenuItem,
            this.CopyFieldContentMenuItem});
      this.contextMenuStrip.Name = "contextMenuStrip1";
      this.contextMenuStrip.ShowImageMargin = false;
      this.contextMenuStrip.Size = new System.Drawing.Size(162, 98);
      // 
      // setNullMenuItem
      // 
      this.setNullMenuItem.Name = "setNullMenuItem";
      this.setNullMenuItem.Size = new System.Drawing.Size(161, 22);
      this.setNullMenuItem.Text = "Set selection to NULL";
      this.setNullMenuItem.ToolTipText = "Sets selected cells\' values to NULL";
      this.setNullMenuItem.Click += new System.EventHandler(this.setNullMenuItem_Click);
      // 
      // deleteRowsMenuItem
      // 
      this.deleteRowsMenuItem.Name = "deleteRowsMenuItem";
      this.deleteRowsMenuItem.Size = new System.Drawing.Size(161, 22);
      this.deleteRowsMenuItem.Text = "Delete selected rows";
      this.deleteRowsMenuItem.Click += new System.EventHandler(this.deleteRowsMenuItem_Click);
      // 
      // toolStripSeparator4
      // 
      this.toolStripSeparator4.Name = "toolStripSeparator4";
      this.toolStripSeparator4.Size = new System.Drawing.Size(158, 6);
      // 
      // copyRowValuesMenuItem
      // 
      this.copyRowValuesMenuItem.Name = "copyRowValuesMenuItem";
      this.copyRowValuesMenuItem.Size = new System.Drawing.Size(161, 22);
      this.copyRowValuesMenuItem.Text = "Copy row values";
      this.copyRowValuesMenuItem.Click += new System.EventHandler(this.copyRowValuesMenuItem_Click);
      // 
      // CopyFieldContentMenuItem
      // 
      this.CopyFieldContentMenuItem.Name = "CopyFieldContentMenuItem";
      this.CopyFieldContentMenuItem.Size = new System.Drawing.Size(161, 22);
      this.CopyFieldContentMenuItem.Text = "Copy field content";
      this.CopyFieldContentMenuItem.Click += new System.EventHandler(this.CopyFieldContentMenuItem_Click);
      // 
      // columnHeaderContextMenuStrip
      // 
      this.columnHeaderContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.setColumnFilterToolStripMenuItem,
            this.resetColumnFilterToolStripMenuItem,
            this.resetAllColumnFiltersToolStripMenuItem});
      this.columnHeaderContextMenuStrip.Name = "columnHeaderContextMenuStrip";
      this.columnHeaderContextMenuStrip.Size = new System.Drawing.Size(200, 70);
      // 
      // setColumnFilterToolStripMenuItem
      // 
      this.setColumnFilterToolStripMenuItem.Name = "setColumnFilterToolStripMenuItem";
      this.setColumnFilterToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
      this.setColumnFilterToolStripMenuItem.Text = "Set Column Filter...";
      this.setColumnFilterToolStripMenuItem.Click += new System.EventHandler(this.setColumnFilterToolStripMenuItem_Click);
      // 
      // resetColumnFilterToolStripMenuItem
      // 
      this.resetColumnFilterToolStripMenuItem.Name = "resetColumnFilterToolStripMenuItem";
      this.resetColumnFilterToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
      this.resetColumnFilterToolStripMenuItem.Text = "Reset Column Filter";
      this.resetColumnFilterToolStripMenuItem.Click += new System.EventHandler(this.resetColumnFilterToolStripMenuItem_Click);
      // 
      // resetAllColumnFiltersToolStripMenuItem
      // 
      this.resetAllColumnFiltersToolStripMenuItem.Name = "resetAllColumnFiltersToolStripMenuItem";
      this.resetAllColumnFiltersToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
      this.resetAllColumnFiltersToolStripMenuItem.Text = "Reset All Column Filters";
      this.resetAllColumnFiltersToolStripMenuItem.Click += new System.EventHandler(this.resetAllColumnFiltersToolStripMenuItem_Click);
      // 
      // RecordsetView
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(811, 375);
      this.Controls.Add(this.recordsetPanel);
      this.Name = "RecordsetView";
      this.Text = "RecordsetView";
      this.recordsetPanel.ResumeLayout(false);
      this.recordsetPanel.PerformLayout();
      this.splitContainer1.Panel1.ResumeLayout(false);
      this.splitContainer1.Panel2.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
      this.splitContainer1.ResumeLayout(false);
      this.logPanel.ResumeLayout(false);
      this.logPanel.PerformLayout();
      this.statusStrip1.ResumeLayout(false);
      this.statusStrip1.PerformLayout();
      this.contextMenuStrip.ResumeLayout(false);
      this.columnHeaderContextMenuStrip.ResumeLayout(false);
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Panel recordsetPanel;
    private System.Windows.Forms.Panel viewPanel;
    private System.Windows.Forms.Panel logPanel;
    private System.Windows.Forms.TextBox messagesTB;
    private System.Windows.Forms.SplitContainer splitContainer1;
    private System.Windows.Forms.StatusStrip statusStrip1;
    private System.Windows.Forms.ToolStripStatusLabel fetchedRowsCountLabel;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    private System.Windows.Forms.ToolStripStatusLabel updatedRowsCountLabel;
    private System.Windows.Forms.ToolStripStatusLabel insertedRowsCountLabel;
    private System.Windows.Forms.ToolStripStatusLabel deletedRowsCountLabel;
    private System.Windows.Forms.ToolStripSeparator tsSeparator0;
    private System.Windows.Forms.ToolStripSeparator tsSeparator1;
    private System.Windows.Forms.ToolStripSeparator tsSeparator2;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
    private System.Windows.Forms.ContextMenuStrip contextMenuStrip;
    private System.Windows.Forms.ToolStripMenuItem setNullMenuItem;
    private System.Windows.Forms.ToolTip toolTip1;
    private System.Windows.Forms.ToolStripMenuItem deleteRowsMenuItem;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
    private System.Windows.Forms.ToolStripMenuItem copyRowValuesMenuItem;
    private System.Windows.Forms.ToolStripMenuItem CopyFieldContentMenuItem;
    private System.Windows.Forms.ContextMenuStrip columnHeaderContextMenuStrip;
    private System.Windows.Forms.ToolStripMenuItem setColumnFilterToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem resetColumnFilterToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem resetAllColumnFiltersToolStripMenuItem;
    private System.Windows.Forms.ToolStrip mainToolStrip;
  }
}