namespace MySQL.GUI.Workbench
{
  partial class ObjectFindForm
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.nextButton = new System.Windows.Forms.Button();
      this.label1 = new System.Windows.Forms.Label();
      this.findText = new System.Windows.Forms.TextBox();
      this.previousButton = new System.Windows.Forms.Button();
      this.matchCaseCheck = new System.Windows.Forms.CheckBox();
      this.searchCommentsCheck = new System.Windows.Forms.CheckBox();
      this.statusLabel = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // nextButton
      // 
      this.nextButton.Location = new System.Drawing.Point(243, 106);
      this.nextButton.Name = "nextButton";
      this.nextButton.Size = new System.Drawing.Size(75, 23);
      this.nextButton.TabIndex = 0;
      this.nextButton.Text = "&Next";
      this.nextButton.UseVisualStyleBackColor = true;
      this.nextButton.Click += new System.EventHandler(this.nextButton_Click);
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(12, 15);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(54, 13);
      this.label1.TabIndex = 1;
      this.label1.Text = "&Find Text:";
      // 
      // findText
      // 
      this.findText.Location = new System.Drawing.Point(72, 12);
      this.findText.Name = "findText";
      this.findText.Size = new System.Drawing.Size(246, 20);
      this.findText.TabIndex = 1;
      // 
      // previousButton
      // 
      this.previousButton.Location = new System.Drawing.Point(162, 106);
      this.previousButton.Name = "previousButton";
      this.previousButton.Size = new System.Drawing.Size(75, 23);
      this.previousButton.TabIndex = 0;
      this.previousButton.Text = "&Previous";
      this.previousButton.UseVisualStyleBackColor = true;
      this.previousButton.Click += new System.EventHandler(this.previousButton_Click);
      // 
      // matchCaseCheck
      // 
      this.matchCaseCheck.AutoSize = true;
      this.matchCaseCheck.Location = new System.Drawing.Point(72, 51);
      this.matchCaseCheck.Name = "matchCaseCheck";
      this.matchCaseCheck.Size = new System.Drawing.Size(83, 17);
      this.matchCaseCheck.TabIndex = 3;
      this.matchCaseCheck.Text = "Match Case";
      this.matchCaseCheck.UseVisualStyleBackColor = true;
      // 
      // searchCommentsCheck
      // 
      this.searchCommentsCheck.AutoSize = true;
      this.searchCommentsCheck.Location = new System.Drawing.Point(72, 74);
      this.searchCommentsCheck.Name = "searchCommentsCheck";
      this.searchCommentsCheck.Size = new System.Drawing.Size(123, 17);
      this.searchCommentsCheck.TabIndex = 4;
      this.searchCommentsCheck.Text = "Search in Comments";
      this.searchCommentsCheck.UseVisualStyleBackColor = true;
      // 
      // statusLabel
      // 
      this.statusLabel.AutoSize = true;
      this.statusLabel.Location = new System.Drawing.Point(12, 111);
      this.statusLabel.Name = "statusLabel";
      this.statusLabel.Size = new System.Drawing.Size(0, 13);
      this.statusLabel.TabIndex = 5;
      // 
      // ObjectFindForm
      // 
      this.AcceptButton = this.nextButton;
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(322, 137);
      this.Controls.Add(this.statusLabel);
      this.Controls.Add(this.searchCommentsCheck);
      this.Controls.Add(this.matchCaseCheck);
      this.Controls.Add(this.findText);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.previousButton);
      this.Controls.Add(this.nextButton);
      this.KeyPreview = true;
      this.MaximizeBox = false;
      this.MaximumSize = new System.Drawing.Size(338, 175);
      this.MinimizeBox = false;
      this.MinimumSize = new System.Drawing.Size(338, 175);
      this.Name = "ObjectFindForm";
      this.ShowIcon = false;
      this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
      this.Text = "Find";
      this.Shown += new System.EventHandler(this.ObjectFindForm_Shown);
      this.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.ObjectFindForm_PreviewKeyDown);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Button nextButton;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.TextBox findText;
    private System.Windows.Forms.Button previousButton;
    private System.Windows.Forms.CheckBox matchCaseCheck;
    private System.Windows.Forms.CheckBox searchCommentsCheck;
    private System.Windows.Forms.Label statusLabel;
  }
}