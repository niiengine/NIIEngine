namespace MySQL.GUI.Workbench
{
	partial class ModelCatalogForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ModelCatalogForm));
      this.panel1 = new System.Windows.Forms.Panel();
      this.comboBox1 = new System.Windows.Forms.ComboBox();
      this.catalogTreeView = new Aga.Controls.Tree.TreeViewAdv();
      this.catalogMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.testToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.nodeStateIcon = new Aga.Controls.Tree.NodeControls.NodeStateIcon();
      this.nameNodeControl = new Aga.Controls.Tree.NodeControls.NodeTextBox();
      this.presenceNodeControl = new Aga.Controls.Tree.NodeControls.NodeTextBox();
      this.headerPanel1 = new MySQL.Controls.HeaderPanel();
      this.panel2 = new System.Windows.Forms.Panel();
      this.panel1.SuspendLayout();
      this.catalogMenuStrip.SuspendLayout();
      this.headerPanel1.SuspendLayout();
      this.panel2.SuspendLayout();
      this.SuspendLayout();
      // 
      // panel1
      // 
      this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(199)))), ((int)(((byte)(222)))));
      this.panel1.Controls.Add(this.comboBox1);
      this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
      this.panel1.Location = new System.Drawing.Point(0, 24);
      this.panel1.Margin = new System.Windows.Forms.Padding(0);
      this.panel1.Name = "panel1";
      this.panel1.Padding = new System.Windows.Forms.Padding(4);
      this.panel1.Size = new System.Drawing.Size(279, 28);
      this.panel1.TabIndex = 3;
      this.panel1.Visible = false;
      // 
      // comboBox1
      // 
      this.comboBox1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.comboBox1.FormattingEnabled = true;
      this.comboBox1.Location = new System.Drawing.Point(4, 4);
      this.comboBox1.Name = "comboBox1";
      this.comboBox1.Size = new System.Drawing.Size(271, 21);
      this.comboBox1.TabIndex = 1;
      // 
      // catalogTreeView
      // 
      this.catalogTreeView.BackColor = System.Drawing.SystemColors.Window;
      this.catalogTreeView.BorderStyle = System.Windows.Forms.BorderStyle.None;
      this.catalogTreeView.ContextMenuStrip = this.catalogMenuStrip;
      this.catalogTreeView.DefaultToolTipProvider = null;
      this.catalogTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
      this.catalogTreeView.DragDropMarkColor = System.Drawing.Color.Black;
      this.catalogTreeView.GridColor = System.Drawing.SystemColors.Control;
      this.catalogTreeView.Indent = 12;
      this.catalogTreeView.LineColor = System.Drawing.SystemColors.ControlDark;
      this.catalogTreeView.LoadOnDemand = true;
      this.catalogTreeView.Location = new System.Drawing.Point(4, 4);
      this.catalogTreeView.Margin = new System.Windows.Forms.Padding(0);
      this.catalogTreeView.Model = null;
      this.catalogTreeView.Name = "catalogTreeView";
      this.catalogTreeView.NodeControls.Add(this.nodeStateIcon);
      this.catalogTreeView.NodeControls.Add(this.nameNodeControl);
      this.catalogTreeView.NodeControls.Add(this.presenceNodeControl);
      this.catalogTreeView.SelectedNode = null;
      this.catalogTreeView.SelectionMode = Aga.Controls.Tree.TreeSelectionMode.Multi;
      this.catalogTreeView.ShowLines = false;
      this.catalogTreeView.Size = new System.Drawing.Size(271, 277);
      this.catalogTreeView.TabIndex = 0;
      this.catalogTreeView.Text = "columnTreeView";
      this.catalogTreeView.MouseDown += new System.Windows.Forms.MouseEventHandler(this.catalogTreeView_MouseDown);
      this.catalogTreeView.MouseMove += new System.Windows.Forms.MouseEventHandler(this.catalogTreeView_MouseMove);
      // 
      // catalogMenuStrip
      // 
      this.catalogMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator1,
            this.testToolStripMenuItem});
      this.catalogMenuStrip.Name = "catalogMenuStrip";
      this.catalogMenuStrip.Size = new System.Drawing.Size(97, 32);
      this.catalogMenuStrip.Opening += new System.ComponentModel.CancelEventHandler(this.catalogMenuStrip_Opening);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(93, 6);
      // 
      // testToolStripMenuItem
      // 
      this.testToolStripMenuItem.Name = "testToolStripMenuItem";
      this.testToolStripMenuItem.Size = new System.Drawing.Size(96, 22);
      this.testToolStripMenuItem.Text = "Test";
      // 
      // nodeStateIcon
      // 
      this.nodeStateIcon.LeftMargin = 1;
      this.nodeStateIcon.ParentColumn = null;
      // 
      // nameNodeControl
      // 
      this.nameNodeControl.DataPropertyName = "Text";
      this.nameNodeControl.IncrementalSearchEnabled = true;
      this.nameNodeControl.LeftMargin = 3;
      this.nameNodeControl.ParentColumn = null;
      // 
      // presenceNodeControl
      // 
      this.presenceNodeControl.IncrementalSearchEnabled = true;
      this.presenceNodeControl.LeftMargin = 0;
      this.presenceNodeControl.ParentColumn = null;
      // 
      // headerPanel1
      // 
      this.headerPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(55)))), ((int)(((byte)(82)))));
      this.headerPanel1.Controls.Add(this.panel2);
      this.headerPanel1.Controls.Add(this.panel1);
      this.headerPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.headerPanel1.ForeColor = System.Drawing.Color.White;
      this.headerPanel1.HeaderColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(97)))), ((int)(((byte)(132)))));
      this.headerPanel1.HeaderPadding = new System.Windows.Forms.Padding(5, 0, 0, 0);
      this.headerPanel1.Location = new System.Drawing.Point(4, 3);
      this.headerPanel1.Name = "headerPanel1";
      this.headerPanel1.Padding = new System.Windows.Forms.Padding(0, 24, 0, 0);
      this.headerPanel1.Size = new System.Drawing.Size(279, 337);
      this.headerPanel1.TabIndex = 4;
      this.headerPanel1.Text = "Catalog Tree";
      // 
      // panel2
      // 
      this.panel2.BackColor = System.Drawing.Color.White;
      this.panel2.Controls.Add(this.catalogTreeView);
      this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
      this.panel2.Location = new System.Drawing.Point(0, 52);
      this.panel2.Name = "panel2";
      this.panel2.Padding = new System.Windows.Forms.Padding(4);
      this.panel2.Size = new System.Drawing.Size(279, 285);
      this.panel2.TabIndex = 4;
      // 
      // ModelCatalogForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.SystemColors.Window;
      this.ClientSize = new System.Drawing.Size(287, 343);
      this.Controls.Add(this.headerPanel1);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "ModelCatalogForm";
      this.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
      this.TabText = "Catalog";
      this.Text = "Catalog";
      this.panel1.ResumeLayout(false);
      this.catalogMenuStrip.ResumeLayout(false);
      this.headerPanel1.ResumeLayout(false);
      this.panel2.ResumeLayout(false);
      this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.ComboBox comboBox1;
		private Aga.Controls.Tree.TreeViewAdv catalogTreeView;
		private Aga.Controls.Tree.NodeControls.NodeStateIcon nodeStateIcon;
		private Aga.Controls.Tree.NodeControls.NodeTextBox nameNodeControl;
    private System.Windows.Forms.ContextMenuStrip catalogMenuStrip;
    private Aga.Controls.Tree.NodeControls.NodeTextBox presenceNodeControl;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    private System.Windows.Forms.ToolStripMenuItem testToolStripMenuItem;
    private MySQL.Controls.HeaderPanel headerPanel1;
    private System.Windows.Forms.Panel panel2;


	}
}