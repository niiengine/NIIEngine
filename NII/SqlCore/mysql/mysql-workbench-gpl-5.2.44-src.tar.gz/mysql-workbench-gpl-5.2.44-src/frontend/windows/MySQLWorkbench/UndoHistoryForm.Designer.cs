namespace MySQL.GUI.Workbench
{
    partial class UndoHistoryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
          if (disposing && (components != null))
          {
            components.Dispose();
          }
          historyTreeBE.remove_tree_refresh_handler(invokeRefresh);
          base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
          this.components = new System.ComponentModel.Container();
          System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UndoHistoryForm));
          this.historyTreeView = new Aga.Controls.Tree.TreeViewAdv();
          this.historyContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
          this.copyHistoryEntriesToClipboardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
          this.nodeStateIcon = new Aga.Controls.Tree.NodeControls.NodeStateIcon();
          this.nameNodeControl = new Aga.Controls.Tree.NodeControls.NodeTextBox();
          this.headerPanel1 = new MySQL.Controls.HeaderPanel();
          this.historyContextMenuStrip.SuspendLayout();
          this.headerPanel1.SuspendLayout();
          this.SuspendLayout();
          // 
          // historyTreeView
          // 
          this.historyTreeView.BackColor = System.Drawing.SystemColors.Window;
          this.historyTreeView.BorderStyle = System.Windows.Forms.BorderStyle.None;
          this.historyTreeView.ContextMenuStrip = this.historyContextMenuStrip;
          this.historyTreeView.DefaultToolTipProvider = null;
          this.historyTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
          this.historyTreeView.DragDropMarkColor = System.Drawing.Color.Black;
          this.historyTreeView.FullRowSelect = true;
          this.historyTreeView.GridLineStyle = Aga.Controls.Tree.GridLineStyle.Horizontal;
          this.historyTreeView.Indent = 12;
          this.historyTreeView.LineColor = System.Drawing.SystemColors.ControlDark;
          this.historyTreeView.LoadOnDemand = true;
          this.historyTreeView.Location = new System.Drawing.Point(0, 24);
          this.historyTreeView.Model = null;
          this.historyTreeView.Name = "historyTreeView";
          this.historyTreeView.NodeControls.Add(this.nodeStateIcon);
          this.historyTreeView.NodeControls.Add(this.nameNodeControl);
          this.historyTreeView.SelectedNode = null;
          this.historyTreeView.SelectionMode = Aga.Controls.Tree.TreeSelectionMode.Multi;
          this.historyTreeView.ShowLines = false;
          this.historyTreeView.ShowNodeToolTips = true;
          this.historyTreeView.ShowPlusMinus = false;
          this.historyTreeView.Size = new System.Drawing.Size(287, 319);
          this.historyTreeView.TabIndex = 0;
          this.historyTreeView.Text = "columnTreeView";
          this.historyTreeView.DoubleClick += new System.EventHandler(this.historyTreeView_DoubleClick);
          // 
          // historyContextMenuStrip
          // 
          this.historyContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyHistoryEntriesToClipboardToolStripMenuItem});
          this.historyContextMenuStrip.Name = "historyContextMenuStrip";
          this.historyContextMenuStrip.Size = new System.Drawing.Size(251, 26);
          // 
          // copyHistoryEntriesToClipboardToolStripMenuItem
          // 
          this.copyHistoryEntriesToClipboardToolStripMenuItem.Name = "copyHistoryEntriesToClipboardToolStripMenuItem";
          this.copyHistoryEntriesToClipboardToolStripMenuItem.Size = new System.Drawing.Size(250, 22);
          this.copyHistoryEntriesToClipboardToolStripMenuItem.Text = "Copy History Entries to Clipboard";
          this.copyHistoryEntriesToClipboardToolStripMenuItem.Click += new System.EventHandler(this.copyHistoryEntriesToClipboardToolStripMenuItem_Click);
          // 
          // nodeStateIcon
          // 
          this.nodeStateIcon.LeftMargin = 1;
          this.nodeStateIcon.ParentColumn = null;
          // 
          // nameNodeControl
          // 
          this.nameNodeControl.DataPropertyName = "Text";
          this.nameNodeControl.EditEnabled = false;
          this.nameNodeControl.IncrementalSearchEnabled = true;
          this.nameNodeControl.LeftMargin = 3;
          this.nameNodeControl.ParentColumn = null;
          // 
          // headerPanel1
          // 
          this.headerPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(55)))), ((int)(((byte)(82)))));
          this.headerPanel1.Text = "History Display";
          this.headerPanel1.HeaderPadding = new System.Windows.Forms.Padding(5, 0, 0, 0);
          this.headerPanel1.Controls.Add(this.historyTreeView);
          this.headerPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
          this.headerPanel1.ForeColor = System.Drawing.Color.White;
          this.headerPanel1.HeaderColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(97)))), ((int)(((byte)(132)))));
          this.headerPanel1.Location = new System.Drawing.Point(0, 0);
          this.headerPanel1.Name = "headerPanel1";
          this.headerPanel1.Padding = new System.Windows.Forms.Padding(0, 24, 0, 0);
          this.headerPanel1.Size = new System.Drawing.Size(287, 343);
          this.headerPanel1.TabIndex = 1;
          // 
          // UndoHistoryForm
          // 
          this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
          this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
          this.BackColor = System.Drawing.SystemColors.Window;
          this.ClientSize = new System.Drawing.Size(287, 343);
          this.Controls.Add(this.headerPanel1);
          this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
          this.Name = "UndoHistoryForm";
          this.TabText = "History";
          this.Text = "History";
          this.historyContextMenuStrip.ResumeLayout(false);
          this.headerPanel1.ResumeLayout(false);
          this.ResumeLayout(false);

        }

        #endregion


        private Aga.Controls.Tree.TreeViewAdv historyTreeView;
        private Aga.Controls.Tree.NodeControls.NodeStateIcon nodeStateIcon;
      private Aga.Controls.Tree.NodeControls.NodeTextBox nameNodeControl;
      private System.Windows.Forms.ContextMenuStrip historyContextMenuStrip;
      private System.Windows.Forms.ToolStripMenuItem copyHistoryEntriesToClipboardToolStripMenuItem;
      private MySQL.Controls.HeaderPanel headerPanel1;

    }
}