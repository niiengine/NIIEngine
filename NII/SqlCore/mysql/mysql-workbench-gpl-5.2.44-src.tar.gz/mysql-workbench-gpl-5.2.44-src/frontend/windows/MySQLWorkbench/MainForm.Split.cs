using System;

using MySQL.Forms;
using MySQL.Utilities;

namespace MySQL.GUI.Workbench
{
	partial class MainForm
	{
  }
}

