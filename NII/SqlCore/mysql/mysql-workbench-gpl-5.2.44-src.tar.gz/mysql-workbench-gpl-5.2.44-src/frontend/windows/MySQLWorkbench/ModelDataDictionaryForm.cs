using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MySQL.GUI.Workbench
{
	public partial class ModelDataDictionaryForm : Form
	{
		public ModelDataDictionaryForm()
		{
			InitializeComponent();
		}

		private void ModelDataDictionaryForm_Load(object sender, EventArgs e)
		{

		}
	}
}