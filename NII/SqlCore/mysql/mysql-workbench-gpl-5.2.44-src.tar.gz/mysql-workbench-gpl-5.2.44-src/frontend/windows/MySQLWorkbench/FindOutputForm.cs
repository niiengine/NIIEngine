using System;

using MySQL.Controls;
using MySQL.Grt;
using MySQL.Workbench;

namespace MySQL.GUI.Workbench
{
  public partial class FindOutputForm : TabDocument
  {
  }
}