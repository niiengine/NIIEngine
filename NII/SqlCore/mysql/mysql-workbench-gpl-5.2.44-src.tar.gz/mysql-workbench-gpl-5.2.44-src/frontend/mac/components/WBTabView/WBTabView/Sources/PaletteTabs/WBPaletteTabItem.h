
/*!
 Copyright 2009 Sun Microsystems, Inc.
 */



#import "WBTabItem.h"



@interface WBPaletteTabItem : WBTabItem
{
}


+ (WBTabItem*) tabItemWithIdentifier: (id) identifier
							   label: (NSString*) label;


@end


