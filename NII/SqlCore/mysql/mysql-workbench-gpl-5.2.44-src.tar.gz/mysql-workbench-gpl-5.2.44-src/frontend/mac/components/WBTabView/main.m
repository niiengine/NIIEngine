//
//  main.m
//  WBTabView
//
//  Created by Jacob on 2008-11-26.
//  Copyright www.PrettySweetPenguin.com 2008. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
