//
//  MCollectionViewItem.h
//  MySQLWorkbench
//
//  Created by Alfredo Kojima on 12/Oct/08.
//  Copyright 2008 Sun Microsystems Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface MCollectionViewItem : NSCollectionViewItem {

}

@end
