//
//  WBMainWindow_Model.h
//  MySQLWorkbench
//
//  Created by Alfredo Kojima on 26/Jul/09.
//  Copyright 2009 Sun Microsystems Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#import "WBMainWindow.h"

@interface WBMainWindow(WBMainWindow_Model)

- (void)setupModel;
- (void)handleModelCreated;
- (void)handleModelClosed;

@end
