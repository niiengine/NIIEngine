#include "stdafx.h"

//#pragma warning(disable: 4793)  // 'vararg' causes native code generation
#include "Grt.h"
#include "DBObjectEditorBE.h"
#include "TableEditorBE.h"