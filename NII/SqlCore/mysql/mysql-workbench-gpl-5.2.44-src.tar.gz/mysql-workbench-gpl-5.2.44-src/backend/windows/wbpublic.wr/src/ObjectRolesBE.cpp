#include "stdafx.h"

#include "Grt.h"
#include "ObjectRolesBE.h"

using namespace MySQL::Grt::Db;

ObjectPrivilegeListBE^ ObjectRoleListBE::get_privilege_list()
{
  return gcnew ObjectPrivilegeListBE(get_unmanaged_object()->get_privilege_list());
}
