#include "stdafx.h"

#include "Grt.h"
#include "DBObjectEditorBE.h"
#include "grts/structs.workbench.physical.h"
#include "ViewEditorBE.h"