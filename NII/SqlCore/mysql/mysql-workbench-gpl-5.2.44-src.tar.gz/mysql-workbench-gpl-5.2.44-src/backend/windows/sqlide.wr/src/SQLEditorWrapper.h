/* 
 * Copyright (c) 2007, 2012, Oracle and/or its affiliates. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; version 2 of the
 * License.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301  USA
 */

#ifndef __SQL_EDITOR_WR_H__
#define __SQL_EDITOR_WR_H__

#include "sqlide/sql_editor_be.h"

using namespace System;
using namespace System::Windows::Forms;

namespace mforms {
  class CodeEditor;
  class DockingPoint;
}

namespace MySQL {
namespace GUI {
namespace Workbench {

ref class Recordset;

public ref class SqlEditorWrapper
{
public:
  typedef MySQL::Grt::ManagedRef<::Sql_editor>^ Ref;

private:
  Ref _ref;
  mforms::DockingPoint *_docking_point; // Holder of the docking point delegate we get from the front end.
  MySQL::Forms::DockingPointDelegateWrapper ^_dock_delegate_wrapper;

public:
  SqlEditorWrapper(IntPtr nref_ptr);
  ~SqlEditorWrapper();

  void set_result_docking_delegate(MySQL::Forms::DockingPointDelegateWrapper ^theDelegate);

  Ref ref() { return _ref; }
  System::Windows::Forms::Control^ get_native_editor();

  bool is_refresh_enabled() { return _ref->is_refresh_enabled(); }
  void set_refresh_enabled(bool val) { _ref->set_refresh_enabled(val); }
  bool is_sql_check_enabled() { return _ref->is_sql_check_enabled(); }
  void set_sql_check_enabled(bool val) { _ref->set_sql_check_enabled(val); }

  void set_language(String^ language);

  void append_text(String^ text);
  void set_text(String^ text);

  static SqlEditorWrapper^ get_sql_editor(MySQL::Grt::BaseEditor^ wrapper);

};


};  // namespace Workbench
};  // namespace GUI
};  // namespace MySQL


#endif // __SQL_EDITOR_WR_H__
