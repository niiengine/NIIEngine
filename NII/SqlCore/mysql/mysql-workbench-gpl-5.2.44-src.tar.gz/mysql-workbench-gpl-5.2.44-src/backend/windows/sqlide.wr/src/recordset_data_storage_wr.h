/* 
 * Copyright (c) 2007, 2011, Oracle and/or its affiliates. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; version 2 of the
 * License.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301  USA
 */


#ifndef __RECORDSET_DATA_STORAGE_WR_H__
#define __RECORDSET_DATA_STORAGE_WR_H__


#include "sqlide/recordset_data_storage.h"


namespace MySQL {
namespace Grt {
namespace Db {


public ref class Recordset_data_storage
{
public:
  typedef ManagedRef<::Recordset_data_storage> ^ Ref;
  Recordset_data_storage(Ref ref) : _ref(ref) {}
  Ref ref() { return _ref; }
private:
  Ref _ref;
private:
  ~Recordset_data_storage();

public:
  void serialize(RecordsetWrapper ^rs);
};


};  // namespace Db
};  // namespace Grt
};  // namespace MySQL


#endif // __RECORDSET_DATA_STORAGE_WR_H__
